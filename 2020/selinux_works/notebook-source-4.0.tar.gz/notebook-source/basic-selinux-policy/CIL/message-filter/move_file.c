/*
 * This is the file mover component for the Notebook demo modular policy
 * It moves the files created as a part of the SECMARK tests from the
 * /usr/message_queue/in_queue to the /usr/message_queue/out_queue.
 * The move_file.conf module ensures that the output queue files are
 * correctly labeled out_file_t by an object type_transition.
 *
 * Copyright (C) 2012  Richard Haines
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * The move_file program is compiled as:
 *      gcc -o move_file move_file.c
 *
 * The move_file application can optionally be called with a timer value
 * (in seconds) so that it can be run forever checking the in_queue
 * every X seconds: move_file [timer]
 *
 * For the tests, the binary should be installed in /usr/local/bin and
 * then the mk-dir script run to create the following directories:
 *      mkdir -p /usr/message_queue/in_queue
 *      mkdir -p /usr/message_queue/out_queue
 *
 * Install the move_file loadable module by:
 *      checkmodule -m move_file.conf -o move_file.mod
 *      semodule_package -o move_file.pp -m move_file.mod -f move_file.fc
 *      semodule -v -s modular-test -i move_file.pp
 *
 * Finally label the binary and message queue directories by:
 *      restorecon -r -f restorecon_move_file
 *
 * The server.c file describes how the files are are created etc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/dir.h>
#include <sys/param.h>

#define MAXBUFFERSIZE 256

#define	FALSE 0
#define TRUE !FALSE

extern int alphasort();

/* variable to store current path */
char in_path[] = "/usr/message_queue/in_queue";
char out_path[] = "/usr/message_queue/out_queue";

int main(int argc, char *argv [])
{
	FILE	*fp1;
	FILE	*fp2;
	char	buffer[MAXBUFFERSIZE];
	char	in_file_name[MAXPATHLEN];
	char	out_file_name[MAXPATHLEN];
	int	timer, count, length, i;
	struct direct **files;
	int select_file();

	/* Use arg as the timer to use */
	if (argc == 2)
		timer = atoi(argv [1]);
	else
		timer = 0;

	while (TRUE) {
		count = 0;
		count = scandir(in_path, &files, select_file, alphasort);
		printf("Count = %d Timer = %d\n", count, timer);
		if ((count <= 0 && timer == 0))
			break;
		else
			sleep(timer);

		for (i=1; i<count+1; ++i) {
			/* Build file name and clear the buffer */
			sprintf(in_file_name,"%s/%s", in_path, files [i-1]->d_name);
			memset(buffer, 0, sizeof (buffer));

			/* Open INQ file */
			if ((fp1 = fopen (in_file_name, "r")) == 0) {
				ferror(fp1);
				exit(1);
			}

			/* Read Contents of File */
			if (fread (buffer, sizeof (buffer), 1, fp1) != 0) {
				ferror(fp1);
				exit(1);			}


			/* Build output file name */
			sprintf(out_file_name,"%s/%s", out_path, files [i-1]->d_name);

			/* Open OUTQ file */
			if ((fp2 = fopen (out_file_name, "w")) == 0) {
				ferror(fp2);
				exit(1);			}

			/* Get buffer length */
			strcat(buffer, "(FILE MOVED TO OUT QUEUE)");
			length = strlen(buffer);

			/* Write Contents of File */
			if (fwrite(buffer, length, 1, fp2) != 1) {
				ferror(fp2);
				exit(1);			}

			unlink(in_file_name);
			fclose(fp1);
			fclose(fp2);
		}
	}
	exit(0);
}



int select_file(struct direct *entry)
{
	if ((strcmp(entry->d_name, ".") == 0) || (strcmp(entry->d_name, "..") == 0))
		return(FALSE);
	else
		return(TRUE);
}
