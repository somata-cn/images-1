/*
 * This is the server component for the Notebook demo modular policy. It
 * will be used to demonstrate SECMARK and NetLabel network functionality
 * and also creates and reads files for the Message Filter example.
 *
 * Copyright (C) 2012  Richard Haines
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * The server is compiled as follows:
 *    gcc server.c -o server -lselinux
 *       (This is labeled system_u:object:unconfined_t)
 *    gcc server.c -o secure_server -lselinux
 *       (This is labeled system_u:object:secure_services_exec_t)
 *
 * For the tests, the binaries should be installed in /usr/local/bin and
 * then the restorecon -f restorefiles_gateway run once the
 * external_gateway loadable module has been installed.
 *
 * The server receives a connection from a client (but no data) and then
 * builds a buffer containing information on ports and contexts used,
 * returning this to the client (the default action).
 */

/* For the SECMARK and NetLabel demo the servers are called as follows:
 *    server <port> - Where the port is any you like (e.g. 1234)
 *    secure_server <port> - Where for the demo are ports 9999 and 1111
 *    as the test iptables security table has been configured for these.
 *    ports.
 */

/* For the Message Filter demo the servers are called as follows:
 *
 *   1) To queue messages to the Message Filter's IN queue:
 *         secure_server <port> in - Where the port is 1111
 *      And then run the secure_client in another terminal session:
 *         secure_client 127.0.0.1 9999
 *      Note - This is using the external_gateway module for controlling
 *      network access and the move_file module for controlling file access.
 *
 *      The [in] command line option writes the buffer to a file named
 *      Message-<message_number> in the in_path directory. If the server is
 *      restarted, then the <message_number> just starts from 1 again
 *      These files will be removed by the Message Filter move_file
 *      application and moved to the out_path directory.
 *
 *   2) To read messages from the Message Filter's OUT queue (after they have
 *      been move by the move_file application):
 *          runcon -t int_gateway_t -r message_filter_r secure_server 9999
 *
 *      And then run the secure_client in another terminal session:
 *          runcon -t int_gateway_t -r message_filter_r secure_client  \
 *                                                         27.0.0.1 9999
 *
 *     Note - This is using the internal_gateway module for controlling
 *      network access and the move_file module for controlling file access.
 *
 *      The [out] command line option reads files from the out_path directory
 *      and sents them to the client. The file is then unlinked.
 */

/* FINAL NOTES:
 *   1) unconfined_t is not allowed to read/write files in the [in] or
 *      [out] directories, if it tries, the context is displayed and the
 *      server will exit (e.g 'server 1234 in' and 'client 127.0.0.1 1234').
 *
 *    2) when tested, the fopen function call on the [in] queue processing
 *       caused a segmentation fault (a feature ??). The only way found to
 *       stop this was to add an 'opendir' function call to the code, the
 *       server can then exit gracefully displaying the context.
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/param.h>
#include <dirent.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <selinux/selinux.h>

#define MAXBUFFERSIZE 256

/* variable to store current path */
char in_path[] = "/usr/message_queue/in_queue";
char out_path[] = "/usr/message_queue/out_queue";


int main(int argc, char *argv[])
{
	short	server_port;
	int	count, rc, sock_fd, new_sock_fd, message_number, option;
	struct sockaddr_in server_addr;
	struct sockaddr_in client_addr;
	socklen_t sin_size;
	char buffer[MAXBUFFERSIZE];
	security_context_t context, peer_context, dir_context;
	char *peer_context_str;
	FILE *fp;
	char file_name[MAXPATHLEN];
	char in[] = "in";
	char out[] = "out";
  	DIR *dp;
	struct dirent *ep;

	if (argc < 2) {
		fprintf(stderr,"Usage: %s <port>\n", argv[0]);
		exit(1);
	}

	if ((server_port = atoi (argv [1])) == 0)  {
		fprintf(stderr,"Usage: %s <port>\n", argv[0]);
		exit(1);
	}

	option = 0; /* Set to default (i.e. no in or out queue parameter) */

	/* Display default message about port, */
	/* but alter if other options selected. */
	sprintf(buffer, "Listening on port %d", server_port);
	if (argc == 3) {
		if (strcmp(argv[2], in) == 0) {
			option = 1;
			sprintf(buffer, "Listening on port %d. Information sent to "
			            "client will be written to files in %s",
			                server_port, in_path);
		}
		else if (strcmp(argv[2], out) == 0) {
			option = 2;
			sprintf(buffer, "Listening on port %d. Files will be read "
			            "from %s and the contents sent to the client",
			                server_port, out_path);
		}
		else {
			fprintf(stderr,"Usage: %s <port> [in | out]\n", argv[0]);
		exit(1);
		}
	}

	printf("%s\n", buffer);

	if ((sock_fd = socket(PF_INET, SOCK_STREAM, 0)) == -1) {
		perror("Server socket");
		exit(1);
	}

	if ((rc = getpeercon (sock_fd, &peer_context)) < 0)
		printf("open socket - No Peer Context Available\n");
	else {
		printf("open socket - Peer Context: %s\n", peer_context);
		freecon(peer_context);
	}

	/* Set message_number to 1 for index "Message[message_number] */
	message_number = 1;

	bzero((char *) &server_addr, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(server_port);
	server_addr.sin_addr.s_addr = INADDR_ANY;

	if (bind(sock_fd, (struct sockaddr *)&server_addr,
	                            sizeof(struct sockaddr)) == -1) {
		perror("Server bind");
		exit(1);
	}
	if ((rc = getpeercon (sock_fd, &peer_context)) < 0)
		printf("bind - No Peer Context Available\n");
	else {
		printf("bind - Peer Context: %s\n", peer_context);
		freecon(peer_context);
	}

	if (listen (sock_fd, 5) == -1) {
		perror("Server listen");
		exit(1);
	}
	if ((rc = getpeercon (sock_fd, &peer_context)) < 0)
		printf("listen - No Peer Context Available\n");
	else {
		printf("listen - Peer Context: %s\n", peer_context);
		freecon(peer_context);
	}

	while (1) {
		sin_size = sizeof(struct sockaddr_in);
		if ((new_sock_fd = accept(sock_fd, (struct sockaddr *)&client_addr,
		                                                &sin_size)) == -1) {
			perror("Server accept");
			continue;
        }
        /* Get context assigned to the new socket */
        if ((rc = fgetfilecon_raw(new_sock_fd, &context)) == -1) {
        perror("fgetfilecon_raw - FAILED");
        exit(1);
        }
        printf("accept on new socket - context assigned to new socket is (using "
                                            "fgetfilecon):\n\t%s\n", context);
        freecon(context);
        /* And then check if a peer context is assigned to this new socket */
	    if ((rc = getpeercon (new_sock_fd, &peer_context)) < 0)
		    printf("accept on new socket - No Peer Context Available\n");
	    else {
		    printf("accept on new socket - Peer Context: %s\n", peer_context);
		    freecon(peer_context);
	    }

		/* Get Server context information */
		if ((rc = getcon(&context)) < 0) {
			perror("Server context");
			exit(1);
		}

		if ((rc = getpeercon(new_sock_fd, &peer_context)) < 0)
			peer_context_str = strdup("No Peer Context Available");
		else {
			peer_context_str = strdup(peer_context);
			freecon(peer_context);
		}
		/* Clear the buffer of rubbish */
		memset(buffer, 0, sizeof(buffer));

		switch (option) {
		case 1:
		/*
		 * This option sends the buffer to client,
		 * and then writes it to a file in the in_que
		 */
		 /*  Make up a file name */
			sprintf(file_name, "Message-%d", message_number);

            /*
			 * Build buffer with Message Number at start.
			 * The Message number will also be the file name
             */
			sprintf(buffer, "This is %s from the server listening on "
			                "port: %d \nClient source port: %d \nServer "
			                "Context: %s \nServer Peer Context: %s \n",
			                file_name, ntohs(server_addr.sin_port),
			                ntohs(client_addr.sin_port), context,
			                peer_context_str);

			if (send(new_sock_fd, buffer, strlen(buffer), 0) == -1)
				perror("Server send");
			/* Now write buffer to file as well */

            /*
			 * This opendir has been put here as get Segmentation
			 * fault if just do the fopen and its
			 * unconfined_t trying to write a file here
			 */
			if ((dp = opendir(in_path)) == 0) {
			/* Could be that unconfined_t is trying this, */
			/* if so exit showing context: */
				getcon(&dir_context);
				printf("Open Directory error %s Context is: %s\n",
				            in_path, dir_context);
				exit(1);
			}
			closedir(dp);

			/* Make up full path + file name */
			sprintf(file_name,"%s/Message-%d", in_path, message_number);
			if ((fp = fopen(file_name, "w")) == 0) {
				ferror(fp);
				exit(0);
			}

			count = strlen(buffer);
			if (fwrite(buffer, count, 1, fp) != 1) {
				ferror(fp);
				exit(0);
			}
			fclose(fp);
			break;

		case 2:
		/* This option will read a file from the out_queue, */
		/* send it to the client and then delete it. */
			if ((dp = opendir(out_path)) == 0) {
			/* Could be that unconfined_t is trying this on insecure */
			/* channel ?? If so then exit showing context: */
				getcon(&dir_context);
				printf("Open Directory error %s Context is: %s\n",
				            out_path, dir_context);
				exit(1);
			}

			do {
				if ((ep = readdir(dp)) == 0) {
					sprintf(buffer, "Server has no files to send\n");
					break;
				}
			} while ((strcmp(ep->d_name, ".") == 0) ||
			                (strcmp(ep->d_name, "..") == 0));

			if (ep != 0) { /* There is a file if ep != 0, otherwise send */
			               /* note to client saying no more files */
				sprintf(file_name,"%s/%s", out_path, ep->d_name);

	   			if ((fp = fopen(file_name, "r")) == 0) {
					ferror(fp);
					exit(0);
				}

				/* Read Contents of File */
				if (fread(buffer, sizeof(buffer), 1, fp) != 0) {
					ferror(fp);
					exit(0);
				}
				unlink(file_name);
				fclose(fp);
				closedir(dp);
			}

			/* Now send the buffer to client */
			count = strlen(buffer);
			if (send(new_sock_fd, buffer, count, 0) == -1)
				perror("Server send");
			break;

		default: /* There is no in_que or out_que parameter */
		         /* so just send the buffer. */
			/* Make up a Message name */
			sprintf(file_name,"Message-%d", message_number);

			/* Print Server network information */
			printf("Server has connection from client: host = %s destination "
			            "port = %d source port = %d\n",
			            inet_ntoa(client_addr.sin_addr),
			            ntohs(server_addr.sin_port),
			            ntohs(client_addr.sin_port));

			printf("Server Context: %s \nServer Peer Context: %s \n",
			            context, peer_context_str);

			sprintf(buffer, "This is %s from the server listening on port: "
			            "%d \nClient source port: %d \nServer Context: %s \n"
			            "Server Peer Context: %s \n",
			            file_name, ntohs(server_addr.sin_port),
			            ntohs(client_addr.sin_port),
			            context, peer_context_str);

			if (send(new_sock_fd, buffer, strlen(buffer), 0) == -1)
				perror("Server send");
		}
		message_number++;
		freecon(context);
		close(new_sock_fd);
	}
	return 0;
}
