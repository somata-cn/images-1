/*
 * This is the client component for the Notebook demo modular policy. It
 * will be used to demonstrate SECMARK, NetLabel and Message Filter
 * loadable modules.
 *
 * Copyright (C) 2012  Richard Haines
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * This client connects to the server that builds a buffer containing
 * information on ports and contexts used by the server, returning this
 * to the client.
 *
 * The client is compiled as follows:
 *    gcc client.c -o client -lselinux
 *       (This is labeled system_u:object:unconfined_t)
 *    gcc client.c -o secure_client -lselinux
 *       (This is labeled system_u:object:secure_services_exec_t)
 *
 * For the tests, the binaries should be installed in /usr/local/bin and
 * then the restorecon -f restorefiles_gateway run once the
 * external_gateway loadable module has been installed.
 */

/* For SECMARK, NetLabel and Message Filter demos the clients are called
 * as follows:
 *    ./client <port> - Where the port is any you like (e.g. 1234)
 *    ./secure_client <port> - Where for the demo thes ports are 1111
 *    and 9999 as the iptables mangle table has been configured for these.
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <selinux/selinux.h>

#define MAXBUFFERSIZE 256
#define ENFORCING 1

#define ESC 0x1B

char red[] = "0;31";
char green[] = "0;32";
char reset[] = "0";

int main(int argc, char *argv [])
{
	int rc, sock_fd, bytes_received;
	char buffer[MAXBUFFERSIZE];
	struct hostent *server_info;
	struct sockaddr_in server_addr;
	short client_port;
	security_context_t context;
	security_context_t peer_context;
	char *peer_context_str;

	if (argc != 3) {
		fprintf(stderr,"usage: %s <hostname> <port> "
		            "(Use port 9999 for secure port test)\n", argv[0]);
		exit(1);
	}

	client_port = atoi(argv[2]);

	if ((server_info = gethostbyname(argv [1])) == NULL) {
		herror("Client gethostbyname");
		exit(1);
	}

	if ((rc = security_getenforce ()) != ENFORCING)
		printf("Should be in enforcing mode for valid testing\n");

	if ((sock_fd = socket(PF_INET, SOCK_STREAM, 0)) == -1) {
		perror("Client Socket");
		exit(1);
	}
	if ((rc = getpeercon (sock_fd, &peer_context)) < 0)
		printf("open socket - No Peer Context Available\n");
	else {
		printf("open socket - Peer Context: %s\n", peer_context);
		freecon (peer_context);
	}

	bzero((char *) &server_addr, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(client_port);
	server_addr.sin_addr = *((struct in_addr *)server_info->h_addr);

	if (connect(sock_fd, (struct sockaddr *)&server_addr,
	                                sizeof(struct sockaddr)) == -1) {
		perror("Client connect");
		exit(1);
	}
	if ((rc = getpeercon (sock_fd, &peer_context)) < 0)
		printf("connect - No Peer Context Available\n");
	else {
		printf("connect - Peer Context: %s\n", peer_context);
		freecon(peer_context);
	}


	/* clear the buffer */
	memset(buffer, 0, sizeof(buffer));
	if ((bytes_received = recv(sock_fd, buffer, MAXBUFFERSIZE-1, 0)) == -1) {
		perror("Client recv");
		exit(1);
	}
	if ((rc = getpeercon (sock_fd, &peer_context)) < 0)
		printf("recv - No Peer Context Available\n");
	else {
		printf("recv - Peer Context: %s\n", peer_context);
		freecon(peer_context);
	}

	buffer[bytes_received] = '\0'; /* Add null at end of line. */
	printf("\033[%smServer Information in RED:\n", red);
	printf("%s \n", buffer);


	/* Print the Clients context information */
	if ((rc = getcon(&context)) < 0) {
		perror("Client context");
		exit(1);
	}

	if ((rc = getpeercon(sock_fd, &peer_context)) < 0)
		peer_context_str = strdup ("No Peer Context Available");
	else {
		peer_context_str = strdup(peer_context);
		freecon(peer_context);
	}
	printf("\033[%smClient Information in GREEN:\n", green);
	printf("Client Context: %s \nClient Peer Context: %s \n",
	                                    context, peer_context_str);
	freecon(context);
	close(sock_fd);
	printf("\033[%sm\n", reset);
	exit(0);
}
