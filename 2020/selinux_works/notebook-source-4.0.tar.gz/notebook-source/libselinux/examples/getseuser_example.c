#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    char *username;
    char *service;
    char *r_seuser = NULL;
    char *r_level = NULL;
    int rc;

#ifdef INFO
    printf("\nThe getseuser example requires a Linux user name and service to "
                "be selected.\nIt will then retrieve the associated SELinux "
                "user and level.\nIt reads the policy 'logins/<linuxuser>' "
                "file for service entries in the form:\n\t"
                "<service>:<user_name>:<level>\n\nIt then returns these "
                "parameters. Should the logins/<linuxuser> file not exist\nor "
				"no entries are found the seusers file is interogated to "
				"finally resolve the\nrequired user and level."
                "\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[linux_user]", (char **)&username);
    get_config_entry("[service]", (char **)&service);

    printf("\nExecuting: getseuser(%s, %s, &r_seuser, &r_level);\n",
                                                            username, service);

    if ((rc = getseuser(username, service, &r_seuser, &r_level)) != 0) {
        perror("getseuser - ERROR");
        exit(1);
    }

    printf("The returned SELinux user is: %s with level: %s\n",
                                                        r_seuser, r_level);
    free(r_seuser);
    free(r_level);
    exit(0);
}
