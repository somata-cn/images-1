/*
 * basic_canonicalize_context - This will take a source context and writes it
 * to /selinux/context. The next read will then return the canonacalised
 * context.
 *
 * This code has been derived from the libselinux source.
 */

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <limits.h>
#include <selinux/selinux.h>

/* selinuxfs mount point */
extern char *selinux_mnt;

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t con;
    security_context_t canoncon = NULL;
	int selinux_page_size = sysconf(_SC_PAGE_SIZE);
	char path[PATH_MAX];
	char *buf;
	int fd, rc;

    printf("The basic_canonicalize_context example requires a context entry "
                                "to be selected.\nPress return to continue\n");
    getchar();
    get_config_entry("[raw_context]", &con);

    sprintf(path, "%s/context", selinux_mnt);
	if ((fd = open(path, O_RDWR)) < 0) {
	    perror("OPEN FAILED");
	    exit(1);
	}

    if ((buf = malloc(selinux_page_size)) == NULL) {
	    perror("MALLOC FAILED");
	    exit(1);
	}

	strncpy(buf, con, selinux_page_size);
	    printf("About to write context %s to:\n\t%s\n\n", con, path);
	if ((rc = write(fd, buf, strlen(buf))) < 0) {
	    perror("WRITE FAILED");
	    exit(1);
	}

	memset(buf, 0, selinux_page_size);

	if ((rc = read(fd, buf, selinux_page_size - 1)) < 0) {
	    perror("READ FAILED");
	    exit(1);
	}

	if ((canoncon = strdup(buf)) == NULL) {
		printf("No context returned\n");
		exit(1);
	}
	printf("Returned context is: %s\n\n", canoncon);

	free(buf);
	close(fd);
	exit(0);
}
