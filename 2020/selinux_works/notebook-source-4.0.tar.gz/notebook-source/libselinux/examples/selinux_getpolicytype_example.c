#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc;
    char *str = NULL;

#ifdef INFO
    printf("\nThe selinux_getpolicytype example will return the SELINUXTYPE "
				"entry (defined\nin the SELinux configuration file) that was "
				"used to load the current policy.\nPress return to continue\n");
    getchar();
#endif

    printf("Executing selinux_getpolicytype(&str);\n");

    if ((rc = selinux_getpolicytype(&str)) == -1) {
        printf("\nFAILED to get current policy type\n");
        perror("selinux_getpolicytype - ERROR");
    }
    else {
    	printf("\nThe current SELINUXTYPE entry is: %s\n", str);
    	free(str);
	}

	exit(0);
}
