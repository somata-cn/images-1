#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);
extern char *config_file;

int main(int argc, char **argv)
{
    security_class_t tclass;
    access_vector_t av_perm;
    char *string;

#ifdef INFO
    printf("\nThe print_access_vector example requires a class and one or more "
				"permissions\nto be selected. The permissions will then be "
				"converted and displayed as\nreadable strings. If some are "
				"invalid, it prints the valid ones and then\nthe permission "
				"bit mask representing the invalid bits.\n\n");

	printf("Notes 1) The class value requested is a string that will be "
				"converted to the\n         class numerical value by the "
				"string_to_security_class function,\n         however the "
				"permissions will be in bit format taken from the\n         "
				"[perms_av] entry of the %s configuration file.\n\n"
				"      2) Policies are built using the string values, they "
				"are then converted\n         to numerical values by the "
				"SELinux kernel services. Therefore the\n         actual "
				"numerical values will vary depending on the policy loaded "
				"and\n         what class / permissions it has configured."
				"\nPress return to continue\n", config_file);
    getchar();
#endif

    get_config_entry("[class]", &string);
    tclass = string_to_security_class(string);
    free(string);

    get_config_entry("[perms_av]", &string);
    av_perm = strtoll(string, (char **)&string[8], 16);
    free(string);

    printf("\nExecuting: print_access_vector(%d, 0x%x);\n", tclass, av_perm);
    print_access_vector(tclass, av_perm);
    printf(" - are the requested permissions for class %s\n",
                                            security_class_to_string(tclass));
    exit(0);
}
