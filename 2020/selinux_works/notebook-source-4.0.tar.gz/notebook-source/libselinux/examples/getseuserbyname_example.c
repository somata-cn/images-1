#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    const char *linuxuser;
    char *selinuxuser = NULL;
    char *level = NULL;
    int rc;

#ifdef INFO
    printf("\nThe getseuserbyname example requires a Linux user name to be "
                "selected. It will\nthen retrieve the associated SELinux user "
                "and level or range.\n");

    printf("Notes 1) The function reads the policy 'seusers' file. If the "
                "Linux user\n          name does not exist, then returns "
                "the seusers '__default__' entry.\n"
                "       2) The function does not check if the Linux user is "
                "valid.\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[linux_user]", (char **)&linuxuser);

    printf("Executing: getseuserbyname(%s, &selinuxuser, &level);\n",
                                                                    linuxuser);

    if ((rc = getseuserbyname(linuxuser, &selinuxuser, &level)) != 0) {
        perror("getseuserbyname - ERROR");
        exit(1);
    }

    printf("The returned SELinux user is: %s and level/range: %s\n",
                                                           selinuxuser, level);
    free(selinuxuser);
    free(level);
    exit(0);
}
