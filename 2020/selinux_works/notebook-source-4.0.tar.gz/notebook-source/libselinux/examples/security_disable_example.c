#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc;

#ifdef INFO
	printf("\nThe security_disable example will call the security_disable "
				"function, however\nit will fail once the SELinux kernel "
				"has loaded a policy. This function is\nonly useful if "
				"it is called before the initial policy load to disable "
				"SELinux.\nPress return to continue\n");
    getchar();
#endif

    printf("\nExecuting: security_disable();\n");

    if ((rc = security_disable()) == -1) {
        printf("\nCannot disable SELinux\n");
        perror("security_disable - ERROR");
    }
    else
        printf("\nSELinux now disabled and /selinux unmounted\n");

    exit(0);
}
