#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

extern char **environ;

int main(int argc, char **argv)
{
    int rc;
	security_context_t mycon;
    char  *path;

#ifdef INFO
    printf("\nThe rpm_execcon example requires an executable file to be "
                "selected that will be\nrun as part of the example.\n\nIt is "
                "recommended that the /usr/local/bin/getcon_example is "
                "selected as that\nwill show the new context set by "
				"rpm_execcon.\n\nDepending on the context you are running in "
				"rpm_execcon will set the 'type'\nfield (via setexeccon) to "
				"a default of 'rpm_script_t' that will be shown by\nthe "
				"getcon_example (if selected).\n");

	printf("\nNote 1) The type 'rpm_script_t' is defined in the Reference "
				"Policy and also\nin the rpm_execcon function (see libselinux "
				"rpm.c)\n\nNote 2) that the current process context will be "
				"displayed before calling\nrpm_execcon so that it can be "
				"compared to the context displayed by\ngetcon_example "
				"(if selected).\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[path]", &path);

	if ((rc = getcon_raw(&mycon)) != 0) {
		printf("could not get current process context\n");
        perror("getcon_raw - ERROR");
		exit (1);
	}
	printf("\nThe current process context is: \n\t%s\n", mycon);

    printf("\nExecuting: rpm_execcon(0, %s, NULL, environ)\n", path);

    if ((rc = rpm_execcon(0, path, NULL, environ)) == -1) {
        perror("Failed to exec - ERROR");
        exit(0);
    }
    /* If execve okay, then we don't get here anyway. */
    free(path);
    exit(0);
}
