#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int enforce_mode, rc;

#ifdef INFO
    printf("\nThe selinux_getenforcemode example will return the SELINUX "
				"entry from the SELinux\nconfiguration file. This will be "
				"either permissive, enforcing or disabled.\nNote that this "
				"is not the current enforcement mode (use security_getenforce "
				"\nfunction for that).\n");
#endif

    printf("\nExecuting: selinux_getenforcemode(&enforce_mode);\n");

    if ((rc = selinux_getenforcemode(&enforce_mode)) == -1) {
        printf("Failed to obtain the SELINUX entry\n");
        perror("selinux_getenforcemode - ERROR");
		exit(1);
	}

	printf("\nThe %sconfig SELINUX entry is set to: ", selinux_path());
    switch (enforce_mode) {
        case 0:
            printf("PERMISSIVE\n");
            break;
       case 1:
            printf("ENFORCING\n");
            break;
       case -1:
            printf("DISABLED\n");
            break;
     }
    exit(0);
}
