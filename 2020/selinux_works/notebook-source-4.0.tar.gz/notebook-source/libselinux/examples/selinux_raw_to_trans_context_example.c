#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t raw;
    security_context_t transp;
    int rc;

#ifdef INFO
    printf("\nThe selinux_raw_to_trans_context example requires a raw "
                "context to be selected\nthat will then be converted to its "
				"'translated' value.\nNote: To run this correctly the "
				"following must be enabled:\n"
                " a) A translation configuration file at:\n\t%s\n"
				"    This will need entries to reflect the translation of the "
				"context as if\n    not present the context is returned "
				"unchanged.\n"
                "\n b) The mcstransd daemon started: service mcstrans start\n"
                "Press return to continue\n", selinux_translations_path());
    getchar();
#endif

    get_config_entry("[raw_context]", &raw);

    printf("Executing: selinux_raw_to_trans_context(%s, &transp);\n", raw);
    if ((rc = selinux_raw_to_trans_context(raw, &transp)) == -1) {
        printf("Failed to get tranlated context\n");
        perror("selinux_raw_to_trans_context - ERROR");
        exit(1);
    }

    printf("\nThe translated context is: %s\n\n", transp);
    freecon(transp);
    exit(0);
}
