#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t scon;
    security_context_t tcon;
    security_class_t tclass;
	security_context_t newcon;
	int rc;
    char *string;

#ifdef INFO
	printf("\nThe security_compute_member example requires a source and target "
            "context plus\na class to be selected. Note that the class will "
			"be converted using the\nstring_to_security_class function. The "
			"function will then compute a context\nbased on the source and "
			"target contexts for labeling a new object of the\nselected class "
			"based on the type_member rule:\n\n"
			"type_member <source_type> <target_type> : class <member_type>;\n");

	printf("\nIf using the F16 targeted policy, then there is a:\n\t"
			"security_compute_member_example.conf\npolicy module supplied in "
			"the 'modules' directory that will add sample\ntype_member rules "
			"to the policy.\nPress return to continue\n");
	getchar();
#endif

    get_config_entry("[raw_context]", &scon);
    get_config_entry("[raw_context]", &tcon);
    get_config_entry("[class]", &string);
    tclass = string_to_security_class(string);

    printf("\nExecuting: security_compute_member_raw(%s, %s, %d, &newcon);\n",
                                                    scon, tcon, tclass);
    if ((rc = security_compute_member_raw(scon, tcon, tclass, &newcon)) < 0) {
        perror("security_compute_member_raw - ERROR");
        exit(1);
    }

	printf("\nReturned member context for class %s is:\n\t%s\n",
                                                            string, newcon);
	free(string);
    exit(0);
}
