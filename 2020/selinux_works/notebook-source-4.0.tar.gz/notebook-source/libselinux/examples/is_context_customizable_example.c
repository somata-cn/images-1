#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t scon;
    int rc;

#ifdef INFO
    printf("\nThe is_context_customizable example requires a context entry to "
                    "be selected.\nThe policy 'context/customizable_types' "
                    "file is then read for a matching\n'type' entry.\n\n"
					"Note: A customizable type is a file context type that is "
					"usually set on files\nthat need to be shared among "
					"certain domains and where the  administrator wants\nto "
					"manually manage the type.\nThe  use  of customizable "
					"types is deprecated as the preferred approach is to\nuse "
					"'semanage fcontext ...'(8)\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[raw_context]", &scon);

    printf("Executing: is_context_customizable(%s);\n", scon);
    rc = is_context_customizable(scon);

    switch (rc) {
        case 0:
            printf("\nThe context 'type' component is not in the "
						"customizable_types file.\n\n");
            break;
        case 1:
            printf("\nThe context 'type' component is in the customizable_types "
						"file and therefore\nrestorecon(8) and setfiles(8) "
						"will not change unless forced to do so.\n\n");
            break;
        case -1:
        default:
            perror("is_context_customizable - ERROR");
            break;
    }
     exit(0);
}
