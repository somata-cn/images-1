#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    const char *str = NULL;
    security_class_t tclass;
    access_vector_t av_perm;
    char *string;

#ifdef INFO
    printf("\nThe security_av_perm_to_string example requires a class string "
                "and a single\npermission bit to be selected. The function "
				"will then return the permission\nstring.\n"
                "\nNotes 1) A class string is requested that is then "
				"converted to the appropriate\n         class ID by the "
				"string_to_security_class function.\n"
				"\n      2) This function will only return a single "
				"permission. Use the\n         security_av_string function to "
                "return multiple permissions.\n"
				"\n      3) If more than one bit is selected, the function "
				"returns the permission\n         for the least significant "
				"bit.\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[class]", &string);
	/* Convert the string to a class id. Do not check so invalid can be used. */
    tclass = string_to_security_class(string);
    free(string);

    get_config_entry("[perms_av]", &string);
	/* Convert the selected permission bit string */
    av_perm = strtoll(string, (char **)&string[8], 16);
    free(string);

    printf("Executing: security_av_perm_to_string(%d, 0x%08x);\n",
                                                            tclass, av_perm);

    if ((str = security_av_perm_to_string(tclass, av_perm)) != NULL)
        printf("\nThe permission returned for class %s is: %s\n",
                                    security_class_to_string(tclass), str);
    else
        perror("\nsecurity_av_perm_to_string - ERROR");

    exit(0);
}
