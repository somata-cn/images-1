#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <selinux/selinux.h>
#include <selinux/get_context_list.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    const char *user;
    const char *level;
    security_context_t fromcon = NULL;
    security_context_t newcon = NULL;
    int rc;

#ifdef INFO
    printf("\nThe get_default_context_with_level example requires a user, "
                "context and level\nto be selected. The default context for "
                "the user is then obtained using the\nsupplied level.\n");

    printf("\nNotes: 1) Select the context NULL entry to use the current "
                "process context.\n"
                "       2) If the policy does not support MCS/MLS then the "
                "NULL level entry\n          should be selected."
                "\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[user]", (char **)&user);
    get_config_entry("[raw_context]", &fromcon);
    if ((strcmp(fromcon, "NULL")) == 0)
        fromcon = NULL;
    get_config_entry("[level]", (char **)&level);
    if ((strcmp(level, "NULL")) == 0)
        level = NULL;

    printf("get_default_context_with_level(%s, %s, %s, newcon);\n",
                                                        user, level, fromcon);

    if ((rc = get_default_context_with_level(user, level, fromcon,
                                                    &newcon)) != 0) {
		printf("Could not retrieve a default context based on level.\n");
        perror("get_default_context_with_level - ERROR");
        free(fromcon);
        exit(1);
    }

    printf("The returned default context is: \n\t%s\n", newcon);

    freecon(fromcon);
    freecon(newcon);
    exit(0);
}
