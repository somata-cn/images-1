#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <keyutils.h>
#include <linux/keyctl.h>  /* Has the KEYCTL_GET_SECURITY defined */
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    security_context_t context;
    key_serial_t key_serial;
    char key_type[] = "user";
    char key_description[] = "nbtest:mykey";
    char my_key[] = "hello world";
	char lsm_security_context[256];

#ifdef INFO
    printf("\nThe setkeycreatecon example requires a context to be selected "
                "for a new key\nthat will be created during the test. "
                "The new key is created with the following\nparameters:\n\t"
                "key_type = %s\n\tkey_description = %s\n\tmy_key = %s\n\n"
                "To check the setkeycreatecon results, a key_request call "
                "is issued. The key\ncontext is then retrieved using "
				"keyctl(KEYCTL_GET_SECURITY, ..) and displayed.\n"
				"\nThe key is then revoked (keyctl_revoke) and "
                "then another key_request call is\nissued to check that "
                "it has been removed (i.e. the request should fail).\n",
				key_type, key_description, my_key);

	printf("\nThere is a setkeycreatecon_example.conf module in the 'modules' "
				"directory that\nwill set auditallow statements so that the "
				"audit log will show the sequence\nof events."
				"\nPress return to continue\n");
	getchar();
#endif

	printf("\nExecuting: getkeycreatecon_raw(&context)\n");
    if ((rc = getkeycreatecon_raw(&context)) == -1) {
        printf("Failed to obtain context\n");
        perror("getkeycreatecon_raw - ERROR");
        exit(1);
    }
	printf("The keycreate context is:\n\t%s\n", context);
	printf("Press return to continue\n");
	getchar();
	freecon(context);

    get_config_entry("[raw_context]", &context);

    printf("Executing: setkeycreatecon_raw(%s);\n", context);
    if ((rc = setkeycreatecon_raw(context)) == -1) {
       perror("setkeycreatecon_raw - ERROR");
        exit(1);
    }
    freecon(context);

    printf("\nTo see the setkeycreatecon results, need to issue a "
                "getkeycreatecon call\nbefore it gets reset to NULL by the "
                "next 'execv*' function call.\n\n");

    if ((rc = getkeycreatecon_raw(&context)) == -1) {
        printf("Failed to obtain context\n");
        perror("getkeycreatecon_raw - ERROR");
        exit(1);
    }
    if (!context) {
        printf("No context has been set (NULL returned)\n");
        exit(1);
    }
    printf("The keycreatecon context is now:\n\t%s\n\n", context);
    freecon(context);

    printf("Adding key     - ");
	if ((key_serial = add_key(key_type, key_description, my_key,
	                    sizeof(my_key), KEY_SPEC_USER_KEYRING)) == -1) {
		perror("\nadd_key - ERROR");
		exit(1);
	}
    printf("returned serial number is: %d\n", key_serial);

    printf("Requesting key - ");
    if ((key_serial = request_key(key_type, key_description, NULL,
                                        KEY_SPEC_USER_KEYRING)) == -1) {
		perror("\nrequest_key - ERROR");
		exit(1);
	}
    printf("returned serial number is: %d\n", key_serial);

    printf("Requesting key security context - ");
	if ((rc = keyctl(KEYCTL_GET_SECURITY, key_serial, lsm_security_context,
									sizeof(lsm_security_context))) == -1) {
		perror("\nkeyctl(KEYCTL_GET_SECURITY) - ERROR");
		exit(1);
	}
	printf("returned LSM security_context is: \n\t%s\n", lsm_security_context);

    printf("\nNow revoking key\n");
    if (keyctl_revoke(key_serial) == -1) {
		perror("\nkeyctl_revoke - ERROR");
		exit(1);
    }
    printf("Re-requesting key (should FAIL as revoked)\n");
     if ((key_serial = request_key(key_type, key_description,
                                    NULL, KEY_SPEC_USER_KEYRING)) == -1)
		printf("request_key FAILED - That is correct operation as key has "
                                    "been revoked:\n\t%s\n", strerror(errno));
    else
        printf("Should not happen as revoked!! - key serial number is: %d\n",
																key_serial);

    exit(0);
}
