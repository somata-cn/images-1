#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc;
    security_context_t context;

#ifdef INFO
    printf("\nThe getfscreatecon example will retrieve and display the context "
                    "used for\ncreating a new file system object.\nIt is "
                    "normally 'null' unless it has been set by "
                    "setfscreatecon.\nPress return to continue\n");
	getchar();
#endif

    printf("Executing: getfscreatecon_raw(&context);\n");

    if ((rc = getfscreatecon_raw(&context)) == -1) {
        printf("Failed to obtain context\n");
        perror("getfscreatecon_raw - ERROR");
        exit(1);
    }
    if (context) {
        printf("The returned context is:\n\t%s\n", context);
        freecon(context);
    } else
        printf("No context has been set (null) returned\n");
    exit(0);
}
