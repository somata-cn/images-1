#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <selinux/selinux.h>
#include <selinux/get_context_list.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    const char *user;
    security_context_t fromcon;
    security_context_t *list;
    int n, i;

#ifdef INFO
    printf("\nThe get_ordered_context_list example requires a user and "
				"context to be\nselected. An ordered list of reachable "
				"contexts for the user is then\nobtained and displayed with "
				"the number of returned entries.\nSelect the context NULL "
				"entry to use the current process context."
				"\nPress return to continue\n");

    getchar();
#endif

    get_config_entry("[user]", (char **)&user);
    get_config_entry("[raw_context]", &fromcon);
    if ((strcmp(fromcon, "NULL")) == 0)
        fromcon = NULL;

    printf("Executing: get_ordered_context_list(%s, %s, &list);\n",
                                                            user, fromcon);

     if ((n = get_ordered_context_list(user, fromcon, &list)) <= 0) {
		printf("Could not retrieve a list of contexts.\n");
        perror("get_ordered_context_list - ERROR");
        freecon(fromcon);
        exit(1);
    }

    printf("Returned %d context entries:\n", n);
    for (i = 0; i < n; i++)
        printf("\tContext %d = %s\n", i+1, list[i]);

    freecon(fromcon);
    freeconary(list);
    exit(0);
}
