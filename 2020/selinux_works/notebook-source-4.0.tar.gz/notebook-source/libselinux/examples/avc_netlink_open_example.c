#include <stdio.h> 
#include <stdlib.h> 
#include <stdarg.h> 
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <libaudit.h>
#include <selinux/selinux.h> 
#include <selinux/avc.h> 

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

/* show callback messages on screen in red and thread/signal in green */
static char red[] = "\033[0;31m";
static char green[] = "\033[0;32m";
static char reset[] ="\033[0m";

/* audit file descriptor */
static int audit_fd;

/* Internal functions */
static int cb_log(int type, const char *fmt, ...);
static int cb_setenforce(int enforcing);
static int cb_policyload(int seqno);
static void * netlink_thread(void * arg);
/* End internal functions */



int main(int argc, char **argv) 
{ 
    security_context_t scon, tcon; 
	security_class_t tclass;
	access_vector_t requested, denied, audited;
	struct av_decision avd_buf, *avd;
    avd = &avd_buf;
    mode_t mode;
    char buf[80]; 
	union selinux_callback callback_info;
	pthread_t thread;
	int rc, netlink_fd;
	char message[MAX_AUDIT_MESSAGE_LENGTH];
	char *result = NULL;

#ifdef INFO
    printf("\nThe avc_netlink_open example makes use of the avc_netlink "
            "functions to show that\nthey can be used without implementing "
            "using avc_open, avc_has_perm etc.\n\nThe example requires a "
            "context and file or directory name to be selected.\n"
            "The security_compute_av_raw call will then be used to determine "
            "whether the\nfile has execute permission or not.\n\nThe example "
            "will then ask whether to quit ('q') or return to request "
            "another\nfile name.\n\nNote that all logging information is "
			"written to the audit log immediately and\nwill have the 'type=' "
			"set to 'TRUSTED_APP'.\n");

	printf("\nNotes 1) If NULL is selected for the source context, then a "
			"getcon will be\n         called and the current process context "
			"will be used.\n"
			"      2) The example uses a number of other functions that are "
			"listed below.\nPress return to continue\n");
	getchar();

	printf("pthread_create\n    Set up a thread to run avc_netlink_loop.\n"
			"\navc_netlink_loop\n    Process netlink messages as they arrive."
            "\n\nselinux_set_callback, selinux_get_callback\n    Used to "
            "set/get the following callbacks: SELINUX_CB_SETENFORCE,"
			"\n    SELINUX_CB_LOG and SELINUX_CB_POLICYLOAD\n"
			"\navc_netlink_open\n    Open netlink in blocking mode.\n"
			"\navc_acquire_netlink_fd\n    Get netlink fd.\n"
			"\naudit_open\n    Open the audit log.\n"
			"\naudit_log_user_avc_message\n    Write entry into audit log."
			"\nPress return to continue\n");
	getchar();

	printf("security_getenforce\n    Checks enforcement mode.\n"
			"getcon\n    Get current context if NULL is selected.\n"
			"\nstring_to_security_class, security_class_to_string"
			"\n    Get file class ID/string.\n"
			"\nstring_to_av_perm, security_av_string"
			"\n    Get execute permission ID/string.\n");

	printf("\ngetfilecon\n    Retrieve the file context (if it exists)."
			"matchpathcon\n    Get the context from the file_contexts file "
			"if the file does not exist\n    (note that this loads the "
			"file_context file and therefore adds a delay).\n"
			"\nsecurity_compute_av_raw\n    Check if execute "
			"permission is allowed on the file.\n"
			"\navc_netlink_release_fd, avc_netlink_close and audit_close.\n"
			"    Close all fd's.\nPress return to continue\n");
	getchar();
#endif

	/* Setting up callback routines */

	/*
	 * The SELINUX_CB_LOG callback is required to write AVC messages
	 * to an audit log. If not set then output is to stderr.
	 */
	printf("Executing: selinux_set_callback(SELINUX_CB_LOG, cb_log);\n");

    selinux_set_callback(SELINUX_CB_LOG, (union selinux_callback)cb_log);


	/* This callback is optional and used whenever enforcing mode changes. */
	printf("Executing: selinux_set_callback(SELINUX_CB_SETENFORCE, "
													"cb_setenforce);\n");
    selinux_set_callback(SELINUX_CB_SETENFORCE, 
								(union selinux_callback)cb_setenforce);

	/* This callback is optional and used whenever the policy is loaded. */
	printf("Executing: selinux_set_callback(SELINUX_CB_POLICYLOAD, "
													"cb_policyload);\n");
	selinux_set_callback(SELINUX_CB_POLICYLOAD, 
								(union selinux_callback)cb_policyload);

	/*
	 * Only executing one selinux_get_callback as it will return an address
	 * because a valid default libselinux routine is present at start-up. The 
	 * only time the address is invalid is when an invalid 'type' is requested.
	 */
	printf("Executing: selinux_get_callback(SELINUX_CB_SETENFORCE);\n");
	callback_info = selinux_get_callback(SELINUX_CB_SETENFORCE);
	if (callback_info.func_setenforce == NULL) {
		printf("selinux_get_callback(SELINUX_CB_SETENFORCE) - ERROR %s\n", 
                                                            strerror(errno));
		exit(1);
	}


	/* Open an audit fd as the standard audit log will be used. */
	printf("Executing: audit_fd = audit_open();\n");
    if ((audit_fd = audit_open()) < 0) {
    	printf("audit_open - ERROR %s\n", strerror(errno));
        exit(1);
    }

    /* This checks whether SELinux is in enforcing mode or not. */
    if (security_getenforce() == 1)
        printf("\nSELinux is currently in Enforcing mode\n");
    else 
        printf("\nSELinux is currently in Permissive mode\n");
    
    /* Open netlink with BLOCKING set */
	printf("Executing: avc_netlink_open(0); - in BLOCKING mode\n");
    if (avc_netlink_open(0) < 0) {
        printf("avc_netlink_open - ERROR %s\n", strerror(errno));
        exit(1);
    }

	printf("Executing: avc_netlink_acquire_fd();\n");
    netlink_fd = avc_netlink_acquire_fd();
    printf("netlink_fd = %d\n", netlink_fd);

	printf("\nCreating thread to run avc_netlink_loop\n");
	pthread_create(&thread, NULL, netlink_thread, NULL);

	printf("\nPress return to continue\n");
	getchar();

	/* Let user select a context to use */
    get_config_entry("[raw_context]", &scon);
	/* If NULL then get the current process context */ 
	if (strcmp(scon, "NULL") == 0) {
		printf("\nExecuting: getcon_raw(&scon);\n");
    	if (getcon_raw(&scon) < 0) { 
        	printf("getcon_raw - ERROR %s\n", strerror(errno));
        	avc_destroy(); 
        	exit(1); 
    	} 
	}


	/* 
	 * Note it is recommended that the string_to_security_class and 
	 * string_to_av_perm calls are used. This is because they will always
	 * retrieve the correct values whereas the flask entries may not always
	 * be correct.
	 */
	/* Get the class id for a file object */
	printf("\nExecuting: string_to_security_class(\"file\");\n");
    if ((tclass = string_to_security_class("file")) != 0)
        printf("\tThe value assigned to the \"file\" class is: %d\n", tclass);
    else 
        printf("string_to_security_class - ERROR %s\n", strerror(errno));
	/* Then get the permission bit for 'execute'.*/
	printf("Executing: string_to_av_perm(tclass, \"execute\");\n");
    if ((requested = string_to_av_perm(tclass, "execute")) != 0)
        printf("\tThe permission bit for \"execute\" is: 0x%08x\n", requested);
    else 
        printf("string_to_av_perm - ERROR %s\n", strerror(errno));

    /* Read file or directory name from stdin */
    while (1) { 
        printf("\nEnter a file or directory name: ");
		fflush(stdin);
		memset(buf, 0, sizeof(buf));
        fgets(buf, sizeof(buf), stdin);
		/* Remove the cr */
		buf[strlen(buf)-1] = 0;  

        /* 
		 * Get security context and SID for the file. Note that getfilecon 
		 * retrieves the context of a file that physically exists. If it
		 * does not exist then matchpathcon is called to see what context
		 * would be applied if it did.
		 */
		printf("\nExecuting: getfilecon_raw(%s, &tcon);\n", buf);
        if (getfilecon_raw(buf, &tcon) < 0) { 
            printf("\tgetfilecon_raw - Could not retrieve file context for "
                    "'%s'\n\tERROR: %s\n", buf, strerror(errno));

			mode = 0;
			printf("Therefore executing: matchpathcon(%s, 0x%x, &tcon);\n\n", 
																buf, mode);
    		if ((rc = matchpathcon(buf, mode, &tcon)) != 0) {
            	printf("\tmatchpathcon - Could not retrieve file context for "
								"'%s'\n\tERROR: %s\n", buf, strerror(errno));
            	continue; 
			}
		} 


		printf("\nExecuting: security_compute_av_raw(scon, tcon, tclass, "
											"requested, avd);\n");
        rc = security_compute_av_raw(scon, tcon, tclass, requested, avd);
    	/* Print class and permissions */    
    	printf("\nFor source context: %s\n    target context: %s\n"
            "        with class: file\n", scon, tcon);

		printf("and requested permissions of:\n\t");
		print_access_vector(tclass, requested);

		/* Now get the actual denied permissions */
		denied = requested & ~avd->allowed;
		audited = denied ? (denied & avd->auditdeny) : 
                                                (requested & avd->auditallow);
		printf("\nthe request would be: %s\n", 
							(denied || !requested) ? "DENIED" : "GRANTED");

		security_av_string(tclass, audited, &result);

		if (audited) {
			/* Add the supplemental audit information so that it is logged. */
    	    sprintf(message, "uavc: %s %s by Sample OM - Checking "
					"file: %s scontext=%s tcontext=%s "
                    "tclass=%s ", denied ? "denied" : "granted", result, buf, 
                    scon, tcon, security_class_to_string(tclass));

			printf("Executing: audit_log_user_avc_message();\n");
			if ((rc = audit_log_user_avc_message(audit_fd, AUDIT_TRUSTED_APP, 
										message, NULL, NULL, NULL, 0)) <= 0) {
				fprintf(stderr, "audit_log_user_avc_message - ERROR %s\n", 
												strerror(errno));
    		}
			printf("Audit Log entry:\n%s%s%s\n", denied ? red : green, 
                                                            message, reset);
		}
		free(result);

		/* Now see if to continue or not */
        printf("\nPress 'q' for quit or return to continue.\n");
		fflush(stdin);
		memset(buf, 0, sizeof(buf));
        fgets(buf, sizeof(buf), stdin);
		if (buf[0] == 'q') {
			/* Free all resources */
			avc_netlink_release_fd();
			avc_netlink_close();
			audit_close(audit_fd);
		    exit(0); 
    	}
	} 
	/* Free all resources */
	avc_netlink_release_fd();
	avc_netlink_close();
	audit_close(audit_fd);
    exit(0); 
} 




			/******** Start callback routines **********/
/*
 * This callback (SELINUX_CB_LOG) is invoked whenever an audit event needs to 
 * be logged. The callback is really mandatory to write messages to an audit 
 * log. This example uses the audit_log_user_avc_message to write events to 
 * the standard audit log, if required a different log file could be used.
 */ 
static int cb_log(int type, const char *fmt, ...)
{
    va_list ap;
    char message[MAX_AUDIT_MESSAGE_LENGTH];
    int rc, audit_type;

		/******************* Do your processing here *****************/
	/*
	 * The 'type' code passed to the logging callback will be one of these:
	 * 		#define SELINUX_ERROR		0
	 * 		#define SELINUX_WARNING		1
	 * 		#define SELINUX_INFO		2
	 * 		#define SELINUX_AVC		    3
	 *
	 * The audit_type entry required by the audit_log_user_avc_message call
	 * is then selected from messages available for the audit library
	 * contained in <libaudit.h>.
	 */
    switch (type) {
        case SELINUX_ERROR:
        	audit_type = AUDIT_USER_SELINUX_ERR;
        break;
        case SELINUX_WARNING:
        	audit_type = AUDIT_USER_AVC;
        break;
        case SELINUX_INFO:
        	audit_type = AUDIT_USER_AVC;
    	break;
        case SELINUX_AVC:
        	audit_type = AUDIT_USER_AVC;
    	break;
        default:
        	audit_type = AUDIT_USER_AVC;
	    break;
    }

    va_start(ap, fmt);
    vsnprintf(message, MAX_AUDIT_MESSAGE_LENGTH, fmt, ap);

	if ((rc = audit_log_user_avc_message(audit_fd, audit_type, message, 
												NULL, NULL, NULL, 0)) <= 0) {
		fprintf(stderr, "%saudit_log_user_avc_message - ERROR %s %s\n", 
												red, strerror(errno), reset);
    	va_end(ap);
		return (-1);
	}
 	else {  
	    va_end(ap);
	    return 0;
	}
}


/*
 * This callback (SELINUX_CB_SETENFORCE) is invoked whenever the enforcement
 * mode changes. 
 * 
 * The enforcing argument is set to either 0 (permissive) or 1 (enforcing).
 * Note: When switched to Permissive mode, the AVC cache is not reset.
 */
static int cb_setenforce(int enforcing)
{
		/******************* Do your processing here *****************/
	/* NOTE: This function just writes a message to audit log and stderr. */
	char message[MAX_AUDIT_MESSAGE_LENGTH];
	int rc;

    sprintf(message, "Received setenforce notice via the %s callback "
						"function. SELinux set to %s", __FUNCTION__, 
						enforcing ? "ENFORCING mode" : "PERMISSIVE mode.");

	if ((rc = audit_log_user_avc_message(audit_fd, AUDIT_TRUSTED_APP, 
								message, NULL, NULL, NULL, 0)) <= 0) {
		fprintf(stderr, "%saudit_log_user_avc_message - ERROR %s %s\n", 
										red, strerror(errno), reset);
		return (-1);
	}
    fprintf(stderr, "\n%s%s%s\n", red, message, reset);
    return 0;
}



/*
 * This callback (SELINUX_CB_POLICYLOAD) is invoked whenever the system  
 * security  policy is reloaded. The seqno argument is the sequence number 
 * generated by the SELinux security server.
  */
static int cb_policyload(int seqno)
{
		/******************* Do your processing here *****************/
	/* NOTE: This function just writes a message to audit log and stderr. */
	char message[MAX_AUDIT_MESSAGE_LENGTH];
	int rc;

    sprintf(message, "Received policy reload notice via the %s callback "
						"function. seqno = %d", __FUNCTION__, seqno);

	if ((rc = audit_log_user_avc_message(audit_fd, AUDIT_USER_MAC_POLICY_LOAD, 
								message, NULL, NULL, NULL, 0)) <= 0) {
		fprintf(stderr, "%saudit_log_user_avc_message - ERROR %s %s\n", 
										red, strerror(errno), reset);
		return (-1);
	}
    fprintf(stderr, "\n%s%s%s\n", red, message, reset);
    return 0;
}
				/******** End callback routines **********/

		/******** Insert thread or signal handler routine **********/
/*
 * Use avc_netlink_check_nb (with signal handler) or avc_netlink_loop (with
 * thread handler to allow the policy load and policy enforcement events to
 * be processed by the relevant callback functions.
 */
static void * netlink_thread(void * arg)
{
/* 
 * avc_netlink_loop enters a loop blocking on the netlink socket and processes
 * messages as they are received. This function will not return unless an 
 * error occurs  on the socket, in which case the socket is closed. 
 */
	fprintf(stderr, "\n%sExecuting: avc_netlink_loop(); at %s%s\n", 
												green, __FUNCTION__, reset);

	/* Blocks here to process policy load and enforcement status events */
	avc_netlink_loop();

	return 0;
}
			/******** End thread or signal handler routine **********/
