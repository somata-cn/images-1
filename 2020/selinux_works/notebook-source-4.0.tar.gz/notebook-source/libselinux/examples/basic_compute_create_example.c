#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <limits.h>
#include <selinux/selinux.h>

/* selinuxfs mount point */
extern char *selinux_mnt;

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

/* If tclass = 0 or any invalid number takes no notice !!! */

int main(int argc, char **argv)
{
    security_context_t scon;
    security_context_t tcon;
    security_class_t tclass;
    security_context_t newcon;
    int selinux_page_size = sysconf(_SC_PAGE_SIZE);
	char path[PATH_MAX];
	char *buf;
	int fd, rc;
    char *string;

    printf("The basic_compute_create example requires a source and target "
                "context, plus a\nclass entry to be selected."
                "\nPress return to continue\n");
    getchar();
    get_config_entry("[raw_context]", &scon);
    get_config_entry("[raw_context]", &tcon);
    get_config_entry("[class]", &string);
    tclass = string_to_security_class(string);
    free(string);

    sprintf(path, "%s/create", selinux_mnt);
	if ((fd = open(path, O_RDWR)) < 0) {
	    perror("OPEN FAILED");
	    exit(1);
	}

    if ((buf = malloc(selinux_page_size)) == NULL) {
	    perror("MALLOC FAILED");
	    exit(1);
	}

	snprintf(buf, selinux_page_size, "%s %s %hu", scon, tcon, tclass);
	printf("About to write scon, tcon, class to \n%s:\n\t%s %s %hu\n\n",
													path, scon, tcon, tclass);
	if ((rc = write(fd, buf, strlen(buf))) < 0) {
	    perror("WRITE FAILED");
	    exit(1);
	}

	memset(buf, 0, selinux_page_size);

	if ((rc = read(fd, buf, selinux_page_size - 1)) < 0) {
	    perror("READ FAILED");
	    exit(1);
	}

	if ((newcon = strdup(buf)) == NULL) {
		printf("No context returned\n");
		exit(1);
	}
	printf("Returned context is: %s\n\n", newcon);

	free(buf);
	close(fd);
	exit(0);
}
