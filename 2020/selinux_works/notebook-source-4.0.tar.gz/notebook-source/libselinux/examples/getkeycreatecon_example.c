#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc;
    security_context_t context;

#ifdef INFO
    printf("\nThe getkeycreatecon example will retrieve and display the context"
                    " used for\ncreating a new kernel key.\nIt is "
                    "normally 'null' unless it has been set by "
                    "setkeycreatecon.\nPress return to continue\n");
	getchar();
#endif

    printf("Executing: getkeycreatecon_raw(&context);\n");

    if ((rc = getkeycreatecon_raw(&context)) == -1) {
        printf("Failed to obtain context\n");
        perror("getkeycreatecon_raw - ERROR");
        exit(1);
    }

    if (context) {
        printf("The returned context is:\n\t%s\n", context);
        freecon(context);
    } else
        printf("No context has been set (null) returned\n");

    exit(0);
}
