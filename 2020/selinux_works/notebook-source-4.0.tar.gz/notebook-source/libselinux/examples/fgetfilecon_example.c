#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc, fd;
    security_context_t context;
    char *path;

    printf("\nThe fgetfilecon function can return the context of any valid "
    "file\ndescriptor as shown by displaying stdin, stdout & stderr:\n\n");

    if ((rc = fgetfilecon_raw(STDIN_FILENO, &context)) == -1) {
        perror("fgetfilecon for stdin - ERROR");
        exit(1);
    }
    printf("The context assigned to stdin is:\n\t%s\n", context);

    if ((rc = fgetfilecon_raw(STDOUT_FILENO, &context)) == -1) {
        perror("fgetfilecon for stdout - ERROR");
        exit(1);
    }
    printf("The context assigned stdout is:\n\t%s\n", context);

    if ((rc = fgetfilecon_raw(STDERR_FILENO, &context)) == -1) {
        perror("fgetfilecon for stderr - ERROR");
        exit(1);
    }
    printf("The context assigned stderr is:\n\t%s\n", context);

#ifdef INFO
    printf("\nThe fgetfilecon example now requires a file or directory to be "
                "selected.\nThis file will then opened to obtain a file "
                "descriptor that will be used by\nfgetfilecon to obtain the "
                "files context using the fgetxattr(2) system call. The\n"
				"context length is also returned and displayed.\nIf extended "
                "attributes are not supported, then errno = ENOTSUP "
                "(Operation not\nsupported) is returned."
                "\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[path]", &path);


    if ((fd = open(path, O_RDONLY)) == -1) {
        printf("Cannot open %s\n", path);
        perror("file open - ERROR");
        exit(1);
    }

    printf("\nOpened file: %s\n", path);
    printf("\nNow obtaining the file context via fgetfilecon:\n");
    if ((rc = fgetfilecon_raw(fd, &context)) == -1) {
        perror("fgetfilecon - ERROR");
        exit(1);
    }
    printf("The \"security.selinux\" xattr context assigned to the file "
                            "is:\n\t%s length: %d\n", context, rc);
    close(fd);
    freecon(context);
    free(path);
    exit(0);
}
