#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    security_context_t context;
    char *media;

#ifdef INFO
    printf("The matchmediacon example requires a media device entry to be "
                    "selected.\nThe function will then read the policy "
                    "'contexts/files/media' file for a\nmatching entry. "
                    "The returned context is not validated.\n"
                    "Press return to continue\n");
    getchar();
#endif

    get_config_entry("[device]", &media);

    printf("\nExecuting: matchmediacon(%s, &context)\n", media);
    if ((rc = matchmediacon(media, &context)) == -1) {
        printf("Entry not found - ERROR %s\n", strerror(errno));
        exit(1);
    }
    printf("The context assigned to the media is:\n\t%s\n", context);
    freecon(context);
    free(media);
    exit(0);
}
