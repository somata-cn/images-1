#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/socket.h>
#include <selinux/selinux.h>

#define MAXBUFFERSIZE 256

int main(int argc, char *argv [])
{
	int rc, sock_fd, bytes_received;
	char buffer[MAXBUFFERSIZE];
	struct addrinfo hints;
	struct addrinfo *result, *ptr;
	security_context_t context;
	security_context_t peer_context;
	char *peer_context_str;
    char red[] = "\033[0;31m";
    char green[] = "\033[0;32m";
    char reset[] ="\033[0m";

	if (argc != 3) {
		fprintf(stderr,"usage: %s <hostname> <port> "
		            "(Use port 9999 for secure port test)\n", argv[0]);
		exit(1);
	}

	/* Obtain address matching host/port */
	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = AF_UNSPEC;        /* Allow IPv4 or IPv6 */
	hints.ai_socktype = SOCK_STREAM;    /* Stream socket */
	hints.ai_flags = 0;
	hints.ai_protocol = 0;              /* Any protocol */

	rc = getaddrinfo(argv[1], argv[2], &hints, &result);
	if (rc != 0) {
	    printf("getaddrinfo - ERROR: %s\n", gai_strerror(rc));
	    exit(1);
	}

	/*
     * getaddrinfo() returns a list of address structures. Try each address
     * until connection. If fail close the socket and try the next address.
     */
	printf("\nNote that on socket open there is no peer context (however, "
                    "for the Reference\nPolicy this is normally set to "
                    "'unlabeled_t' for the open):\n");
	for (ptr = result; ptr != NULL; ptr = ptr->ai_next) {
	    sock_fd = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);
    	if (sock_fd == -1)
	    	continue;

        /* Show peer context if available (should not be until connect) */
	    if ((rc = getpeercon_raw(sock_fd, &peer_context)) < 0)
		    printf("   socket open - No Peer Context Available\n\n");
	    else {
		    printf("   socket open - Peer Context: %s\n\n", peer_context);
		    freecon(peer_context);
	    }

	    if (connect(sock_fd, ptr->ai_addr, ptr->ai_addrlen) != -1)
	    	break;		/* Success */

        close(sock_fd);
	}

    /* No address succeeded */
	if (ptr == NULL) {
	    printf("Could not connect as no server found.\nNeed to run "
                    "getpeercon_server_example in another virtual terminal "
                    "or on another networked system as follows:\n"
                    "\n\tgetpeercon_server_example <port>\n\n");
	    exit(1);
	}

    /* Free the address structures */
	freeaddrinfo(result);

    /* Now have a connection so check peer context */
    /* Show peer context if available */
    printf("If 'netlabelctl' has been used to set a valid peer context, then "
                "it will\nnow be displayed as a connection to the server has "
                "been established:\n");
	if ((rc = getpeercon_raw(sock_fd, &peer_context)) < 0)
		printf("   connect received - No Peer Context Available\n\n");
	else {
		printf("   connect received - Peer Context: %s\n\n", peer_context);
		freecon(peer_context);
	}

	/* clear the buffer */
	memset(buffer, 0, sizeof(buffer));
	if ((bytes_received = recv(sock_fd, buffer, MAXBUFFERSIZE-1, 0)) == -1) {
		perror("Client recv - ERROR");
		exit(1);
	}

    printf("Receiving data from server:\n");
	buffer[bytes_received] = '\0'; /* Add null at end of line. */
	printf("%sServer Information in RED:\n", red);
	printf("%s \n", buffer);


	/* Print the Clients context information */
	if ((rc = getcon_raw(&context)) < 0) {
		perror("getcon_raw - ERROR");
		exit(1);
	}

	if ((rc = getpeercon_raw(sock_fd, &peer_context)) < 0)
		peer_context_str = strdup ("No Peer Context Available");
	else {
		peer_context_str = strdup(peer_context);
		freecon(peer_context);
	}
	printf("%sClient Information in GREEN:\n", green);
	printf("Client Context: %s\nClient Peer Context: %s\n",
	                                    context, peer_context_str);
	freecon(context);
	close(sock_fd);
	printf("%s\n", reset);
	exit(0);
}
