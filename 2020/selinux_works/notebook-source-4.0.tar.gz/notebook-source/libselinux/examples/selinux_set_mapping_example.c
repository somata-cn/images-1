#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <selinux/selinux.h>
#include <selinux/flask.h>
#include <selinux/av_permissions.h>

/*
 * selinux_set_mapping sets up a multi-dimensional array (see the
 * "static struct security_class_mapping map[]" definition below) as follows:
 *
 *      Object Classes are allocated consecutive numbers (1, 2, 3 etc.) in the
 *      order they are listed in the array (hence "file" = 1).
 *
 *      Permissions are allocated numbers to power 2 (1, 2, 4, 8 etc.) in the
 *      order they are listed in the array for the object class they are
 *      allocated against (hence "execute" = 1, "read" = 2 etc.).
 *      These finally form a bit wise set of permissions (a maximum of 32
 *      permissions per object class at present).
 *
 * Important - The structure defined below MUST BE named as shown, otherwise
 * various errors such as "error: array type has incomplete element type" will
 * be given when compiling this sample (as libselinux has this defined in
 * selinux.h).
 */
static struct security_class_mapping map[] = {
    { "file",           /* "file" object class ID will be 1 */
        { "execute",    /* "execute" permission 0x00000001  */
          "read",       /* "read" permission    0x00000002  */
          "write",      /* "write" permission   0x00000004  */
          NULL } },     /* End of FILE object class definition for this OM */
     { NULL }			/* End of mapping definitions */
};

#define MAP_FILE_CLASS		1
#define MAP_FILE_EXECUTE	0x00000001UL
#define MAP_FILE_READ		0x00000002UL
#define MAP_FILE_WRITE		0x00000004UL


int main(int argc, char **argv)
{
    security_class_t tclass;
    const char *str = NULL;
    access_vector_t av_perm;
    char *result = NULL;
    int rc;

#ifdef INFO
    printf("\nThe selinux_set_mapping example will display the "
				"\"file\" class ID (tclass) and\nread, write, execute "
				"permissions before the selinux_set_mapping is called using\n"
				"the class/permission conversion functions."
				"\nPress return to continue\n");
	getchar();
#endif

	printf("Class ID (tclass) and permission bits BEFORE calling "
				"selinux_set_mapping.\nThese will follow the order defined "
				"by the loaded policy:\n");

	printf("\n------ Security Classes / Permissions Before Mapping --------\n");


	printf("\nExecuting: string_to_security_class(file)\n");
	tclass = string_to_security_class("file");
	if (tclass == 0)
		perror("string_to_security_class - ERROR");
	else
		printf("The 'file' class ID defined in policy is: 0x%04x\n", tclass);

	printf("\nExecuting: security_class_to_string(0x%04x)\n", tclass);
    if ((str = security_class_to_string(tclass)) == NULL)
		perror("security_class_to_string - ERROR");
	else
		printf("The class requested is: %s\n", str);

	printf("\nExecuting: string_to_av_perm(0x%04x, execute);\n", tclass);
	av_perm = string_to_av_perm(tclass, "execute");
	if (av_perm == 0)
		perror("string_to_av_perm - ERROR");
	else
		printf("The execute permission for 'file' class ID: 0x%08x\n", av_perm);

	printf("\nExecuting: security_av_perm_to_string(0x%04x, 0x%08x)\n",
															tclass, av_perm);
    if ((str = security_av_perm_to_string(tclass, av_perm)) == NULL)
        perror("security_av_perm_to_string - ERROR");
	else
        printf("The requested permission is: %s\n", str);

	/* Set av_perm to execute | read | write and display string */
	av_perm = FILE__EXECUTE | FILE__READ | FILE__WRITE;

	printf("\nExecuting: security_av_string(0x%04x, 0x%08x)\n",
															tclass, av_perm);
    if ((rc = security_av_string(tclass, av_perm, &result)) == 0) {
        printf("The permission strings requested are for class %s are: %s\n",
                                    security_class_to_string(tclass), result);
        free(result);
    } else
		perror("security_av_string - ERROR");

	printf("--------------- SELINUX_SET_MAPPING --------------------------\n");
	printf("Press return to continue\n");
	getchar();

    printf("\nExecuting: selinux_set_mapping(map);\n");
    if (selinux_set_mapping(map) < 0) {
        perror("selinux_set_mapping - ERROR");
        if (errno == EINVAL) {
            printf("Invalid object class mapping\n");
            exit(1);
        }
        printf("Could not set up the object class mapping\n");
        exit(1);
    }
	printf("The selinux_set_mapping is complete.\n\n");


	printf("\n------ Security Classes / Permissions After Mapping --------\n");
	printf("\nPress return to continue\n");
	getchar();

	printf("Executing: string_to_security_class(file)\n");
	tclass = string_to_security_class("file");
	if (tclass == 0)
		perror("string_to_security_class - ERROR");
	else
		printf("The 'file' class ID defined in policy is: 0x%04x\n", tclass);

	printf("\nExecuting: security_class_to_string(0x%04x)\n", tclass);
    if ((str = security_class_to_string(tclass)) == NULL)
		perror("security_class_to_string - ERROR");
	else
		printf("The class requested is: %s\n", str);

	printf("\nExecuting: string_to_av_perm(0x%04x, execute);\n", tclass);
	av_perm = string_to_av_perm(tclass, "execute");
	if (av_perm == 0)
		perror("string_to_av_perm - ERROR");
	else
		printf("The execute permission for 'file' class ID: 0x%08x\n", av_perm);

	printf("\nExecuting: security_av_perm_to_string(0x%04x, 0x%08x)\n",
															tclass, av_perm);
    if ((str = security_av_perm_to_string(tclass, av_perm)) == NULL)
        perror("security_av_perm_to_string - ERROR");
	else
        printf("The requested permission is: %s\n", str);

	/* Set av_perm to execute | read | write and display string */
	av_perm = MAP_FILE_EXECUTE | MAP_FILE_READ | MAP_FILE_WRITE;
	printf("\nExecuting: security_av_string(0x%04x, 0x%08x)\n", tclass, av_perm);
    if ((rc = security_av_string(tclass, av_perm, &result)) == 0) {
        printf("The permission strings requested are for class %s are: %s\n",
                                    security_class_to_string(tclass), result);
        free(result);
    } else
		perror("security_av_string - ERROR");

	exit(0);
}
