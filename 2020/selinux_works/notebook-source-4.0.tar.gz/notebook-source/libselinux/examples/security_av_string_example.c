#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    char *result = NULL;
    int rc;
    security_class_t tclass;
    access_vector_t av_perm;
    char *string;

#ifdef INFO
    printf("\nThe security_av_string example requires a class string and one "
                "or more\npermission bits to be selected. The function will "
                "then return the permission\nstrings.\n"
                "\nNotes 1) The class string is requested that is then "
				"converted to the\n         appropriate class ID by the "
				"string_to_security_class function.\n"
				"\n      2) All the selected permission bits must be valid "
				"otherwise 'invalid\n         argument' is returned."
				"\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[class]", &string);
	/* Convert the string to a class id. Do not check so invalid can be used. */
    tclass = string_to_security_class(string);
    free(string);

    get_config_entry("[perms_av]", &string);
	/* Convert the selected permission bits string */
    av_perm = strtoll(string, (char **)&string[8], 16);
    free(string);

    printf("Executing: security_av_string(%d, 0x%08x);\n", tclass, av_perm);

    if ((rc = security_av_string(tclass, av_perm, &result)) == 0) {
        printf("\nThe permission strings requested are: %s\n", result);
        free(result);
    } else
		perror("\nsecurity_av_string - ERROR");

    exit(0);
}
