#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc, sock_fd;
    security_context_t context;

#ifdef INFO
    printf("\nThe setsockcreatecon example requires a context to be selected "
                "for a new\nsocket that will be created during the test.\n"
				"Once the new socket context has been set, getsockcreatecon "
				"will be called to\ncheck the context. A socket is then "
				"opened and its context checked using the\n'fgetfilecon' "
				"call (as this will check the context of any object "
				"that\nuses a file descriptor and supports xattrs).\n");
    printf("\nFinally getpeercon is called to check the sockets peer context, "
                "however, note\nthat the peer context will be unlabeled_t for "
                "the Reference Policy as no\nconnection has been established "
                "to allow the peer association to be made. This\nis done when "
                "an 'accept(new_sockfd, ...);' system call returns with the "
                "peer\ninfo. See the getpeercon_client/server example for a "
                "netlabel demonstration.\n");
#endif

	printf("\nExecuting: getsockcreatecon_raw(&context)\n");
    if ((rc = getsockcreatecon_raw(&context)) == -1) {
        printf("Failed to obtain context\n");
        perror("getsockcreatecon_raw - ERROR");
        exit(1);
    }
	printf("The sockcreate context is:\n\t%s\n", context);
	printf("Press return to continue\n");
	getchar();
	freecon(context);

    get_config_entry("[raw_context]", &context);

    printf("Executing: setsockcreatecon_raw(%s);\n", context);
    if ((rc = setsockcreatecon_raw(context)) == -1) {
        perror("setsockcreatecon_raw - ERROR");
        exit(1);
    }
    freecon(context);

    printf("\nTo see the setsockcreatecon results, issue a getsockcreatecon "
                "call before it\ngets reset to NULL by the next 'execv*' "
                "function call.\n\n");

    if ((rc = getsockcreatecon_raw(&context)) == -1) {
        printf("Failed to obtain context\n");
        perror("getsockcreatecon_raw - ERROR");
        exit(1);
    }
    if (!context) {
        printf("No context has been set (NULL returned)\n");
        exit(1);
    }

    printf("The sockcreate context is now:\n\t%s\n", context);
    freecon(context);

	if ((sock_fd = socket(PF_INET, SOCK_STREAM, 0)) == -1) {
		perror("Open Socket - ERROR");
		exit(1);
	}
    printf("\nOpened a new socket, so checking if the correct context has been "
                "set using the\nfgetfilecon_raw function.\n");

    if ((rc = fgetfilecon_raw(sock_fd, &context)) == -1) {
        perror("fgetfilecon_raw - ERROR");
        exit(1);
    }
    printf("The context assigned to the new socket is:\n\t%s\n", context);
    freecon(context);

    /*
     * Now get the peer context using getpeercon. Note that the peer context
     * will be unlabeled_t for the Reference Policy as no connection has been
     * made to allow the peer association to be made (This is done when an
     * accept(new_sockfd, ...); system call returns with the peer info).
     */
/* This will use getsockopt to get peer context:
    char buf[256];
	socklen_t size;
    size = sizeof(buf);
    getsockopt(sock_fd, SOL_SOCKET, SO_PEERSEC, buf, &size);
    printf("getsockopt with SO_PEERSEC context is: %s\n", buf);
*/
    printf("\nExecuting: getpeercon_raw(sock_fd, &context);\n");
    if ((rc = getpeercon_raw(sock_fd, &context)) < 0) {
        printf("No peer context available.\n");
        perror("getpeercon_raw - ERROR");
    }
    else {
        printf("The peer context returned by getpeercon is: \n\t%s\n", context);
        freecon(context);
    }
    close(sock_fd);
    exit(0);
}
