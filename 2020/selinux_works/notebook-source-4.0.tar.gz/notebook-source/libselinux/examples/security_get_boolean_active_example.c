#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    char *name;

#ifdef INFO
    printf("\nThe security_get_boolean_active example requires a boolean entry "
                    "to be\nselected. The current status will then be "
                    "displayed.\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[boolean]", &name);

    printf("Executing: security_get_boolean_active(name);\n");

    if ((rc = security_get_boolean_active(name)) == -1) {
        printf("FAILED to get the boolean status for %s\n", name);
        perror("security_get_boolean_active - ERROR");
    }
    else
        printf("The current boolean status for %s is: %s\n",
                                    name, rc ? "true (1)" : "false (0)");

    exit(0);
}
