#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

static int flag = 0;

static void * setcon_thread(void * arg)
{
/*
 * This thread will be used to call setcon etc. as in the setcon_example code,
 * except that this will be executed in a thread. It will be seen that without
 * a typebounds statement (see the setcon_thread_example.conf module), it will
 * not be allowed. This can be seen by the return code of EPERM (Operation not
 * permitted) and an audit.log entry containing:
 *
 *    type=SELINUX_ERR msg=audit(...): op=security_bounded_transition
 *    result=denied oldcontext=..... newcontext=.....

 * To get this to work using the Fedora-16 targeted policy, add the
 * setcon_thread_example.conf module.
 */
	int rc;
    security_context_t context;
	char *argv[] = { NULL };

	printf("\nExecuting: getcon and setcon in thread: %s\n", __FUNCTION__);

	printf("\nExecuting: getcon_raw(&context)\n");
    if ((rc = getcon_raw(&context)) == -1) {
        printf("Failed to obtain context\n");
        perror("getcon_raw - ERROR");
		flag = 1;
        exit(1);
    }

    if(context) {
        printf("The current context is:\n\t%s\n", context);
		printf("Press return to continue, then select new context\n");
    	getchar();
        freecon(context);
    }

    get_config_entry("[raw_context]", &context);

	printf("\nExecuting: setcon_raw(%s)\n", context);
    if ((rc = setcon_raw(context)) == -1) {
        perror("setcon_raw - ERROR");
		printf("Check the audit log for SELinux audit messages.\n");
		flag = 1;
        exit(1);
    }
    freecon(context);

    /*
     * Got here so managed to set the current context and read it back. Now go
     * and run an execvp (or execve etc.) to prove that if the context is
     * valid, then a new task can run in the correct context.
     */
    printf("\nAbout to execute an execvp with the \"getcon_example\" sample "
				"function:\n\texecvp(\"getcon_example\", argv)\n\nThis will "
				"display the exec'ed context if the set context is valid.\n");
	printf("Press return to continue\n");
    getchar();


    printf("Executing: \"execvp(\"getcon_example\", argv);\" function\n");
    if ((rc = execvp("getcon_example", argv)) == -1) {
        perror("execvp - ERROR");
        exit(1);
    }
    /* If execve okay, then we don't get here anyway. */
 	flag = 1;
	return 0;
}



int main(int argc, char **argv)
{
	pthread_t thread;

#ifdef INFO
    printf("\nThe setcon_thread2 example calls setcon from a thread. It "
				"requires a context to be selected that will be set by "
				"setcon.\nTo check that the context has been set a getcon "
				"is issued to display the\nresult, followed by:\n"
				"\texecvp(\"getcon_example\", argv)\n"
           		"that will execute the getcon_example application and display "
				"the new process\ncontext.\n"
				"\nNotes 1) The getcon_example binary needs to be in "
				"/usr/local/bin\n"
				"\n      2) The call requires process {dyntransition} "
				"permission and a typebounds\n         statement to work as a "
				"minimum.\n"
				"\n      3) If using the targeted policy there is a "
				"setcon_thread_example.conf\n         policy module supplied "
				"in the 'modules' directory that will add the"
				"\n         required rules to the policy. A context of:"
				"\n\t\tunconfined_u:unconfined_r:user_t:s0"
				"\n         should then be selected.\n"
				"\nPress return to continue\n");
    getchar();

	printf("To run the example:\n\n"
				"1) Ensure the setcon_example.conf policy module has been "
				"loaded but NOT the\n   setcon_example.conf policy module.\n\n"
				"2) Run the example and select a context of:\n\t"
				"unconfined_u:unconfined_r:user_t:s0\n\n"
				"   An error message should be displayed as follows:\n\t"
				"setcon_raw - ERROR: Operation not permitted\n\n"
				"   This is because the setcon function cannot be run in a "
				"threaded environment\n   without a typebounds statement.\n\n"
				"3) Load  the setcon_thread_example.conf policy module, the\n"
				"   setcon_thread2_example should now complete without error.\n"
				"\nPress return to continue\n");
    getchar();
#endif

	printf("\nCreating thread to run setcon_raw\n");
	pthread_create(&thread, NULL, setcon_thread, NULL);

	while (flag != 1)
		sleep(1);

	exit(0);
}
