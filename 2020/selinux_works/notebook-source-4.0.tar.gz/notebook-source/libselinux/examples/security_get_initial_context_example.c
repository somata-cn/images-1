#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    char *name;
    security_context_t con;
    int rc;

#ifdef INFO
    printf("\nThe security_get_initial_context example requires an initial "
                    "context name\nto be selected. The context assigned to "
                    "that name by the policy will then\nbe returned."
					"\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[initial_context]", &name);

    printf("\nExecuting: security_get_initial_context_raw(%s, &con);\n", name);

    if ((rc = security_get_initial_context_raw(name, &con)) != 0) {
        printf("No initial context found for %s\n", name);
        perror("security_get_initial_context_raw - ERROR");
        free(name);
        exit(1);
    }
    printf("\nThe returned initial context is: %s\n", con);
    freecon(con);
    free(name);
    exit(0);
}
