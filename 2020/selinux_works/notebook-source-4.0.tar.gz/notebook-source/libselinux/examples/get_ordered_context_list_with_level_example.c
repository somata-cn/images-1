#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <selinux/selinux.h>
#include <selinux/get_context_list.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    const char *user;
    const char *level;
    security_context_t fromcon;
    security_context_t *list;
    int n, i;

#ifdef INFO
    printf("\nThe get_ordered_context_list_with_level example requires a user, "
				"level and\ncontext to be selected. An ordered list of "
				"reachable contexts for the user\nbased on the level is then "
				"obtained and displayed with the number of returned\nentries. "
				"Select the context NULL entry to use the current process "
				"context.\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[user]", (char **)&user);
    get_config_entry("[raw_context]", &fromcon);
    if ((strcmp(fromcon, "NULL")) == 0)
        fromcon = NULL;
    get_config_entry("[level]", (char **)&level);
    if ((strcmp(level, "NULL")) == 0)
        level = NULL;

    printf("Executing: get_ordered_context_list_with_level(%s, %s, %s, "
                                            "&list);\n", user, fromcon, level);

    if ((n = get_ordered_context_list_with_level(user, level, fromcon,
                                                            &list)) <= 0) {
		printf("Could not retrieve a list of contexts.\n");
        perror("get_ordered_context_list_with_level - ERROR");
        exit(1);
    }

    printf("Returned %d context entries:\n", n);
    for (i = 0; i < n; i++)
        printf("\tContext %d = %s\n", i+1, list[i]);

    freecon(fromcon);
    freeconary(list);
    exit(0);
}
