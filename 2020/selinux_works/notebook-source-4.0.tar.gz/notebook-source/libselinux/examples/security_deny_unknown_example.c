#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int deny_unknown;

#ifdef INFO
	printf("\nThe security_deny_unknown example will display the status of "
				"the deny_unknown\nflag that is set within the active policy. "
				"It signifies whether undefined\nobject classes and "
				"permissions are allowed or not.\n\nThe flag can be set in the "
				"Reference Policy source or in the semanage.conf\nfile "
				"(need to run semodule -B that will rebuild the base module "
				"and\nactivate new setting).\n\nAn example semanage.conf "
				"entry is as follows:\n\thandle-unknown = allow\n"
				"Valid entries are: allow|deny|reject\n"
				"\nPress return to continue\n");
    getchar();
#endif

    printf("\nExecuting: security_deny_unknown();\n");

    if ((deny_unknown = security_deny_unknown()) == -1) {
        perror("deny_unknown - ERROR\n");
        exit(1);
    }
    printf("\nQueries on undefined object classes or permissions are: %s\n",
										deny_unknown ? "DENIED" : "ALLOWED");
    exit(0);
}
