#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    security_context_t context;
    char *path;

#ifdef INFO
    printf("\nThe getfilecon example requires a file or directory name to be "
                "selected. It will\nthen retrieve the context from the files "
                "xattr \"security.selinux\" attribute and its length using "
                "getxattr(2) system call.\nIf extended attributes are not "
                "supported, then errno = ENOTSUP (Operation not\nsupported) "
                "is returned.\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[path]", &path);

    printf("\nExecuting: getfilecon_raw(%s, &context);\n", path);
    if ((rc = getfilecon_raw(path, &context)) == -1) {
        perror("getfilecon - ERROR");
        exit(1);
    }
    printf("The \"security.selinux\" xattr context assigned to the file "
                            "is:\n\t%s length: %d\n", context, rc);
    freecon(context);
    free(path);
    exit(0);
}
