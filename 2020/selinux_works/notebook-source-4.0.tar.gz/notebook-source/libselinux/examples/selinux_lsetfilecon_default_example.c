#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    char *path;
	security_context_t context;

#ifdef INFO
    printf("\nThe selinux_lsetfilecon_default example requires a file name to "
					"be selected.\nIts current context will then be displayed "
					"(using the lgetfilecon function)\nand then reset to "
					"the system default specified in the file_contexts file.\n"
					"\nIf the file is a symbolic link it will update the "
					"symbolic link entry only.\nIf a normal file, the file will "
					"be updated.\n"
					"\nNote that if the system default is set to <<none>> in "
					"the file contexts file,\nthen the context will not be "
					"updated and zero (success) is returned."
                    "\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[path]", &path);

    printf("\nNow obtaining the files context via lgetfilecon_raw:\n");
    if ((rc = lgetfilecon_raw(path, &context)) == -1) {
        perror("lgetfilecon_raw - ERROR");
        exit(1);
    }
    printf("The files current context is:\n\t%s\n", context);
    freecon(context);

    printf("\nExecuting: selinux_lsetfilecon_default(%s);\n\n", path);
    if ((rc = selinux_lsetfilecon_default(path)) == 0) {
        lgetfilecon_raw(path, &context);
        printf("Reset context to system default of: %s\n", context);
        freecon(context);
    }
    else {
        printf("Failed to reset context to system default\n");
        perror("selinux_lsetfilecon_default - ERROR");
    }

    free(path);
    exit(0);
}
