#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* selinuxfs mount point defined in selinux.h */
extern char *selinux_mnt;

int main(int argc, char **argv)
{
    int rc;

#ifdef INFO
    printf("\nThe is_selinux_mls_enabled example checks whether the active "
					"policy is MCS/MLS\nenabled or not by reading the %s/mls "
					"entry and returns the value.\n", selinux_mnt);
#endif

    printf("\nExecuting: is_selinux_mls_enabled();\n");

    rc = is_selinux_mls_enabled();
    switch (rc) {
        case 0:
            printf("\nThe active policy is not MLS enabled.\n");
            break;
        case 1:
            printf("\nThe active policy is MLS enabled.\n");
            break;
        default:
            printf("\nCannot determine the policy MLS state.\n");
            perror("is_selinux_mls_enabled - ERROR");
            break;
    }
    exit(0);
}
