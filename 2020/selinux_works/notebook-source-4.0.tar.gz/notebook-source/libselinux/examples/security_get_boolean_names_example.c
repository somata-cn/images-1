#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc, i;
    char **names;
    int number_of_booleans;

#ifdef INFO
	printf("\nThe security_get_boolean_names example will display the number "
				"of booleans and\ntheir names.\nPress return to continue\n");
    getchar();
#endif

    printf("Executing: security_get_boolean_names"
						"(names, number_of_booleans);\n");

	if ((rc = security_get_boolean_names(&names, &number_of_booleans)) == -1) {
        printf("FAILED to get boolean names\n");
        perror("security_get_boolean_names - ERROR");
    }
    else {
        printf("Returned %d booleans:\n", number_of_booleans);
        for (i = 0; i < number_of_booleans; i++)
            printf("Boolean %d - %s\n", i+1, names[i]);
    }
    exit(0);
}
