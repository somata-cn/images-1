#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    const char *str = NULL;
    security_class_t tclass;
    char *string;

#ifdef INFO
    printf("\nThe security_class_to_string example requires a class ID to "
                "be selected\n(e.g '1'), the string value will then be "
                "displayed."
                "\n\nNotes 1) When building policy, strings are used to define "
				"classes, the kernel\n         will then assign the numeric IDs "
				"as it loads the policy. The order of\n         the numbering "
				"is the order that the classes are defined in the policy"
				"\n         source file (for the Reference Policy the "
				"'security' object class\n         is first and is therefore "
				"'1').\n"
				"\n      2) Unless selinux_set_mapping is called the only "
				"classes the function\n         will recognise are those "
				"built into libselinux. For 2.1.6 the\n         maximum "
				"class number is '73' (x_application_data).\n"
				"\n      3) See the security_class_to_string_with_class_"
				"mapping_example example\n         where the "
                "selinux_set_mapping function is called to set all object"
                "\n         classes defined in the F-16 Reference Policy "
                "source.\nPress return to continue\n");
	getchar();
#endif

    get_config_entry("[class_flask]", &string);
    tclass = strtol(string, (char **)&string[3], 10);
    free(string);

    printf("Executing: security_class_to_string(%d);\n", tclass);

    if ((str = security_class_to_string(tclass)) != NULL)
        printf("\nThe class string is: %s\n", str);
    else
        perror("security_class_to_string - ERROR");

    exit(0);
}
