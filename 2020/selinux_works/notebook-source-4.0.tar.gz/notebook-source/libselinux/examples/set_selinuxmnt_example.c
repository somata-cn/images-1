#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* selinuxfs mount point defined in src/policy.h of libselinux */
extern char *selinux_mnt;

int main(int argc, char **argv)
{
	char our_mnt[] = "/MY_SELINUX";

#ifdef INFO
    printf("\nThe current SELinux mount point is: %s\n\nThe set_selinuxmnt "
                "example will set this to %s for this process only.\nThis "
                "function would only be used by system selinux-aware programs "
                "such as\nsbin/init to set the initial mount point.\n"
				"\nNotes: 1) libselinux will initialise 'selinux_mnt' to the "
				"actual SELinux mount\n         point during its "
				"initialisation sequence. This is local to this\n         "
				"instance of libselinux, therefore (for this test) it "
				"performs no\n         useful purpose.\n"
				"\n       2) The init_selinuxmnt and fini_selinuxmnt functions "
				"defined in the\n         libselinux man pages are not public "
				"so cannot be called.\n"
				"\nPress return to continue\n", selinux_mnt, our_mnt);
    getchar();
#endif

    printf("Executing: set_selinuxmnt(%s);\n", our_mnt);
    set_selinuxmnt(our_mnt);

    printf("\nThe SELinux mount point is now: %s for this process only.\n",
																selinux_mnt);

	exit(0);
}
