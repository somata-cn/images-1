/*
 * basic_commit_booleans - This will write a '1' to
 * selinuxfs/commit_pending_bools. The loaded policy will then have the
 * appropriate boolean policy statements updated to reflect the new conditions.
 *
 * This code has been derived from the libselinux source.
 */

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <selinux/selinux.h>

/* selinuxfs mount point */
extern char *selinux_mnt;

int main(int argc, char **argv)
{
	char path[PATH_MAX];
	char buf[2];
	int fd, rc;

    sprintf(path, "%s/commit_pending_bools", selinux_mnt);
	if ((fd = open(path, O_WRONLY)) < 0) {
	    perror("OPEN FAILED");
	    exit(1);
	}

   	buf[0] = '1';
	buf[1] = '\0';

    printf("\nCommit booleans by writing %s to %s\n\n", buf, path);
	if ((rc = write(fd, buf, 2)) < 0) {
	    perror("WRITE FAILED");
	    exit(1);
	}

	close(fd);
	exit(0);
}
