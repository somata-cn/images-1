#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>
#include <selinux/get_context_list.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    const char *user;
    security_context_t newcon = NULL;
    int rc;

#ifdef INFO
    printf("\nThe manual_user_enter_context example requires a user to be "
                "selected. Once\nentered the function will ask if you want "
                "to enter a context (role, type and\nlevel (if MLS/MCS)). "
                "You need to enter 'y' to proceed or 'n' to exit. Once a\n"
                "valid context has been selected the function terminates."
                "\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[user]", (char **)&user);

    printf("\nExecuting: manual_user_enter_context(%s, &newcon);\n", user);

    if ((rc = manual_user_enter_context(user, &newcon)) != 0) {
        /* This function does not always set errno */
        perror("manual_user_enter_context - ERROR");
        exit(1);
    }
    printf("\nThe selected context %s is valid for this user: %s\n",
															newcon, user);
    freecon(newcon);
    exit(0);
}
