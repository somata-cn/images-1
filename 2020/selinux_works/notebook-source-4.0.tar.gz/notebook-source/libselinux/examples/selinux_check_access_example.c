#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <selinux/selinux.h>

/* Get config entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t scon, tcon;
	int enforce_mode, rc;
    char *class, *perm_list, *audit_msg = NULL;

#ifdef INFO
    printf("\nThe selinux_check_access example requires a source and target "
                "context plus a\nclass and one permission (if a list is "
				"selected, then only the first is taken).\n"
				"\nNote that if access is denied, then an AVC error will be "
				"displayed on stderr.\n\nThe selinux_check_access_audit "
				"example shows how the output can be redirected\nto the "
				"audit log with  the optional 'audit_msg' parameter."
				"\nPress return to continue\n");
	getchar();
#endif

    get_config_entry("[raw_context]", &scon);
    get_config_entry("[raw_context]", &tcon);
	get_config_entry("[class]", &class);
    get_config_entry("[perms]", &perm_list);
	/* Take first in the list if multiple entries */
	strtok(perm_list, " ");

    if ((enforce_mode = security_getenforce()) == -1) {
        printf("Failed to get current SELinux enforcing state\n");
        perror("security_getenforce - ERROR");
        exit(1);
    }
    if (!enforce_mode)
        printf("\nNOTE: Currently in permissive mode, therefore this "
							"function will always return\nokay.\n");


    printf("\nExecuting selinux_check_access(%s, %s, %s, %s, NULL);\n\n",
												scon, tcon, class, perm_list);

	if ((rc = selinux_check_access(scon, tcon, class, perm_list, audit_msg))
																	== -1) {
		perror("selinux_check_access - ERROR ");
		if (errno == EACCES)
			printf("\nCheck stderr for AVC message\n");
		exit(1);
	}

	printf("Access allowed\n");
    exit(0);
}
