#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <selinux/selinux.h>
#include <selinux/label.h>

void x_menu()
{
    printf("Now select an object_type from the following list:\n");
    printf("1) property       SELABEL_X_PROP\n");
    printf("2) extension      SELABEL_X_EXT\n");
    printf("3) client         SELABEL_X_CLIENT\n");
    printf("4) event          SELABEL_X_EVENT\n");
    printf("5) selection      SELABEL_X_SELN\n");
    printf("6) poly_property  SELABEL_X_POLYPROP\n");
    printf("7) poly_selection SELABEL_X_POLYSELN\n\n");
}

/* These follow the order in label.h */
static char *object_type[] = {
    "SELABEL_X_PROP",
    "SELABEL_X_EXT",
    "SELABEL_X_CLIENT",
    "SELABEL_X_EVENT",
    "SELABEL_X_SELN",
    "SELABEL_X_POLYPROP",
    "SELABEL_X_POLYSELN"
};

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main (int argc, char **argv)
{
    int max_objects, index;
    char answer[8];
    struct selabel_handle *hnd;
    security_context_t selabel_context;
    char *object_name, *x_contexts_path, *validate = NULL;

    struct selinux_opt selabel_option [] = {
		{ SELABEL_OPT_PATH, x_contexts_path },
		{ SELABEL_OPT_VALIDATE, validate }
	};

#ifdef INFO
    printf("\nThe selabel_x example will show the context that will be applied "
				"to an object\ninstance for the X-Windows object manager. "
				"The example will loop asking for an\nX-Windows object type to "
				"be selected (e.g. selection) and then an object name\n"
				"(e.g. X11:SelectionNotify). The objects context will then "
                "be displayed.\nPress 'q' to quit and call selabel_stats, "
				"or return to continue.\n");

	printf("\nThe example will ask for an x_contexts file to be selected, if "
				"you want the\ndefault select NULL. Then select whether the "
				"contexts are to be validated or\nnot.\n");

	printf("\nNote 1: selabel_lookup does not validate the 'object_name' "
	        "component. However\nthe process does allow wild-cards (* and ?) "
	        "to be used that will be expanded.\nThis will allow matching to "
	        "return a valid context (but note any object_name\nwill return a "
			"context if the '*' is configured against object_type in the\n"
			"x_contexts file).\n\n"
	        "Note 2: For X-Windows the object_type maps to a predefined "
			"string. For example\n'SELABEL_X_EVENT' is mapped to 'event' "
			"in the x_contexts file as follows:\n");
    printf("\n\t<object_type> <object_name> <security_context>\n"
        "\t    event           *        system_u:object_r:xevent_t:s0\n\n");

	printf("Press return to continue\n");
	getchar();
#endif

	get_config_entry("[x_contexts_path]", &x_contexts_path);
    if ((strcmp(x_contexts_path, "NULL")) == 0)
        x_contexts_path = NULL;

	printf("\nDo you want to validate contexts? [y/n]");
	fflush(stdin);
	fgets(answer, sizeof(answer), stdin);
	if ((answer[0] == 'y') || (answer[0] == 'Y'))
		validate = (char *)1;

	selabel_option[0].value = x_contexts_path;
	selabel_option[1].value = validate;

    printf("Executing: selabel_open(SELABEL_CTX_X, selabel_option, 2)\n\n");
	if ((hnd = selabel_open(SELABEL_CTX_X, selabel_option, 2)) == NULL) {
	    perror("selabel_open- ERROR");
	    exit(1);
	}

    while(1) {
        /* Set the number of X objects in menu and then display on screen */
        max_objects = 7;
        x_menu();
        fgets(answer, sizeof(answer), stdin);
        index = atoi(answer);
        if(index >= max_objects+1 || index < 1)
            continue;
        printf("The chosen object_type is: %s\n", object_type[index-1]);
        get_config_entry("[object_name]", &object_name);
		/* Allow NULL for object_name - causes Segmentation fault - fix avail */
    	if ((strcmp(object_name, "NULL")) == 0)
        	object_name = NULL;

        printf("Executing: selabel_lookup_raw(hnd, &selabel_context, %s, %s)"
									"\n\n", object_name, object_type[index-1]);

        if (selabel_lookup_raw(hnd, &selabel_context, object_name, index)
                                                                        == 0) {
            printf ("The X context to be applied is: %s\n", selabel_context);
	        freecon (selabel_context);
        } else {
			switch (errno) {
				case ENOENT:
					printf("\nselabel_lookup failed to find a context."
										"\n\tERROR: %s\n", strerror(errno));
					break;
				case EINVAL:
					printf("\nselabel_lookup failed to validate context, or "
								"the object name / object type are invalid."
										"\n\tERROR: %s\n", strerror(errno));
					break;
				default:
					printf("\nselabel_lookup ERROR: %s\n", strerror(errno));
					break;
			}
		}
		free(object_name);
        printf("\nq for Quit and display X selabel_stats or "
                                                    "return to continue.\n");
        fgets(answer, sizeof(answer), stdin);
        if (answer[0] == 'q') {
            printf("selabel_stats returned:\n");
            selabel_stats(hnd);
            break;
        }
    }
    selabel_close(hnd);
    exit(0);
}
