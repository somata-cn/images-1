#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t con;
	int rc;

#ifdef INFO
    printf("\nThe security_check_context example requires a context to be "
                "selected that will\nthen be validated."
				"\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[raw_context]", &con);

    printf("\nExecuting: security_check_context_raw(%s);\n", con);
    if ((rc = security_check_context_raw(con)) != 0) {
        printf("\nThe security context is invalid.\n");
        perror("security_check_context_raw - ERROR");
    }
	else
		printf("\nThe security context is valid.\n");

    exit(0);
}
