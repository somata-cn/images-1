/*
 * basic_setcon_example - This will take a source context and then write it to
 * /proc/self/task/<tid>/attr/current. The read will return any errors.
 *
 * In this example the basic setcon is run, then a normal getcon is issued to
 * check that the context has been changed. An execvp is then executed to
 * run an application in the set context.
 *
 * For reference the libselinux source module (procattr.c) checks whether
 * the call should use '/proc/self/task/<tid>/attr/<attr>' for those calls
 * that work on the 'self' process such as:
 * get/setcon()             <attr> = current
 * get/setexeccon()         <attr> = exec
 * get/setsockcreatecon() <attr> = sockcreate
 * get/setfscreatecon()     <attr> = fscreate
 * get/setkeycreatecon()    <attr> = keycreate
 * getprevcon()             <attr> = prev
 *
 * or '/proc/<pid>/attr/<attr>' for those that work on other process id's
 * such as: getpidcon() <attr> = current.
 *
 * This code has been derived from the libselinux source.
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <limits.h>
#include <selinux/selinux.h>


/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    security_context_t context;
	char path[PATH_MAX];
	int fd;
	pid_t tid;
	int errno_hold;

    printf("\nThe basic_setcon example requires a context entry to be selected."
                                                "\nPress return to continue\n");
    getchar();
    get_config_entry("[raw_context]", &context);

    printf("About to run a direct setcon function using: %s\n\n", context);

    /*
     * gettid() returns  the caller’s thread ID (TID). In a single-threaded
     * process, the thread ID is equal to the process ID (PID, as returned  by
     * getpid(2)). In a multithreaded process, all threads have the same PID,
     * but each one has a unique TID.
     * On success, returns the thread ID of the calling process. This call
     * is always successful.
     */
    tid = syscall(__NR_gettid);
	printf("The callers thread ID (tid) is: %d\n", tid);

	snprintf(path, PATH_MAX, "/proc/self/task/%d/attr/current", tid);

	if ((fd = open(path, O_RDWR)) < 0) {
		perror("FAILED OPEN");
		exit(1);
	}

	printf("Writing context to %s\n", path);
	if (context)
		do {
			rc = write(fd, context, strlen(context) + 1);
		} while (rc < 0 && errno == EINTR);
	else
		do {
			rc = write(fd, NULL, 0);
		} while (rc < 0 && errno == EINTR);
	errno_hold = errno;
	close(fd);
	errno = errno_hold;
	if (errno != 0) {
		perror("WRITE FAILED");
		printf("\tDenied dyntransition permission is typical\n");
		exit(1);
    }

    freecon(context);

    printf("\nTo see the setcon results, need to issue a getcon() "
                "call before it gets reset\nto NULL by the next 'execve' "
                "type function call.\n\n");

    if ((rc = getcon_raw(&context)) == -1) {
        printf("Failed to obtain context\n");
        exit(1);
    }

    if(context) {
        printf("getcon returned a context of:\n\t%s\n", context);
        freecon(context);
    }
    else {
            printf("getcon returned a context of: %s\n", context);
            exit(1);
    }

    /*
     * Got here so managed to set context and read it back. Now go and
     * run an execvp (or execve etc.) to prove that if the context is valid,
     * then a new task can run in the correct context. If fails check the
     * audit log for SELinux audit messages (denied  dyntransition permission
     * is typical).
     */
    printf("\nNow execute an execvp with the \"getcon_example\" sample "
                "function:\n\texecvp(\"getcon_example\", argv)\nThis will "
                "display the exec'ed context if the set context is valid. \n"
                "If the set context is invalid, then there will be an entry "
                "in the \naudit log stating why it failed (denied "
                "dyntransition permission\nis typical).\n\n");

    printf("Now executing: \"execvp(\"getcon_example\", argv);\" function:\n");
    if ((rc = execvp("getcon_example", argv)) == -1) {
        perror("execvp failed - see audit log for SELinux reason");
        exit(1);
    }
    /* If execvp okay, then we don't get here anyway. */
    exit(0);
}
