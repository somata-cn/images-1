#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc;

#ifdef INFO
	printf("\nThe selinux_init_load_policy example will call the function "
				"to reload the policy\nand display whether it was reloaded or "
				"not.\n\n"
				"Notes 1) For kernels >= than 2.6.22, then the preservebools "
				"flag is\n         automatically set to '0' as the kernel "
				"preserves boolean values\n         across a reload, so do "
				"not need to preserve them in userspace.\n"
				"      2) If there is a valid SETLOCALDEFS= entry in the "
				"%sconfig\n         file the function opens the policy in "
				"write mode and runs genusers\n         on %slocal.users to "
				"update the policy\n         before the reload.\n"
				"Press return to continue\n",
                selinux_path(), selinux_users_path());
	getchar();
#endif

    printf("Executing: selinux_mkload_policy(0);\n");

    if ((rc = selinux_mkload_policy(0)) == -1) {
        printf("Cannot load policy\n");
        perror("selinux_mkload_policy - ERROR");
    }
    else
        printf("Policy loaded\n");

    exit(0);
}
