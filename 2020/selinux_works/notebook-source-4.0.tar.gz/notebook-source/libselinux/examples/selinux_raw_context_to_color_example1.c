#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t raw;
    char *color_str;
    int rc;

#ifdef INFO
    printf("\nThe selinux_raw_context_to_color example1 requires a raw context "
                "to be selected.\n\nNote: To run this correctly the following "
                "must be enabled:\n"
                " a) A translation configuration file at:\n\t%s\n"
                "\n b) A colour configuration file at:\n\t%s\n"
				"    (a suitable file is in the 'config' directory)\n"
                "\n c) The mcstransd daemon started: service mcstrans start\n",
                		selinux_translations_path(), selinux_colors_path());

	printf("\nNote that if the %s configuration file is\nmissing, then the "
				"default colour string returned is:"
				"\n\t ---- user ----  ---- role ----  ---- type ----  ---- "
				"range ---\n\t#000000 #ffffff #000000 #ffffff #000000 "
				"#ffffff #000000 #ffffff\n"
				"Press return to continue\n", selinux_colors_path());
    getchar();
#endif

    get_config_entry("[raw_context]", &raw);

    printf("Executing: selinux_raw_context_to_color(%s, &color_str);\n", raw);
    if ((rc = selinux_raw_context_to_color(raw, &color_str)) == -1) {
        printf("Failed to get the colour string\n");
        perror("selinux_raw_context_to_color - ERROR");
        exit(1);
    }

    printf("The colour string is: \n\t ---- user ----  ---- role ----  "
				"---- type ----  ---- range ---\n\t%s\n\n", color_str);
    free(color_str);
	freecon(raw);
    exit(0);
}
