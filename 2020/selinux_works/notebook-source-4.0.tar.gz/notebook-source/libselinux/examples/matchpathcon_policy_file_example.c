#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <limits.h>
#include <sepol/sepol.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int validate_policy(const char *path, unsigned lineno, char *context)
{
	int rc;

	printf("---------- Start %s callback function -----------\n", __FUNCTION__);

	if (sepol_check_context(context) == -1) {
        printf("\nsepol_check_context validated default context as "
								"INVALID:\n\t%s\n", context);
        printf("sepol_check_context - ERROR: %s\n\n", strerror(errno));
		printf("Context File: %s\n", path);

        rc = -1;
    }
    else {
   	    printf("sepol_check_context validated default context as VALID:"
														"\n\t%s\n", context);
		printf("Context File: %s\n", path);
    	rc = 0;
    }
	printf("---------- End %s callback function -----------\n\n", __FUNCTION__);
	return (rc);
}


int main(int argc, char **argv)
{
    int rc, mode;
    char *path, *file_contexts_path;
    security_context_t context;
    char answer[8];
    char *policyfile;
    char policy_path[PATH_MAX];
    FILE *policystream;
    int ver = security_policyvers();

#ifdef INFO
    printf("\nThe matchpathcon_policy_file example will show the default "
				"context that should\nbe applied to a file using the selected "
				"binary policy file and associated\nfile_contexts file (and "
				"their corresponding .homedirs and .local files).\n\n");

    printf("The example requests a binary policy file name and then a "
                "file_contexts file.\nOnce selected the example will validate "
                "each file_contexts as the\nMATCHPATHCON_VALIDATE flag is set, "
				"and then loop asking for a file name\nto be selected. The "
				"files default context will then be displayed.\nPress 'q' to "
				"quit and check matches.\n");

	printf("\nNote that if the context specified in the file contexts series "
				"of files is\n<<none>>, then error ENOENT is returned."
				"\nPress return to continue\n");
    getchar();

    printf("This example calls the following libselinux and libsepol functions:"
                "\n  set_matchpathcon_flags"
                "\n     This sets MATCHPATHCON_VALIDATE to validate on init "
                "and\n     MATCHPATHCON_NOTRANS so that raw contexts are "
                "displayed."
                "\n  set_matchpathcon_invalidcon"
                "\n     This will set up a validation routine to allow the "
                "libsepol function\n     'sepol_check_context' to be called to "
                "obtain the file context\n     that will be applied by the "
                "policy."
                "\n  sepol_set_policydb_from_file"
                "\n     This will load the selected binary policy file."
                "\n  matchpathcon_init"
                "\n     This will initialise and load the selected "
                "'file_contexts' file and\n     (if available) the .homedirs "
                "and .local files."
                "\n  matchpathcon"
                "\n     This will obtain the files context via the validation "
                "routine."
                "\n  matchpathcon_checkmatches"
                "\n     Reports any specifications that have not been matched."
                "\n  matchpathcon_fini"
                "\n     Close the file_contexts files and free any memory."
                "\n\nPress return to continue\n");
    getchar();
#endif

    /*
     * This validates the file_contexts set of files as the files are loaded
     * and also stops the labels being translated.
     */
    printf("Executing: set_matchpathcon_flags(MATCHPATHCON_VALIDATE | "
                                                "MATCHPATHCON_NOTRANS);\n");
    set_matchpathcon_flags(MATCHPATHCON_VALIDATE | MATCHPATHCON_NOTRANS);

    /*
     * Set the callback to our validate_policy routine. This replaces the
     * default security_check_context that would validate against the active
     * policy.
     */
    printf("Executing: set_matchpathcon_invalidcon(*validate_policy);\n");
    set_matchpathcon_invalidcon(*validate_policy);

    printf("\nSelect a binary policy file:");
    get_config_entry("[binary_policy]", &policyfile);
    if ((strcmp(policyfile, "CURRENT")) == 0)
        snprintf(policy_path, sizeof(policy_path), "%s.%d", selinux_binary_policy_path(), ver);
	else
		snprintf(policy_path, sizeof(policy_path), "%s", policyfile);
	free(policyfile);
    /*
     * Open the binary policy file and use the libsepol function
     * sepol_set_policydb_from_file to read it into memory. The validate_policy
     * routine will then use the sepol_check_context function to check the
     * selected file contexts against the policy.
     */
	policystream = fopen(policy_path, "r");
	if (!policystream) {
        printf("ERROR - opening policy file: %s\n%s\n", policy_path,
                                                            strerror(errno));
		exit(1);
	}

    printf("Executing: sepol_set_policydb_from_file(%s);\n", policy_path);
	if (sepol_set_policydb_from_file(policystream) <  0) {
        printf("ERROR - reading policy file: %s\n%s\n", policy_path,
                                                            strerror(errno));
		exit(1);
    }
	fclose(policystream);
    printf("Policy file opened\n\n");

    /* Get the file_context location */
    printf("Now select the file_contexts location (NULL = current):");
    get_config_entry("[file_contexts_path]", &file_contexts_path);
    if ((strcmp(file_contexts_path, "NULL")) == 0)
        file_contexts_path = NULL;

    printf("Executing: matchpathcon_init(%s);\n", file_contexts_path);
    if ((rc = matchpathcon_init(file_contexts_path)) == -1) {
        perror("matchpathcon_init - ERROR");
        free(file_contexts_path);
        free(policyfile);
        exit(1);
    }

    /* Set the file mode to '0' */
    mode = 0;

    while(1) {
        printf("Obtaining [path] entries:\n");
        get_config_entry("[path]", &path);

        printf("\nExecuting: matchpathcon(%s, %d, &context);\n", path, mode);
        if (matchpathcon(path, mode, &context) == 0) {
            printf("The default context that will be assigned is: \n\t%s\n",
                                                            		context);
	        freecon(context);
		} else {
			printf("\nmatchpathcon ERROR %s\n", strerror(errno));
			switch (errno) {
				case ENOENT:
					printf("Failed to find a default context.\n");
					break;
				case EINVAL:
					printf("Failed to validate context, or the path / mode "
															"are invalid.\n");
					break;
			}
		}
		free(path);

        printf("\nq for Quit and check matches or return to continue.\n");
        fgets(answer, sizeof(answer), stdin);
        if (answer[0] == 'q') {
            printf("Executing: matchpathcon_checkmatches(NULL)\n");
            matchpathcon_checkmatches(NULL);
            break;
        }
    }
    free(file_contexts_path);
    matchpathcon_fini();
    exit(0);
}
