#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>
#include <selinux/get_context_list.h>

/* Get entries from $HOME/notebook.conf file */
extern char *config_file;
extern void get_config_list(char *entry, char ***content);

int main(int argc, char **argv)
{
    security_context_t newcon = NULL;
    int rc;
    char **list;

#ifdef INFO
    printf("\nThe query_user_context example requires a list of contexts to be "
				"passed to the\nfunction. These will automatically be taken "
				"from the [context_list] entry\nof the %s configuration file."
				"\n\nThe query_user_context function will present a default "
				"context (the first in\nthe list) and then ask if you want to "
				"select a different context. Either\nselect 'n' for the "
				"default or 'y' to select a different context. Once a\n"
				"context has been selected it will be returned. Note that "
				"the selected context\nis not validated."
				"\nPress return to continue\n", config_file);
    getchar();
#endif

    get_config_list("[context_list]", &list);

    printf("\nExecuting: query_user_context(list, &newcon);\n");

    if ((rc = query_user_context(list, &newcon)) != 0) {
        perror("query_user_context - ERROR");
        exit(1);
    }
    printf("\nThe selected context is: %s\n\tNote that the context has not "
					"been validated by query_user_context.\n", newcon);
    free(list);
    freecon(newcon);
    exit(0);
}
