#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <selinux/selinux.h>
#include <selinux/get_context_list.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    const char *user;
    const char *role;
    security_context_t newcon = NULL;
    security_context_t fromcon;
    int rc;

#ifdef INFO
    printf("\nThe get_default_context_with_role example requires a user, role "
                "and context\nentries to be selected. The default context "
                "for the user is then obtained using the supplied role.\n\n"
                "Notes 1) Select the context NULL entry to use the current "
				"process context.\n\n      2) If an invalid role is selected "
				"the function fails with errno = 0\n         (Success). If an "
				"invalid user or context is selected the function\n         "
				"fails with errno = 22 (Invalid argument)."
				"\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[user]", (char **)&user);
    get_config_entry("[role]", (char **)&role);
    get_config_entry("[raw_context]", &fromcon);
    if ((strcmp(fromcon, "NULL")) == 0)
        fromcon = NULL;

    printf("Executing: get_default_context_with_role(%s, %s, %s, &newcon);\n",
                                                     user, role, fromcon);

    if ((rc = get_default_context_with_role(user, role, fromcon,
                                                            &newcon)) != 0) {
		printf("Could not retrieve a default context based on role.\n");
        perror("get_default_context_with_role - ERROR");
        exit(1);
    }

    printf("The returned default context is:\n\t%s\n", newcon);

    freecon(fromcon);
    freecon(newcon);
    exit(0);
}
