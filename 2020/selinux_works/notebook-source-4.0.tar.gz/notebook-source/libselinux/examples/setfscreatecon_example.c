#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc, fd;
    security_context_t context;
    /* This is a file created to check assigned context */
    char file_name[] = "test-file";

#ifdef INFO
    printf("\nThe setfscreatecon example requires a context to be selected "
                "for a new\nfile that will be created during the test.\n"
                "\nA new file will be created in the cwd and called "
				"'test-file'.\n\nTo check the setfscreatecon results, a "
				"getfscreatecon call is\nissued before it gets reset to NULL "
				"by the next 'execv*'.\n");

    printf("\nNote 1: In permissive mode it is possible to set any context "
                "not defined in the\npolicy (such as \"RUBBISH\"). If this is "
                "done, then in permissive mode\ngetfilecon will show the "
                "xattr value (i.e. RUBBISH), however in enforcing mode\nit "
				"will be shown as unlabeled_t if using Reference Policy.\n");

	printf("\nNote 2: If a valid policy context is set in permissive mode BUT "
                "not allowed for\nthe current process by the policy, then in "
				"enforcement mode the context will be\ndisplayed correctly, "
				"however it will not be possible to change it.\n");

	printf("\nNote 3: Add the setfilecon_example.conf policy module to "
				"experiment with\n'deferred mapping of security contexts'. "
				"This will allow contexts NOT defined\nin the current policy "
				"to be set.\nPress return to continue\n");
    getchar();
#endif

	printf("\nExecuting: getfscreatecon_raw(&context)\n");
    if ((rc = getfscreatecon_raw(&context)) == -1) {
        printf("Failed to obtain context\n");
        perror("getfscreatecon_raw - ERROR");
        exit(1);
    }
	printf("The fscreate context is:\n\t%s\n", context);
	printf("Press return to continue\n");
	getchar();
	freecon(context);

    get_config_entry("[raw_context]", &context);

    printf("Executing: setfscreatecon_raw(%s);\n", context);
	if ((rc = setfscreatecon_raw(context)) == -1) {
        printf("Failed to set fs context\n");
        perror("setfscreatecon_raw - ERROR");
        exit(1);
    }
    freecon(context);

    if ((rc = getfscreatecon_raw(&context)) == -1) {
        printf("Failed to obtain context\n");
        perror("getfscreatecon_raw - ERROR");
        exit(1);
    }
    if (!context) {
        printf("No context has been set (NULL returned)\n");
        exit(1);
    }
    printf("The fscreate context is now:\n\t%s\n", context);
    freecon(context);
    /*
     * Remove old file from current dir if it exists as will then create
     * again for next part of test to check its assigned context.
     */
    unlink(file_name);

    if ((fd = open(file_name, O_CREAT | O_WRONLY, S_IRUSR | S_IWUSR)) == -1) {
        printf("Cannot create %s\n", file_name);
        perror("open - ERROR");
        exit(1);
    }

    printf("\nCreated a new file (%s) in current working directory to check "
            "if the\ncorrect context has been set.\n", file_name);
    printf("\nNow obtaining the file context via fgetfilecon_raw:\n");
    if ((rc = fgetfilecon_raw(fd, &context)) == -1) {
        perror("fgetfilecon_raw - ERROR");
        exit(1);
    }
    printf("The context assigned to the new file is:\n\t%s\n", context);
    freecon(context);

    printf("\nNow run 'ls -Z %s' and check the file context\n", file_name);
    exit(0);
}
