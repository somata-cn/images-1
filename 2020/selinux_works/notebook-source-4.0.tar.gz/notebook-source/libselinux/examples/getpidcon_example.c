#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc;
    pid_t pid;
    security_context_t context;
    char answer[8];

#ifdef INFO
    printf("\nThe getpidcon example will require a pid to be entered. This "
                    "will then be used\nto retrieve and display the process "
                    "context.\nPress return to continue\n");
    getchar();
#endif

    printf("Enter pid:\n");
    fflush(stdin);
    fgets (answer, sizeof(answer), stdin);
    pid = strtol(answer, NULL, 10);

    printf("Executing: getpidcon_raw(%d, &context);\n", pid);

    if ((rc = getpidcon_raw(pid, &context)) == -1) {
        printf("Failed to obtain context - invalid pid\n");
        perror("getpidcon_raw - ERROR");
        exit(1);
    }
    printf("The returned context is:\n\t%s\n", context);
    freecon(context);
    exit(0);
}
