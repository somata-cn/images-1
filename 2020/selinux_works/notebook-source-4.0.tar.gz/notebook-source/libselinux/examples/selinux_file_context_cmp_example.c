#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    security_context_t context_a;
    security_context_t context_b;

#ifdef INFO
    printf("\nThe selinux_file_context_cmp example requires two context entries"
                    " to be selected\nthat will then be compared. The contexts "
                    "will be compared for an exact match\nthat excludes the "
					"user component.\n\nNote that these contexts do not need "
					"to be file contexts.\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[raw_context]", &context_a);
    get_config_entry("[raw_context]", &context_b);

    printf("\nExecuting: selinux_file_context_cmp(%s, %s);\n\n",
                                                context_a, context_b);
    rc = selinux_file_context_cmp(context_a, context_b);

	if (rc == 0) {
		printf("The contexts are considered equal as they match after "
							"the 'user:' component.\n\treturn = %d\n\n", rc);
	}

	else if (rc > 0) {
		printf("The contexts do not match (context_a is greater than "
										"context_b)\n\treturn = %d\n\n", rc);
	}

	else if (rc < 0) {
            printf("The contexts do not match (context_a is less than "
										"context_b)\n\treturn = %d\n\n", rc);
	}

    free(context_a);
    free(context_b);
    exit(0);
}
