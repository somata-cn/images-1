#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>
#include <selinux/get_default_type.h>

int main(int argc, char **argv)
{
    const char *str = NULL;

#ifdef INFO
    printf("\nThe selinux_path_functions example will call all 28 libselinux "
            "path functions\nfor the active policy that are defined in "
			"version 2.1.6.\nNote that if a configuration file does not "
			"physically exist, the function\nwill return the default.\n"
			"\nPress return to continue\n");
    getchar();
#endif

    if ((str = selinux_path()) != NULL)
        printf("1 - selinux_path is:\n\t%s\n\n", str);
    else
        perror("selinux_path - ERROR");

    if ((str = selinux_policy_root()) != NULL)
        printf("2 - selinux_policy_root is:\n\t%s\n\n", str);
    else
        perror("selinux_policy_root - ERROR");

    if ((str = selinux_binary_policy_path()) != NULL)
        printf("3 - selinux_binary_policy_path is:\n\t%s\n\n", str);
    else
        perror("selinux_binary_policy_path - ERROR");

    if ((str = selinux_current_policy_path()) != NULL)
        printf("4 - selinux_current_policy_path is:\n\t%s\n\n", str);
    else
        perror("selinux_current_policy_path - ERROR");

    if ((str = selinux_booleans_path()) != NULL)
        printf("5 - selinux_booleans_path is:\n\t%s\n\n", str);
    else
        perror("selinux_booleans_path - ERROR");

    if ((str = selinux_booleans_subs_path()) != NULL)
        printf("6 - selinux_booleans_subs_path is:\n\t%s\n\n", str);
    else
        perror("selinux_booleans_subs_path - ERROR");

    if ((str = selinux_colors_path()) != NULL)
        printf("7 - selinux_colors_path is:\n\t%s\n\n", str);
    else
        perror("selinux_colors_path - ERROR");

    if ((str = selinux_contexts_path()) != NULL)
        printf("8 - selinux_contexts_path is:\n\t%s\n\n", str);
    else
        perror("selinux_contexts_path - ERROR");

    if ((str = selinux_customizable_types_path()) != NULL)
        printf("9 - selinux_customizable_types_path is:\n\t%s\n\n", str);
    else
        perror("selinux_customizable_types_path - ERROR");

    if ((str = selinux_default_context_path()) != NULL)
        printf("10 - selinux_default_context_path is:\n\t%s\n\n", str);
    else
        perror("selinux_default_context_path - ERROR");

    if ((str = selinux_default_type_path()) != NULL)
        printf("11 - selinux_default_type_path is:\n\t%s\n\n", str);
    else
        perror("selinux_default_type_path - ERROR");

    if ((str = selinux_failsafe_context_path()) != NULL)
        printf("12 - selinux_failsafe_context_path is:\n\t%s\n\n", str);
    else
        perror("selinux_failsafe_context_path - ERROR");

    if ((str = selinux_file_context_homedir_path()) != NULL)
        printf("13 - selinux_file_context_homedir_path is:\n\t%s\n\n", str);
    else
        perror("selinux_file_context_homedir_path - ERROR");

    if ((str = selinux_file_context_local_path()) != NULL)
        printf("14 - selinux_file_context_local_path is:\n\t%s\n\n", str);
    else
        perror("selinux_file_context_local_path - ERROR");

    if ((str = selinux_file_context_path()) != NULL)
        printf("15 - selinux_file_context_path is:\n\t%s\n\n", str);
    else
        perror("selinux_file_context_path - ERROR");

    if ((str = selinux_file_context_subs_path()) != NULL)
        printf("16 - selinux_file_context_subs_path is:\n\t%s\n\n", str);
    else
        perror("selinux_file_context_subs_path - ERROR");

    if ((str = selinux_file_context_subs_dist_path()) != NULL)
        printf("17 - selinux_file_context_subs_dist_path is:\n\t%s\n\n", str);
    else
        perror("selinux_file_context_subs_dist_path - ERROR");

    if ((str = selinux_homedir_context_path()) != NULL)
        printf("18 - selinux_homedir_context_path is:\n\t%s\n\n", str);
    else
        perror("selinux_homedir_context_path - ERROR");

    if ((str = selinux_media_context_path()) != NULL)
        printf("19 - selinux_media_context_path is:\n\t%s\n\n", str);
    else
        perror("selinux_media_context_path - ERROR");

    if ((str = selinux_netfilter_context_path()) != NULL)
        printf("20 - selinux_netfilter_context_path is:\n\t%s\n\n", str);
    else
        perror("selinux_netfilter_context_path - ERROR");

    if ((str = selinux_removable_context_path()) != NULL)
        printf("21 - selinux_removeable_context_path is:\n\t%s\n\n", str);
    else
        perror("selinux_removable_context_path - ERROR");

    if ((str = selinux_securetty_types_path()) != NULL)
        printf("22 - selinux_securetty_types_path is:\n\t%s\n\n", str);
    else
        perror("selinux_securetty_types_pathERROR");

    if ((str = selinux_translations_path()) != NULL)
        printf("23 - selinux_translations_path is:\n\t%s\n\n", str);
    else
        perror("selinux_translations_path - ERROR");

    if ((str = selinux_user_contexts_path()) != NULL)
        printf("24 - selinux_user_contexts_path is:\n\t%s\n\n", str);
    else
        perror("selinux_user_contexts_path - ERROR");

    if ((str = selinux_users_path()) != NULL)
        printf("25 - selinux_users_path is:\n\t%s\n\n", str);
    else
        perror("selinux_users_path - ERROR");

    if ((str = selinux_usersconf_path()) != NULL)
        printf("26 - selinux_usersconf_path is:\n\t%s\n\n", str);
    else
        perror("selinux_usersconf_path -ERROR");

    if ((str = selinux_virtual_domain_context_path()) != NULL)
        printf("27 - selinux_virtual_domain_context_path is:\n\t%s\n\n", str);
    else
        perror("selinux_virtual_domain_context_path - ERROR");

    if ((str = selinux_virtual_image_context_path()) != NULL)
        printf("28 - selinux_virtual_image_context_path is:\n\t%s\n\n", str);
    else
        perror("selinux_virtual_image_context_path - ERROR");

    if ((str = selinux_x_context_path()) != NULL)
        printf("29 - selinux_x_context_path is:\n\t%s\n\n", str);
    else
        perror("selinux_x_context_path - ERROR");

    if ((str = selinux_sepgsql_context_path()) != NULL)
        printf("30 - selinux_sepgsql_context_path is:\n\t%s\n\n", str);
    else
        perror("selinux_sepgsql_context_path - ERROR");

    if ((str = selinux_lxc_contexts_path()) != NULL)
        printf("31 - selinux_lxc_contexts_path is:\n\t%s\n\n", str);
    else
        perror("selinux_lxc_contexts_path - ERROR");

    if ((str = selinux_systemd_contexts_path()) != NULL)
        printf("32 - sselinux_systemd_contexts_path is:\n\t%s\n\n", str);
    else
        perror("selinux_systemd_contexts_path - ERROR");

    exit(0);
}
