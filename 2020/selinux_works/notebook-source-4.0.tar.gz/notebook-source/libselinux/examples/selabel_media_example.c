#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <selinux/selinux.h>
#include <selinux/label.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main (int argc, char **argv)
{
    char answer[8];
    struct selabel_handle *hnd;
    security_context_t selabel_context;
    char *device, *media_contexts_path, *validate = NULL;

    struct selinux_opt selabel_option [] = {
		{ SELABEL_OPT_PATH, media_contexts_path },
		{ SELABEL_OPT_VALIDATE, validate }
	};

#ifdef INFO
    printf("\nThe selabel_media example will show the context that will be "
				"applied to a media\nobject instance. The example will loop "
				"asking for a device type to be selected\n(e.g. cdrom). "
				"The objects context will then be displayed.\n"
				"Press 'q' to quit and call selabel_stats, or return to "
				"continue.\n");

	printf("\nThe example will ask for an media contexts file to be selected, "
				"if you want the\ndefault select NULL. Then select whether the "
				"contexts are to be validated or\nnot."
				"\nPress return to continue\n");
	getchar();
#endif

	get_config_entry("[media_contexts_path]", &media_contexts_path);
    if ((strcmp(media_contexts_path, "NULL")) == 0)
        media_contexts_path = NULL;

	printf("\nDo you want to validate contexts? [y/n]");
	fflush(stdin);
	fgets(answer, sizeof(answer), stdin);
	if ((answer[0] == 'y') || (answer[0] == 'Y'))
		validate = (char *)1;

	selabel_option[0].value = media_contexts_path;
	selabel_option[1].value = validate;

    printf("Executing: selabel_open(SELABEL_CTX_MEDIA, selabel_option, 2)\n");
	if ((hnd = selabel_open(SELABEL_CTX_MEDIA, selabel_option, 2)) == NULL) {
	    perror("selabel_open - ERROR");
	    exit(1);
	}

    while(1) {
        get_config_entry("[device]", &device);
        printf("Executing: selabel_lookup_raw(hnd, &selabel_context, %s, 0)\n",
                                                                    device);

        if (selabel_lookup_raw(hnd, &selabel_context, device, 0) == 0) {
            printf("The media context to be applied is: %s\n", selabel_context);
	        freecon(selabel_context);
        } else {
			switch (errno) {
				case ENOENT:
					printf("\nselabel_lookup failed to find a context."
										"\n\tERROR: %s\n", strerror(errno));
					break;
				case EINVAL:
					printf("\nselabel_lookup failed to validate context, or "
								"the device is invalid."
										"\n\tERROR: %s\n", strerror(errno));
					break;
				default:
					printf("\nselabel_lookup ERROR: %s\n", strerror(errno));
					break;
			}
		}
		free(device);
        printf("\nq for Quit and display file selabel_stats or "
                                                    "return to continue.\n");
        fgets(answer, sizeof(answer), stdin);
        if (answer[0] == 'q') {
            printf("selabel_stats returned:\n");
            selabel_stats(hnd);
            break;
        }
	}
    selabel_close(hnd);
    exit(0);
}
