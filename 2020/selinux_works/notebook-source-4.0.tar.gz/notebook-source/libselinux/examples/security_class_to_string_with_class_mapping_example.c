#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <selinux/selinux.h>

/* this include file was built using the build-policy.py script as follows:
 * 	build-policy.py -i -r <refpolicy_base> -o example_access_vectors.h
 *
 * The build-policy.py script is in the 'tools' directory.
 */
#include "../include/example_access_vectors.h"

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    const char *str = NULL;
    security_class_t tclass;
    char *string;

#ifdef INFO
    printf("\nThe security_class_to_string_with_class_mapping example requires "
				"a class ID\nto be selected (e.g '1'), the string value "
				"will then be displayed.\n"
				"\nNotes 1) This example calls the libselinux selinux_set_"
                "mapping function to set\n         object classes (and "
				"permissions) to those defined in the Fedora 16"
				"\n          Policy 3.10.0 (the last class defined is "
				"'service' whose ID is 82).\n"
                "\n      2) When building policy, strings are used to define "
				"classes, the kernel\n         will then assign the numbers "
				"as it loads the policy. The order of the\n         numbering "
				"is the order that the classes are defined in the policy"
				"\n         source file (for the Reference Policy the "
				"'security' object class\n         is first and is therefore "
				"'1').\nPress return to continue\n");
    getchar();
#endif

/*
 * The "example_access_vectors.h" header file used by this function
 * will set the Class and Permission mapping in the same order as those in
 * the Fedora 16 Reference Policy source "security_class" file.
 */
    printf("Executing: selinux_set_mapping(map);\n");
    if (selinux_set_mapping(map) < 0) {
        if (errno == EINVAL) {
            printf("Invalid object class mapping\n");
           exit(1);
       }
       printf("Could not set up the object class mapping\n");
        exit(1);
    }

	printf("\nThe selinux_set_mapping is complete, therefore all object "
				"classes defined\nin Fedora 16 Reference Policy version "
				"can be selected.\n");

    get_config_entry("[class_flask]", &string);
    tclass = strtol(string, (char **)&string[3], 10);
    free(string);

    printf("Executing: security_class_to_string(%d);\n", tclass);

    if ((str = security_class_to_string(tclass)) != NULL)
        printf("The class requested is: %s\n", str);
    else
        perror("security_class_to_string - ERROR");

    exit(0);
}
