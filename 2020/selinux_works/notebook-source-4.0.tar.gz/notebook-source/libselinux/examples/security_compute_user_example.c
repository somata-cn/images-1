#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <selinux/selinux.h>
#include <selinux/get_context_list.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    char *user;
    security_context_t fromcon;
    security_context_t *reachable;
    int rc, i = 0;

#ifdef INFO
    printf("\nThe security_compute_user example requires a user and context "
				"to be selected. The reachable contexts will then be "
				"returned.\n\nNote that this call can fail with errno = 34 "
				"(Numerical result out of range)\nas the returned results are "
				"too large for the buffer (selinux_page_size =\n"
				"sysconf(_SC_PAGE_SIZE);).\n"
				"\nTry the Fedora 'targeted' policy with user = unconfined_u "
				"and context =\nunconfined_u:unconfined_r:unconfined_t:s0, "
				"and the function should fail.\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[user]", &user);
    get_config_entry("[raw_context]", &fromcon);

    printf("\nExecuting: security_compute_user_raw(%s, %s, &reachable);\n",
                                                            fromcon, user);

    if ((rc = security_compute_user_raw(fromcon, user, &reachable)) < 0) {
        perror("security_compute_user_raw - ERROR");
        /* If errno = 34 (ERANGE) then the return buffer is too large for
	     * kernel to pass back as SIMPLE_TRANSACTION_LIMIT exceeded (this is
	     * PAGE_SIZE - a little bit) */
        if (errno == ERANGE)
	        printf("errno = ERANGE. This means that there are too many "
	                                                   "entries to return.\n");
        exit(1);
    }

    if (reachable[i] == NULL)
        printf("\nNo reachable contexts were found.\n");
    else {
        printf("\nThe returned reachable contexts are:\n");
        for (i = 0; reachable[i] != NULL; i++)
            printf("Context %d = %s\n", i+1, reachable[i]);
    }
    freecon(fromcon);
    freeconary(reachable);
    exit(0);
}
