#include <stdio.h> 
#include <stdlib.h> 
#include <stdarg.h> 
#include <string.h>
#include <unistd.h>
#include <selinux/selinux.h> 
#include <selinux/avc.h> 

#include <selinux/flask.h> 
#include <selinux/av_permissions.h> 

/* show avc messages on screen in red */
static char red[] = "\033[0;31m";
static char reset[] ="\033[0m";

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

/* 
 * Function to print the AVC statistics. Because no audit logging call back
 * has been set, the avc_av_stats and avc_sid_stats information will be 
 * displayed on stderr.
 */
void print_stats(void)
{
    struct avc_cache_stats acs; 

    printf("The avc_av_stats and avc_sid_stats outputs are as follows:\n"); 
    avc_av_stats();
    avc_sid_stats();
     
    printf("\nThe avc_cache_stats are as follows:\n"); 
    avc_cache_stats(&acs); 
    printf("entry_lookups:  %d\t(Queries made)\n", acs.entry_lookups); 
    printf("entry_hits:     %d\t(Decisions found in aeref)\n", 
                                                            acs.entry_hits); 
    printf("entry_misses:   %d\t(Decisions not found in aeref)\n", 
                                                            acs.entry_misses); 
    printf("entry_discards: %d\t(Decisions not found in aeref that were also "
                                         "non-NULL)\n", acs.entry_discards); 
    printf("cav_lookups:    %d\t(Cache lookups)\n", acs.cav_lookups); 
    printf("cav_hits:       %d\t(Cache hits)\n", acs.cav_hits); 
    printf("cav_probes:     %d\t(Entries examined searching the cache)\n", 
                                                            acs.cav_probes); 
    printf("cav_misses:     %d\t(Cache misses)\n", acs.cav_misses); 
}



int main(int argc, char **argv) 
{ 
    security_context_t scon, tcon, check_con; 
    security_id_t ssid, tsid; 
    struct avc_entry_ref aeref;
    struct selinux_opt avc_option;
	security_class_t tclass;
	access_vector_t av_perm;
	struct av_decision avd;
    mode_t mode;
    int rc;
    char buf[80]; 

#ifdef INFO
    printf("\nThe avc_has_perm example requires a context and file or directory"
			" name to be\nselected. The avc_has_perm and avc_has_perm_noaudit "
			"calls will then be used to\ndetermine whether the file has "
			"execute permission or not.\nThe example will then ask whether the "
			"AVC statistics should be printed ('p') or\nthe cache reset ('r') "
			"and then loop requesting another file name.\n"
			"\nNote that all logging information is written to stderr.\n");

	printf("\nNotes 1) If NULL is selected for the context, then getcon "
			"will be called\n         and the current process context will be "
			"used.\n"
			"      2) As there are two queries performed for each file name "
			"(avc_has_perm\n         and avc_has_perm_noaudit), the statistics"
			" entry_lookups and\n         entry_hits will always increment by "
			"two.\n"
			"      3) The avc_has_perm uses the flask values for 'file' and "
			"'execute'\n         permission whereas avc_has_perm_noaudit, "
			"uses those derived from\n         string_to_security_class and "
			"string_to_av_perm.\n"
			"      4) The audit messages such as policy reloaded and avc "
			"denials will only\n         be displayed when avc_has_perm* "
			"functions called.\n"
			"      5) Because the userspace AVC is used, a number of "
			"other\n         functions also need to be called, these are "
			"listed below.\nPress return to continue\n");
	getchar();

	printf("security_getenforce\n    Checks enforcement mode.\n"
			"\navc_open\n    The option AVC_OPT_SETENFORCE is set to "
			"force the userspace AVC into\n    enforcing mode whether SELinux "
			"itself is in Permissive or Enforcing mode.\n"
			"\navc_entry_ref_init\n    Ensure that the aeref entry is NULL.\n"
			"\ngetcon\n    Get current context if NULL is selected.\n"
			"\navc_context_to_sid\n    Convert context to SID.\n"
			"\navc_sid_to_context\n    Convert SID to context.\n"
			"\nstring_to_security_class\n    Get file class ID."
			"\nPress return to continue\n");
	getchar();

	printf("string_to_av_perm\n    Get execute permission ID."
			"\ngetfilecon\n    Retrieve the file context (if it exists).\n"
			"\nmatchpathcon\n    Get the context from the file_contexts file "
			"if the file does not exist\n    (note that this loads the "
			"file_context file and therefore adds a large\n    overhead).\n"
			"\navc_has_perm and avc_has_perm_noaudit\n    Check if execute "
			"permission is allowed on the file.\n"
			"\navc_audit\n    Called when avc_has_perm_noaudit returns "
			"'denied'.\n"
			"\navc_av_stats, avc_sid_stats and avc_cache_stats\n"
			"    Display statistics.\n"
			"\navc_reset and avc_destroy\n    Reset the AVC cache. "
			"Destroy AVC cache.\nPress return to continue\n");
	getchar();
#endif

    if (security_getenforce() == 1)
        printf("SELinux is currently in Enforcing mode\n");
    else 
        printf("SELinux is currently in Permissive mode - But setting "
									"application to Enforcing mode\n");
    
	avc_option.type = AVC_OPT_SETENFORCE;
	avc_option.value = (char *)1;

    /* Open with the one option set */
	printf("\nExecuting: avc_open(&avc_option, 1);\n");
    if (avc_open(&avc_option, 1) < 0) {
        printf("avc_open - ERROR %s\n", strerror(errno));
        exit(1);
    }
	printf("The avc_has_perms_example is set to enforcement mode.\n");

    /* 
     * NOTE: There must be a avc_entry_ref_init call when using the thread 
     * library otherwise avc_has_perm_noaudit will cause core dump.
     */
	printf("\nExecuting: avc_entry_ref_init(&aeref);\n");
    avc_entry_ref_init(&aeref);    


	/* Let user select a context to use */
    get_config_entry("[raw_context]", &scon);
	/* If NULL then get the current process context */ 
	if (strcmp(scon, "NULL") == 0) {
		printf("\nExecuting: getcon_raw(&scon);\n");
    	if (getcon_raw(&scon) < 0) { 
        	printf("Could not get context for this process - ERROR %s\n", 
                                                            strerror(errno));
        	avc_destroy(); 
        	exit(1); 
    	} 
	}

	/* Get a SID for the context */
	printf("Executing: avc_context_to_sid(%s, &ssid);\n", scon);
    if (avc_context_to_sid_raw(scon, &ssid) < 0) { 
        printf("Could not get SSID - ERROR %s\n", strerror(errno));
        avc_destroy(); 
        exit(1); 
    } 

	/* Now use avc_sid_to_context to get the context again as a check */
	printf("\nExecuting: avc_sid_to_context(ssid, &check_con);\n");
    if (avc_sid_to_context_raw(ssid, &check_con) < 0) { 
        printf("Could not get context from SID - ERROR %s\n", strerror(errno));
        avc_destroy(); 
        exit(1); 
    }
	if (strcmp(scon, check_con) != 0) {
        printf("ERROR - The scon and check_con context do not match\n");
        avc_destroy(); 
        exit(1); 
    } 
    printf("Function avc_sid_to_context_raw returned matching context\n");
    freecon(scon);
    freecon(check_con);

	/* 
	 * The avc_has_perm call will use the flask.h and av_permissions.h entries
	 * However the avc_has_perm_noaudit call will use those retrieved via the
	 * string_to_security_class and string_to_av_perm calls.
	 *
	 * Note it is recommended that the string_to_security_class and 
	 * string_to_av_perm calls are used. This is because they will always
	 * retrieve the correct values whereas the flask entries may not always
	 * be correct.
	 */

	/* Get the class id for a file object */
	printf("\nExecuting: string_to_security_class(\"file\");\n");
    if ((tclass = string_to_security_class("file")) != 0)
        printf("\tThe value assigned to the \"file\" class is: %d\n", tclass);
    else 
        printf("string_to_security_class - ERROR %s\n", strerror(errno));
	/* Then get the permission bit for 'execute'.*/
	printf("Executing: string_to_av_perm(tclass, \"execute\");\n");
    if ((av_perm = string_to_av_perm(tclass, "execute")) != 0)
        printf("\tThe permission bit for \"execute\" is: 0x%08x\n", av_perm);
    else 
        printf("string_to_av_perm - ERROR %s\n", strerror(errno));

    /* Read file or directory name from stdin */
    while (1) { 
        printf("\nEnter a file or directory name: ");
        fgets(buf, sizeof(buf), stdin);
		/* Remove the cr */
		buf[strlen(buf)-1] = 0;  

        /* 
		 * Get security context and SID for the file. Note that getfilecon 
		 * retrieves the context of a file that physically exists. If it
		 * does not exist then matchpathcon is called to see what context
		 * would be applied if it did.
		 */
		printf("\nExecuting: getfilecon_raw(%s, &tcon);\n", buf);
        if (getfilecon_raw(buf, &tcon) < 0) { 
            printf("\tgetfilecon_raw - Could not retrieve file context for "
                    "'%s'\n\tERROR: %s\n", buf, strerror(errno));

			mode = 0;
			printf("Therefore executing: matchpathcon(%s, 0x%x, &tcon);\n\n", 
																buf, mode);
    		if ((rc = matchpathcon(buf, mode, &tcon)) != 0) {
            	printf("\tmatchpathcon - Could not retrieve file context for "
								"'%s'\n\tERROR: %s\n", buf, strerror(errno));
            	continue; 
			}
		} 

        if (avc_context_to_sid_raw(tcon, &tsid) < 0) { 
            printf("Could not get SID for '%s'\n" 
					"ERROR: %s\n", buf, strerror(errno));
            continue; 
        }
		printf("File context (tcon) is: %s\n", tcon); 

		/* Note as audit callback is not implemented, the auditdata is NULL. */
		printf("\nExecuting: avc_has_perm(ssid, tsid, SECCLASS_FILE, "
									"FILE__EXECUTE, &aeref, NULL);%s\n", red);

//        rc = avc_has_perm(ssid, tsid, SECCLASS_FILE, FILE__EXECUTE, 
//                                                        	&aeref, NULL);
        rc = avc_has_perm(ssid, tsid, SECCLASS_FILE, FILE__EXECUTE, 
                                                        	&aeref, NULL);
		printf("%s", reset);

		if (rc == 0)
			printf("\tFile execute GRANTED for: %s\n", buf);
		else if (errno == EACCES) 
			printf("\tFile execute DENIED for: %s\n\tavc_audit is automatically "
						"called by avc_has_perm and outputs to stderr.\n", buf);
        else 
			printf("\tUnexpected error: %s\n", strerror(errno));

		/* Now use avc_has_perm_noaudit */
		memset(&avd, 0, sizeof(avd));
		printf("\nExecuting: avc_has_perm_noaudit(ssid, tsid, tclass, "
												"av_perm, &aeref, &avd);\n");
		rc = avc_has_perm_noaudit(ssid, tsid, tclass, av_perm, &aeref, &avd);
		if (rc == 0)
			printf("\tFile execute GRANTED for: %s\n", buf);
		else if (errno == EACCES) 
            printf("\tFile execute DENIED for: %s\n", buf); 
        else 
			printf("\tUnexpected error: %s\n", strerror(errno));

		/* Always call avc_audit to ensure mandatory policy events (auditallow)
		 * are always audited. Note as audit callback is not implemented, the
		 * auditdata is NULL. Output is to stderr. */
		printf("\nNow executing: avc_audit(ssid, tsid, tclass, "
					"av_perm, &avd, rc, NULL);\n"
					"The output (if any) will be to stderr.\n%s\n", red);
		avc_audit(ssid, tsid, tclass, av_perm, &avd, rc, NULL);
		printf("%s", reset);

		/* Now see if to continue , reset cache or display stats */
        printf("\nPress 'p' to print stats or 'r' to reset AVC cache or "
													"return to continue.\n");
        fgets(buf, sizeof(buf), stdin);
        if (buf[0] == 'p') {
			print_stats();
			continue;
		}
        if (buf[0] == 'r') {
            printf("Calling avc_reset to flush AVC cache.\n");
            avc_reset();
            continue;
        }        
        if (buf[0] == 'q') {
			print_stats();
			avc_destroy();
		    exit(0); 
   		} 
    } 
	print_stats();
    avc_destroy();
    exit(0); 
}
