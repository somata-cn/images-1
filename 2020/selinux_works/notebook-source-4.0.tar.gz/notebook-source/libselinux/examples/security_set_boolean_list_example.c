#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern char *config_file;
void get_config_boollist(char *entry, SELboolean ** boollist, size_t * boolcnt);

int main(int argc, char **argv)
{
    int rc, i;
    int permanent = 1;
    size_t boolcnt;
    SELboolean *boollist;

#ifdef INFO
    printf("\nThe security_set_boolean_list example requires a list of booleans"
                " that will be\ntaken from the [boolean_list] entry in %s "
                "file.\n", config_file);

	printf("\nNotes 1) This function has the 'permanent' flag set to '1' "
				"(true) therefore\n         writing the booleans to the "
				"%s.local file.\n         The format of the booleans.local "
				"file is as follows:\n\t\t<boolean_name> <true | false | "
				"0 | 1>\n", selinux_booleans_path());


	printf("\n      2) If the booleans are all valid then "
				"security_commit_booleans is\n         automatically "
				"called to activate them in the loaded policy.\n         This "
				"will also trigger a policy reload notice that is sent to "
				"\n         all object managers with a policy reload callback "
				"function,\n         also for each boolean changed in the "
				"loaded policy, a\n         MAC_CONFIG_CHANGE audit event "
				"will be logged.\nPress return to continue\n");
    getchar();
#endif

    get_config_boollist("[boolean_list]", &boollist, &boolcnt);
    printf("Found %d boolean_list entries:\n", (int)boolcnt);

    for (i =0; i<boolcnt; i++)
          printf("\tEntry %d: %s = %d\n", i+1, boollist[i].name,
														boollist[i].value);

    printf("\nExecuting: security_set_boolean_list(boolcnt, boollist, "
															"permanent);\n");

    if ((rc = security_set_boolean_list(boolcnt, boollist, permanent)) == -1) {
        printf("FAILED to set boolean list\n");
        perror("security_set_boolean_list - ERROR");
    } else {
        printf("\nCommited the list of booleans. ");
        if (permanent)
            printf("Also wrote updates to \n\t%s.local",
													selinux_booleans_path());
    }
    printf("\n\n");
    exit(0);
}
