#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <selinux/selinux.h>

#define MAXBUFFERSIZE 256

int main(int argc, char *argv[])
{
	int	rc, sock_fd, new_sock_fd;
	struct sockaddr_in client_addr;
	socklen_t sin_size;
	char buffer[MAXBUFFERSIZE];
	security_context_t context, peer_context;
	char *peer_context_str;
    struct addrinfo hints;
	struct addrinfo *result, *ptr;

#ifdef INFO
    printf("\nThe getpeercon_server example will listen on the specified "
                "port for a connection\nfrom the getpeercon_client_example. "
				"Once a connection has been established the\nrelevant context "
                "and connection information is displayed and also sent to\nthe "
                "client where it will also be displayed.\n");

    printf("\nThe peer context needs to be set by the netlabelctl command "
                "that is supplied in\nthe netlabel_tools package. To set "
                "this and check it is working the following\nis required:\n"
                "\n   1) The getpeercon_example.conf module needs to be loaded "
                "as this will allow\n      the 'netlabel_peer_test_t' type "
                "to be added and enable the required\n      ingress and "
				"recvfrom permissions.\n");

    printf("\n   2) The netlabelctl command needs to be run as follows:\n\n"
                "netlabelctl unlbl add interface:lo address:127.0.0.1 "
                "label:system_u:object_r:netlabel_peer_test_t:s0\n"
				"\nPress return to continue\n");
	getchar();
#endif

	if (argc < 2) {
		printf("Usage: %s <port>\n", argv[0]);
		exit(1);
	}

	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = AF_UNSPEC;        /* Allow IPv4 or IPv6 */
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;        /* For wildcard IP address */
	hints.ai_protocol = 0;              /* Any protocol */
	hints.ai_canonname = NULL;
	hints.ai_addr = NULL;
	hints.ai_next = NULL;

	rc = getaddrinfo(NULL, argv[1], &hints, &result);
	if (rc != 0) {
        printf("getaddrinfo ERROR: %s\n", gai_strerror(rc));
        exit(1);
	}

	/*
     * getaddrinfo() returns a list of address structures. Try each address
     * until connection. If fail close the socket and try the next address.
     */
	for (ptr = result; ptr != NULL; ptr = ptr->ai_next) {
        sock_fd = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);

        if (sock_fd == -1)
    		continue;

        /* Show peer context if available (should not be until accept) */
	    printf("\nNote that on socket open there is no peer context (however, "
                    "for the Reference\nPolicy this is normally set to "
                    "'unlabeled_t' for the open):\n");
	    if ((rc = getpeercon_raw(sock_fd, &peer_context)) < 0)
		    printf("   socket open - No Peer Context Available\n\n");
	    else {
		    printf("   socket open - Peer Context: %s\n\n", peer_context);
		    freecon(peer_context);
	    }

    	if (bind(sock_fd, ptr->ai_addr, ptr->ai_addrlen) == 0)
    		break;		/* Success */

    	close(sock_fd);
	}

    /* No address succeeded */
	if (ptr == NULL) {
        printf("Could not bind to any address.\n");
        exit(1);
    }

    /* Free the address structures */
	freeaddrinfo(result);

    printf("Listening on port %s\n", argv[1]);
	if (listen (sock_fd, 5) == -1) {
		perror("Server listen - ERROR");
		exit(1);
	}

	while (1) {
		sin_size = sizeof(struct sockaddr_in);
        printf("Waiting on accept for connection.\n");
		if ((new_sock_fd = accept(sock_fd, (struct sockaddr *)&client_addr,
		                                                &sin_size)) == -1) {
			perror("Server accept - ERROR");
			continue;
        }
        /* Get context assigned to the new socket */
        if ((rc = fgetfilecon_raw(new_sock_fd, &context)) == -1) {
        perror("fgetfilecon_raw - ERROR");
        exit(1);
        }
        printf("accept on new socket - Context assigned to new socket is "
                                    "(using fgetfilecon):\n\t%s\n", context);
        freecon(context);
        /* And then check if a peer context is assigned to this new socket */
	    if ((rc = getpeercon_raw(new_sock_fd, &peer_context)) < 0)
		    printf("accept on new socket - No Peer Context Available\n\n");
	    else {
		    printf("accept on new socket - Peer Context: %s\n\n", peer_context);
		    freecon(peer_context);
	    }

		if ((rc = getcon_raw(&context)) < 0) {
			perror("getcon_raw - ERROR");
			exit(1);
		}

		if ((rc = getpeercon_raw(new_sock_fd, &peer_context)) < 0)
			peer_context_str = strdup("No Peer Context Available");
		else {
			peer_context_str = strdup(peer_context);
			freecon(peer_context);
		}
		/* Clear the buffer of rubbish */
		memset(buffer, 0, sizeof(buffer));

		/* Print Server network information */
		printf("Server has connection from client: host = %s\n\tdestination "
			            "port = %s source port = %d\n",
			            inet_ntoa(client_addr.sin_addr),
			            argv[1],
			            ntohs(client_addr.sin_port));


		printf("Server Context: %s\nServer Peer Context: %s\n",
			            context, peer_context_str);

		sprintf(buffer, "This is from the server listening on port: "
			            "%s\nClient source port: %d\nServer Context: %s\n"
			            "Server Peer Context: %s \n",
			            argv[1],
			            ntohs(client_addr.sin_port),
			            context, peer_context_str);

		if (send(new_sock_fd, buffer, strlen(buffer), 0) == -1)
				perror("Server send - ERROR");

		freecon(context);
		close(new_sock_fd);
	}
	exit(0);
}
