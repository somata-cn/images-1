/*
 * basic_get_boolean_names_example - This will read the /selinux/booleans
 * directory and extracts the current boolean names. It will then take each
 * name, append it to form /selinux/booleans/<boolean_name>, and then read the
 * current and pending values for that boolean. All the boolean names will
 * be printed along with their current and pending values.
 *
 * This code has been derived from the libselinux source.
 */

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <limits.h>
#include <dirent.h>
#include <selinux/selinux.h>

/* selinuxfs mount point */
extern char *selinux_mnt;

/* This function takes a boolen name and prints its current and pending value */
void print_boolean_values(char * name)
{
	char buf[4] ="\0\0\0\0";
	int fd, rc, value, pending;
	char path[PATH_MAX];

	sprintf(path, "%s/booleans/%s", selinux_mnt, name);
	if ((fd = open(path, O_RDWR)) < 0) {
	    perror("OPEN FAILED");
	    exit(1);
	}
/*
 * The returned buffer will be 3 bytes long and will consist of:
 *          byte 0        - byte 1 -         byte 2
 * Current value (0 or 1) - space  - Pending value (0 or 1)
*/
	if ((rc = read(fd, buf, sizeof(buf))) < 0) {
	    perror("READ FAILED");
	    exit(1);
	}
    value = atoi(&buf[0]);
    pending = atoi(&buf[2]);
    printf("Its current value is %s and its pending value is %s\n\n",
                                            value ? "true" : "false",
                                            pending ? "true" : "false");
    return;
}

/*
 * This function is used to get the boolean file name entries from
 * the /selinux/booleans directory via the scandir() call.
 */
int filename_select(const struct dirent *d)
{
	if (d->d_name[0] == '.'
	    && (d->d_name[1] == '\0'
		|| (d->d_name[1] == '.' && d->d_name[2] == '\0')))
		return 0;
	return 1;
}

int main(int argc, char **argv)
{
	int selinux_page_size = sysconf(_SC_PAGE_SIZE);
	char path[PATH_MAX];
	struct dirent **namelist;
	char *buf;
	int i, entries;


    if ((buf = malloc(selinux_page_size)) == NULL) {
	    perror("MALLOC FAILED");
	    exit(1);
	}

	sprintf(path, "%s/booleans", selinux_mnt);
	entries = scandir(path, &namelist, &filename_select, alphasort);
	if (entries == 0)
	    printf("No boolean entries found\n");
	    else {
            printf("There are %d booleans defined in %s:\n\n", entries, path);
	        for (i = 0; i < entries; i++) {
		        printf("%d - boolean name: %s\n", i+1, namelist[i]->d_name);
		        print_boolean_values(namelist[i]->d_name);
            }
        }

	free(buf);
	exit(0);
}
