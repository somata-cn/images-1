#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <limits.h>
#include <selinux/selinux.h>
#include <selinux/label.h>
#include <sepol/sepol.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

/*
 * This routine will validate the selected file context against those
 * defined in the policy. It is set-up by the selinux_set_callback function.
 */
int validate_policy(char **contextp)
{
    char *context = *contextp;
	int rc;

	printf("---------- Start %s callback function -----------\n", __FUNCTION__);

	if (sepol_check_context(context) < 0) {
        printf("\nsepol_check_context validated default context as "
								"INVALID:\n\t%s\n", context);
        printf("sepol_check_context - ERROR %s\n", strerror(errno));
        rc = -1;
    }
    else {
   	    printf("sepol_check_context validated default context as VALID:"
														"\n\t%s\n", context);
    	rc = 0;
    }
	printf("---------- End %s callback function -----------\n\n", __FUNCTION__);
	return rc;
}



/* This file is created as a log file in CWD */
static char log_file_name[] = "selabel.log";

/* This callback is invoked whenever an message needs to be logged. */
int cb_log_file(int type, const char *fmt, ...)
{
    FILE *fp;

    if ((fp = fopen(log_file_name, "a+")) == NULL) {
        printf("Cannot create %s\n", log_file_name);
        perror("ERROR");
        return -1;
    }
	/* Print the type of error being logged */
    switch (type) {
        case SELINUX_ERROR:
        	fprintf(fp, "SELINUX_ERROR: ");
        	break;
        case SELINUX_WARNING:
        	fprintf(fp, "SELINUX_WARNING: ");
	        break;
        case SELINUX_INFO:
			fprintf(fp, "SELINUX_INFO: ");
    		break;
        case SELINUX_AVC:
        	fprintf(fp, "SELINUX_AVC: ");
    		break;
        default:
        	fprintf(fp, "SELINUX_UNKNOWN: ");
		    break;
    }
	/* Now print the message */
 	va_list ap;
	va_start(ap, fmt);
	vfprintf(fp, fmt, ap);
	va_end(ap);
	fclose(fp);
	return 0;
}




/* --------------- Start Here ----------------------- */
int main (int argc, char **argv)
{
    char answer[8];
    int mode;
    struct selabel_handle *hnd;
    security_context_t selabel_context;
    char *policyfile, *path, *file_contexts_path;
    char policy_path[PATH_MAX];
    FILE *policystream;
    int ver = security_policyvers();

    /* The selabel_open options are VALIDATE contexts and use specified path */
    struct selinux_opt selabel_option[] = {
        { SELABEL_OPT_VALIDATE, (char *)1 },
        { SELABEL_OPT_PATH, file_contexts_path }
    };

#ifdef INFO
    printf("\nThe selabel_policy_file_log example will show the default "
				"context that should\nbe applied to a file using the selected "
				"binary policy file and associated\nfile_contexts file (and "
				"their corresponding .homedirs and .local files).\n\n");

    printf("The example requests a binary policy file name and then a "
                "file_contexts file.\nOnce selected the example will validate "
                "each file_contexts entry (because\nthe SELABEL_OPT_VALIDATE "
				"option is set), and then loop asking for a file name\nto be "
				"selected. The files default context will then be displayed."
				"\nPress 'q' to quit and call selabel_stats, or return to "
				"continue.\n");

	printf("\nNote that the warning messages are output to a log file "
				"(selabel.log) in the\nCWD by setting a callback function with "
				"selinux_set_callback.\nPress return to continue\n");
    getchar();
#endif

    /*
     * Set the callback to our validate_policy routine. This replaces the
     * default security_check_context that would validate against the active
     * policy.
     */
	printf("Executing: selinux_set_callback(SELINUX_CB_VALIDATE, &validate_policy);\n");
    selinux_set_callback(SELINUX_CB_VALIDATE,
                                (union selinux_callback)validate_policy);

	/*
	 * The SELINUX_CB_LOG callback is required to write AVC messages
	 * to an audit log. If not set then output is to stderr.
	 */
	printf("Executing: selinux_set_callback(SELINUX_CB_LOG, cb_log_file);\n");
    selinux_set_callback(SELINUX_CB_LOG, (union selinux_callback)cb_log_file);

    printf("\nSelect a binary policy file:");
    get_config_entry("[binary_policy]", &policyfile);
    if ((strcmp(policyfile, "CURRENT")) == 0)
        snprintf(policy_path, sizeof(policy_path), "%s.%d", selinux_binary_policy_path(), ver);
	else
		snprintf(policy_path, sizeof(policy_path), "%s", policyfile);
	free(policyfile);

	policystream = fopen(policy_path, "r");
	if (!policystream) {
        printf("ERROR - opening policy file: %s\n%s\n", policy_path,
                                                            strerror(errno));
		exit(1);
	}

    printf("Executing: sepol_set_policydb_from_file(%s);\n", policy_path);
	if (sepol_set_policydb_from_file(policystream) <  0) {
        printf("ERROR - reading policy file: %s\n%s\n", policy_path,
                                                            strerror(errno));
		exit(1);
    }
	fclose(policystream);
    printf("Policy file opened\n\n");

    /* Get the file_context location */
    printf("Now select the file_contexts location (NULL = current):");
    get_config_entry("[file_contexts_path]", &file_contexts_path);
    if ((strcmp(file_contexts_path, "NULL")) == 0)
        file_contexts_path = NULL;
    /* Set the SELABEL_OPT_PATH option to the selected file_contexts path */
	selabel_option[1].value = file_contexts_path;

    printf("Executing: selabel_open(SELABEL_CTX_FILE, selabel_option, 2)\n\n");
	if ((hnd = selabel_open(SELABEL_CTX_FILE, selabel_option, 2)) == NULL) {
	    printf("ERROR - selabel_open failed: %s\n", strerror(errno));
	    exit(1);
	}
	free(file_contexts_path);

    /* Set the file mode to '0' */
    mode = 0;

    while(1) {

        printf("Obtaining [path] entries:\n");
        get_config_entry("[path]", &path);

        printf("Executing: selabel_lookup_raw(hnd, &selabel_context, "
                                                    "%s, %d)\n", path, mode);
        /* Using the _raw function as don't want the labels translated */
        if (selabel_lookup_raw(hnd, &selabel_context, path, mode) == 0) {
            printf("The default context that will be assigned is: \n\t%s\n",
                                                            selabel_context);
	        freecon(selabel_context);
		} else {
			printf("\nselabel_lookup ERROR %s\n", strerror(errno));
			switch (errno) {
				case ENOENT:
					printf("Failed to find a default context.\n");
					break;
				case EINVAL:
					printf("Failed to validate context, or the path / mode "
															"are invalid.\n");
					break;
			}
		}
		free(path);
        printf("\nq for Quit and display selabel_stats or "
                                                    "return to continue.\n");
        fgets(answer, sizeof(answer), stdin);
        if (answer[0] == 'q') {
            printf("selabel_stats returned:\n");
            selabel_stats(hnd);
			break;
        }
	}
	selabel_close(hnd);
    exit(0);
}
