/*
 * basic_compute_user - This will take an SELinux user and source context
 * then writes it to /selinux/context. The next read will then return the
 * list of reachable contexts for that user/context.
 *
 * Note: In some cases the number of returned entries exceeds the capacity
 * of the buffer and the read returns errno = 34 (ERANGE). 
 *
 * Using the Fedora targeted policy it is possible to get this error by:
 *    user = system_u and
 *    context = unconfined_u:unconfined_r:unconfined_t:s0-s0:c0.c1023
 *
 * This code has been derived from the libselinux source.
 */

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <limits.h>
#include <selinux/selinux.h>

/* selinuxfs mount point */
extern char *selinux_mnt;

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t fromcon;
	int selinux_page_size = sysconf(_SC_PAGE_SIZE);
	char path[PATH_MAX];
	char *buf, *ptr;
	int fd, rc, i, entries;
    char *user;

    printf("The basic_compute_user example requires a user and context "
            "entry to be selected.\nPress return to continue\n");
    getchar();
    get_config_entry("[user]", &user);
    get_config_entry("[raw_context]", &fromcon);

	sprintf(path, "%s/user", selinux_mnt);
	if ((fd = open(path, O_RDWR)) < 0) {
	    perror("OPEN FAILED");
	    exit(1);
	}

    if ((buf = malloc(selinux_page_size)) == NULL) {
	    perror("MALLOC FAILED");
	    exit(1);
	}

	snprintf(buf, selinux_page_size, "%s %s", fromcon, user);
    printf("About to write scon, user, to %s:\n\t%s %s\n\n",
                                                        path, fromcon, user);
	if ((rc = write(fd, buf, strlen(buf))) < 0) {
	    perror("WRITE FAILED");
	    /* If errno = 34 (ERANGE) then the return buffer is too large for
	     * kernel to pass back as SIMPLE_TRANSACTION_LIMIT exceeded (this is
	     * PAGE_SIZE - a little bit) */
	    if (errno == ERANGE)
	        printf("errno = ERANGE. This means that there are too many "
	                                                    "entries to return\n");
	    exit(1);
	}

	memset(buf, 0, selinux_page_size);

	if ((rc = read(fd, buf, selinux_page_size - 1)) < 0) {
	    perror("READ FAILED");
	    exit(1);
	}

    if (sscanf(buf, "%u", &entries) != 1) {
		printf("No context returned\n");
		exit(1);
	}

	if (entries == 0)
	    printf("There were no reachable contexts returned\n");
	    else {
        	ptr = buf + strlen(buf) + 1;
            printf("There are %d returned reachable contexts:\n", entries);
	        for (i = 0; i < entries; i++) {
		        printf("Context %d = %s\n", i+1, ptr);
		        ptr += strlen(ptr) + 1;
            }
        }

	free(buf);
	close(fd);
	exit(0);
}
