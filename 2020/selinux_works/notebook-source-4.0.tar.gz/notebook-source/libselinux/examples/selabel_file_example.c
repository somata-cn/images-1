#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <selinux/selinux.h>
#include <selinux/label.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main (int argc, char **argv)
{
    char answer[8];
    mode_t mode;
    struct selabel_handle *hnd;
    security_context_t selabel_context;
    struct stat stat_buf;
    char *path, *subset, *file_contexts_path, *validate = NULL;

    struct selinux_opt selabel_option [] = {
		{ SELABEL_OPT_PATH, file_contexts_path },
		{ SELABEL_OPT_SUBSET, subset },
		{ SELABEL_OPT_VALIDATE, validate }
	};

#ifdef INFO
    printf("\nThe selabel_file example requires a file contexts file to be "
				"selected (choose\nNULL for the default), then a 'subset' "
				"prefix entry that will be used by\nselabel_open to select the "
				"entries to be processed. NULL can be selected that\nwill "
				"process all entries, finally whether the contexts should be "
				"validated or\nnot.\n\nOnce initialised, a file can be "
				"selected and the files default context will be\ndisplayed. "
				"Press 'q' to quit and call selabel_stats, or "
				"press return to select\nanother file.\n");

    printf("\nThe example will check if the file exists (to obtain the mode) "
				"using lstat.\nIf the file does not exist, then mode = 0 is "
				"used.\n\nNote 1) The context displayed is the 'default "
				"context' and not the context\nthat maybe set on the file (in "
				"the extended attribute). Use the\nselinux_file_context_verify_"
				"example to check if the file is set to the default."
				"\n\nNote 2) If the context specified in the file "
				"contexts series of files is\n<<none>>, then error ENOENT is "
				"returned.\nPress return to continue\n");
	getchar();
#endif

	get_config_entry("[file_contexts_path]", &file_contexts_path);
    if ((strcmp(file_contexts_path, "NULL")) == 0)
        file_contexts_path = NULL;

	get_config_entry("[subset]", &subset);
    if ((strcmp(subset, "NULL")) == 0)
        subset = NULL;

	printf("\nDo you want to validate contexts? [y/n]");
	fflush(stdin);
	fgets(answer, sizeof(answer), stdin);
	if ((answer[0] == 'y') || (answer[0] == 'Y'))
		validate = (char *)1;

	selabel_option[0].value = file_contexts_path;
	selabel_option[1].value = subset;
	selabel_option[2].value = validate;

    printf("Executing: selabel_open(SELABEL_CTX_FILE, &selabel_option, 3)\n\n");

	if ((hnd = selabel_open(SELABEL_CTX_FILE, selabel_option, 3)) == NULL) {
	    perror("selabel_open - ERROR");
	    exit(1);
	}


    while(1) {
        get_config_entry("[path]", &path);

		if (lstat(path, &stat_buf) != 0) {
			printf("\nCould not stat the file: %s\nHowever the default "
					"context that would apply to this file if created "
					"will be\ndisplayed.\n", strerror(errno));
	    	mode = 0;
		}
		else
			mode = stat_buf.st_mode;

        printf("Executing: selabel_lookup_raw(hnd, &selabel_context, %s, 0x%x);"
														"\n\n", path, mode);

        if (selabel_lookup_raw(hnd, &selabel_context, path, mode) == 0) {
			printf("The default context for the selected file is:\n\t%s\n",
															selabel_context);
	        freecon(selabel_context);
        } else {
			switch (errno) {
				case ENOENT:
					printf("\nselabel_lookup failed to find a context."
										"\n\tERROR: %s\n", strerror(errno));
					break;
				case EINVAL:
					printf("\nselabel_lookup failed to validate context, or "
								"the path / mode are invalid.\n\tERROR: %s\n",
															strerror(errno));
					break;
				default:
					printf("\nselabel_lookup ERROR: %s\n", strerror(errno));
					break;
			}
		}

		free(path);
        printf("\nq for Quit and display file selabel_stats or "
                                                    "return to continue.\n");
        fgets(answer, sizeof(answer), stdin);
        if (answer[0] == 'q') {
            printf("selabel_stats returned:\n");
            selabel_stats(hnd);
            break;
        }
	}
    selabel_close(hnd);
    exit(0);
}
