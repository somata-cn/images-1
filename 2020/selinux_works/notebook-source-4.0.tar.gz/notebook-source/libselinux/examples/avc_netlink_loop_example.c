#include <stdio.h> 
#include <stdlib.h> 
#include <stdarg.h> 
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <libaudit.h>
#include <selinux/selinux.h> 
#include <selinux/avc.h> 

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

static char om_info[] = "Sample AVC OM";

/* show callback messages on screen in red and thread/signal in green */
static char red[] = "\033[0;31m";
static char green[] = "\033[0;32m";
static char reset[] ="\033[0m";

/* audit file descriptor */
static int audit_fd;

/* Internal functions */
static int cb_audit(void *auditdata, security_class_t class, char *msgbuf,
			size_t msgbufsize);
static int cb_log(int type, const char *fmt, ...);
static int cb_setenforce(int enforcing);
static int cb_avc_add (u_int32_t event, security_id_t ssid, security_id_t tsid,
			security_class_t tclass, access_vector_t perms, 
			access_vector_t *out_retained);
static int cb_policyload(int seqno);
static void * netlink_thread(void * arg);
void print_stats(void);
/* End internal functions */



int main(int argc, char **argv) 
{ 
    security_context_t scon, tcon, check_con; 
    security_id_t ssid, tsid; 
	security_class_t tclass;
	access_vector_t av_perm;
    struct avc_entry_ref aeref; 
    mode_t mode;
    int rc;
    char buf[80], auditdata[80]; 
	union selinux_callback callback_info;
	pthread_t thread;

#ifdef INFO
    printf("\nThe avc_netlink_loop example is based on the "
			"avc_has_perm_callbacks example\nexcept that a thread is set up to "
			"execute the avc_netlink_loop function that\nwill process the "
			"netlink messages immediately.\n\nThe example requires a context "
			"and file or directory name to be selected.\nThe avc_has_perm "
			"call will then be used to determine whether the file has\n"
			"execute permission or not. The example will then ask whether the "
			"AVC statistics\nshould be printed ('p') or the cache reset ('r') "
			"or return to loop requesting\nanother file name.\n\nNote "
			"that all logging information is written to the audit log.\n");

	printf("\nNotes 1) If NULL is selected for the context, then a getcon "
			"will be called\n         and the current process context will be "
			"used.\n"
			"      2) Because the userspace AVC is used, a number of "
			"other functions also\n         need to be called, these are "
			"listed below.\nPress return to continue\n");
	getchar();

	printf("pthread_create\n    Set up a thread to run avc_netlink_loop.\n"
			"\navc_netlink_loop\n    Process netlink messages as they arrive.\n"
            "\navc_acquire_netlink_fd\n    Get netlink fd.\n"
            "\nselinux_set_callback, selinux_get_callback\n    Used to "
            "set/get the following callbacks: SELINUX_CB_LOG, SELINUX_CB_"
            "AUDIT,\n    SELINUX_CB_SETENFORCE and SELINUX_CB_POLICYLOAD\n"
			"\navc_add_callback\n    Set avc callback.\n"
			"\naudit_open\n    Open the audit log.\n"
			"\naudit_log_user_avc_message\n    Write entry into audit log.\n"
			"\nsecurity_getenforce\n    Checks enforcement mode."
			"\nPress return to continue\n");
	getchar();

	printf("avc_open\n    The AVC_OPT_SETENFORCE is NOT used so will follow "
			"SELinux Enforcing mode.\n"
			"\navc_entry_ref_init\n    Ensure that the aeref entry is NULL.\n"
			"\ngetcon\n    Get current context if NULL is selected.\n"
			"\navc_context_to_sid\n    Convert context to SID.\n"
			"\navc_sid_to_context\n    Convert SID to context.\n"
			"\nstring_to_security_class\n    Get file class ID.\n"
			"\nstring_to_av_perm\n    Get execute permission ID."
			"\nPress return to continue\n");
	getchar();

	printf("getfilecon\n    Retrieve the file context (if it exists)."
			"matchpathcon\n    Get the context from the file_contexts file "
			"if the file does not exist\n    (note that this loads the "
			"file_context file and therefore adds a delay).\n"
			"\navc_has_perm\n    Check if execute "
			"permission is allowed on the file.\n"
			"\navc_av_stats, avc_sid_stats and avc_cache_stats\n"
			"    Display statistics.\n"
			"\navc_netlink_release_fd, avc_netlink_close, audit_close and "
			"avc_destroy\n    Close all fd's.\nPress return to continue\n");
	getchar();
#endif

/* Setting up callback routines */
	/* 
	 * The only selinux_set_callback function parameter not used is  
	 * SELINUX_CB_VALIDATE. This is because it is for validating contexts that
	 * is not required for this example. See the selabel_policy_file_example
	 * for an example usage. The callback functions do not return any errors.
	 */

	/*
	 * The SELINUX_CB_LOG callback is required to write AVC messages
	 * to an audit log. If not set then output is to stderr.
	 */
	printf("Executing: selinux_set_callback(SELINUX_CB_LOG, cb_log);\n");
    selinux_set_callback(SELINUX_CB_LOG, (union selinux_callback)cb_log);

	/* 
	 * This callback is optional and used for adding supplemental auditing 
	 * information to AVC messages for avc_has_perm.
	 */
	printf("Executing: selinux_set_callback(SELINUX_CB_AUDIT, cb_audit);\n");
    selinux_set_callback(SELINUX_CB_AUDIT, (union selinux_callback)cb_audit);

	/* This callback is optional and used whenever enforcing mode changes. */
	printf("Executing: selinux_set_callback(SELINUX_CB_SETENFORCE, "
													"cb_setenforce);\n");
    selinux_set_callback(SELINUX_CB_SETENFORCE, 
								(union selinux_callback)cb_setenforce);

	/* This callback is optional and used whenever the policy is loaded. */
	printf("Executing: selinux_set_callback(SELINUX_CB_POLICYLOAD, "
													"cb_policyload);\n");
	selinux_set_callback(SELINUX_CB_POLICYLOAD, 
								(union selinux_callback)cb_policyload);

	/*
	 * Only executing one selinux_get_callback as it will return an address
	 * because a valid default libselinux routine is present at start-up. The 
	 * only time the address is invalid is when an invalid 'type' is requested.
	 */
	printf("Executing: selinux_get_callback(SELINUX_CB_SETENFORCE);\n");
	callback_info = selinux_get_callback(SELINUX_CB_SETENFORCE);
	if (callback_info.func_setenforce == NULL) {
		printf("selinux_get_callback(SELINUX_CB_SETENFORCE) - ERROR %s\n", 
                                                            strerror(errno));
		exit(1);
	}

	/* 
	 * The avc_add_callback function only calls back on the AVC_CALLBACK_RESET
	 * event. This maybe useful if you need to know the cache has been flushed.
	 */
	printf("Executing: avc_add_callback(cb_avc_add, ALL DEFINES);\n");
    if ((avc_add_callback(cb_avc_add, AVC_CALLBACK_GRANT | AVC_CALLBACK_RESET
			| AVC_CALLBACK_TRY_REVOKE | AVC_CALLBACK_REVOKE
			| AVC_CALLBACK_AUDITALLOW_ENABLE | AVC_CALLBACK_AUDITALLOW_DISABLE
			| AVC_CALLBACK_AUDITDENY_ENABLE | AVC_CALLBACK_AUDITDENY_DISABLE,
			NULL, NULL, 0, 0)) < 0) {
        printf("avc_add_callback - ERROR %s\n", strerror(errno));
        exit (1);
    }


	/* Open an audit fd as the standard audit log will be used. */
	printf("Executing: audit_fd = audit_open();\n");
    if ((audit_fd = audit_open()) < 0) {
    	printf("audit_open - ERROR %s\n", strerror(errno));
        exit(1);
    }

    /*
     * This checks whether SELinux is in enforcing mode or not.
     * To set OM always in ENFORCING mode:
     * 	   avc_option.type = AVC_OPT_SETENFORCE;
     * 	   avc_option.value = (char *)1; 
	 *
	 * To set OM always in PERMISSIVE mode:
     * 	   avc_option.type = AVC_OPT_SETENFORCE;
     * 	   avc_option.value = (char *)0;
	 *
	 * To follow the SELinux enforcment mode:
	 *     NEVER set the 'avc_option.type = AVC_OPT_SETENFORCE;' at all. 
     */
    if (security_getenforce() == 1)
        printf("\nSELinux is currently in Enforcing mode\n");
    else 
        printf("\nSELinux is currently in Permissive mode\n");
    
    /* Open with no options set */
	printf("Executing: avc_open(NULL, 0);\n");
    if (avc_open(NULL, 0) < 0) {
        printf("avc_open - ERROR %s\n", strerror(errno));
        exit(1);
    }
	printf("The avc_has_perms_callbacks_example will follow the SELinux "
										"enforcement status.\n");

	printf("\nCreating thread to run avc_netlink_loop\n");
	pthread_create(&thread, NULL, netlink_thread, NULL);

    /* 
     * NOTE: There must be a avc_entry_ref_init call when using the thread 
     * library otherwise avc_has_perm_noaudit will cause core dump.
     */
	printf("\nExecuting: avc_entry_ref_init(&aeref);\n");
    avc_entry_ref_init(&aeref);    

	printf("\nPress return to continue\n");
	getchar();

	/* Let user select a context to use */
    get_config_entry("[raw_context]", &scon);
	/* If NULL then get the current process context */ 
	if (strcmp(scon, "NULL") == 0) {
		printf("\nExecuting: getcon_raw(&scon);\n");
    	if (getcon_raw(&scon) < 0) { 
        	printf("getcon_raw - ERROR %s\n", strerror(errno));
        	avc_destroy(); 
        	exit(1); 
    	} 
	}

	/* Get a SID for the context */
	printf("Executing: avc_context_to_sid(%s, &ssid);\n", scon);
    if (avc_context_to_sid(scon, &ssid) < 0) { 
        printf("Could not get SSID - ERROR %s\n", strerror(errno));
        avc_destroy(); 
        exit(1); 
    } 
 
	/* Now use avc_sid_to_context to get the context again as a check */
	printf("\nExecuting: sid_to_context(ssid, &check_con);\n");
    if (avc_sid_to_context(ssid, &check_con) < 0) { 
        printf("Could not get context from SID - ERROR %s\n", strerror(errno));
        avc_destroy(); 
        exit(1); 
    }
	if (strcmp(scon, check_con) != 0) {
        printf("ERROR - The scon and check_con context do not match\n");
        avc_destroy(); 
        exit(1); 
    } 
    printf("Function avc_sid_to_context returned matching context\n");
    freecon(scon);
    freecon(check_con);

	/* 
	 * Note it is recommended that the string_to_security_class and 
	 * string_to_av_perm calls are used. This is because they will always
	 * retrieve the correct values whereas the flask entries may not always
	 * be correct.
	 */
	/* Get the class id for a file object */
	printf("\nExecuting: string_to_security_class(\"file\");\n");
    if ((tclass = string_to_security_class("file")) != 0)
        printf("\tThe value assigned to the \"file\" class is: %d\n", tclass);
    else 
        printf("string_to_security_class - ERROR %s\n", strerror(errno));
	/* Then get the permission bit for 'execute'.*/
	printf("Executing: string_to_av_perm(tclass, \"execute\");\n");
    if ((av_perm = string_to_av_perm(tclass, "execute")) != 0)
        printf("\tThe permission bit for \"execute\" is: 0x%08x\n", av_perm);
    else 
        printf("string_to_av_perm - ERROR %s\n", strerror(errno));

    /* Read file or directory name from stdin */
    while (1) { 
        printf("\nEnter a file or directory name: ");
		fflush(stdin);
		memset(buf, 0, sizeof(buf));
        fgets(buf, sizeof(buf), stdin);
		/* Remove the cr */
		buf[strlen(buf)-1] = 0;  

        /* 
		 * Get security context and SID for the file. Note that getfilecon 
		 * retrieves the context of a file that physically exists. If it
		 * does not exist then matchpathcon is called to see what context
		 * would be applied if it did.
		 */
		printf("\nExecuting: getfilecon_raw(%s, &tcon);\n", buf);
        if (getfilecon_raw(buf, &tcon) < 0) { 
            printf("\tgetfilecon_raw - Could not retrieve file context for "
                    "'%s'\n\tERROR: %s\n", buf, strerror(errno));

			mode = 0;
			printf("Therefore executing: matchpathcon(%s, 0x%x, &tcon);\n\n", 
																buf, mode);
    		if ((rc = matchpathcon(buf, mode, &tcon)) != 0) {
            	printf("\tmatchpathcon - Could not retrieve file context for "
								"'%s'\n\tERROR: %s\n", buf, strerror(errno));
            	continue; 
			}
		} 

        if (avc_context_to_sid(tcon, &tsid) < 0) { 
            printf("Could not get SID for '%s'\n" 
					"ERROR: %s\n", buf, strerror(errno));
            continue; 
        } 
		printf("The file context (tcon) is: %s\n", tcon);

		/* Add the supplemental AVC audit information so that it is logged. */
        sprintf (auditdata,"%s - Checking file: %s", om_info, buf);
	
		printf("\nExecuting: avc_has_perm(ssid, tsid, tclass, "
											"av_perm, &aeref, auditdata);\n");
        rc = avc_has_perm(ssid, tsid, tclass, av_perm, &aeref, auditdata);
		switch (rc) {
			case 0:
				printf("avc_has_perm - File execute GRANTED for: %s\n", buf);
				break;
			case -1:
			default:
				if (errno == EACCES) 
            		printf("avc_has_perm - File execute DENIED for: %s\n" 
									"avc_audit is automatically called by "
									"avc_has_perm - Entry in audit log\n", buf);
        		else 
            		printf("avc_has_perm - ERROR: %s\n", strerror(errno));
				break;
		}

		/* Now see if to continue , reset cache or display stats */
        printf("\nPress 'p' to print stats, 'r' to reset AVC cache, 'q' "
										"for quit or return to\ncontinue.\n");
		fflush(stdin);
		memset(buf, 0, sizeof(buf));
        fgets(buf, sizeof(buf), stdin);
        if (buf[0] == 'p') {
			print_stats();
			continue;
		}
        if (buf[0] == 'r') {
            printf("Calling avc_reset to flush AVC cache.\n");
            avc_reset();
            continue;
        }  

		if (buf[0] == 'q') {
			print_stats();
			/* Free all resources */
			avc_netlink_release_fd();
			avc_netlink_close();
			audit_close(audit_fd);
		    avc_destroy();
		    exit(0); 
    	}
	} 
	print_stats();
	/* Free all resources */
	avc_netlink_release_fd();
	avc_netlink_close();
	audit_close(audit_fd);
    avc_destroy();
    exit(0); 
} 




			/******** Start callback routines **********/
/* 
 * This callback (SELINUX_CB_AUDIT) is invoked whenever avc_has_perm calls 
 * avc_audit with the auditdata parameter. It becomes the 'msg=' entry in the 
 * audit log. This callback is optional - use only if additional AVC info needs
 * to be logged. 
 */
static int cb_audit(void *auditdata, 
					security_class_t class,
					char *msgbuf,
					size_t msgbufsize)
{
		/******************* Do your processing here *****************/
	fprintf(stderr, "\n%sReceived audit notice via the %s callback function.\n"
				"Logging supplemental info in audit log.%s\n", red, 
            	__FUNCTION__, reset);
	/* 
	 * The auditdata buffer was updated just before calling avc_has_perm()
	 * The snprintf function will return a negative value.
	 */
    return snprintf(msgbuf, msgbufsize, "%s", (char *)auditdata);
}


/*
 * This callback (SELINUX_CB_LOG) is invoked whenever an audit event needs to 
 * be logged. The callback is really mandatory to write messages to an audit 
 * log. This example uses the audit_log_user_avc_message to write events to 
 * the standard audit log, if required a different log file could be used.
 */ 
static int cb_log(int type, const char *fmt, ...)
{
    va_list ap;
    char message[MAX_AUDIT_MESSAGE_LENGTH];
    int rc, audit_type;

		/******************* Do your processing here *****************/
	/*
	 * The 'type' code passed to the logging callback will be one of these:
	 * 		#define SELINUX_ERROR		0
	 * 		#define SELINUX_WARNING		1
	 * 		#define SELINUX_INFO		2
	 * 		#define SELINUX_AVC		    3
	 *
	 * The audit_type entry required by the audit_log_user_avc_message call
	 * is then selected from messages available for the audit library
	 * contained in <libaudit.h>.
	 */
    switch (type) {
        case SELINUX_ERROR:
        	audit_type = AUDIT_USER_SELINUX_ERR;
        break;
        case SELINUX_WARNING:
        	audit_type = AUDIT_USER_AVC;
        break;
        case SELINUX_INFO:
        	audit_type = AUDIT_USER_AVC;
    	break;
        case SELINUX_AVC:
        	audit_type = AUDIT_USER_AVC;
    	break;
        default:
        	audit_type = AUDIT_USER_AVC;
	    break;
    }

    va_start(ap, fmt);
    vsnprintf(message, MAX_AUDIT_MESSAGE_LENGTH, fmt, ap);

	if ((rc = audit_log_user_avc_message(audit_fd, audit_type, message, 
												NULL, NULL, NULL, 0)) <= 0) {
		fprintf(stderr, "%saudit_log_user_avc_message - ERROR %s %s\n", 
												red, strerror(errno), reset);
    	va_end(ap);
		return (-1);
	}
 	else {  
	    va_end(ap);
	    return 0;
	}
}



/*
 * This callback (SELINUX_CB_SETENFORCE) is invoked whenever the enforcement
 * mode changes. 
 * 
 * The enforcing argument is set to either 0 (permissive) or 1 (enforcing).
 * Note: When switched to Permissive mode, the AVC cache is not reset.
 */
static int cb_setenforce(int enforcing)
{
		/******************* Do your processing here *****************/
	/* NOTE: This function just writes a message to audit log and stderr. */
	char message[MAX_AUDIT_MESSAGE_LENGTH];
	int rc;
    sprintf(message, "Received setenforce notice via the %s callback "
						"function. SELinux set to %s", __FUNCTION__, 
						enforcing ? "ENFORCING mode" : "PERMISSIVE mode.");

	if ((rc = audit_log_user_avc_message(audit_fd, AUDIT_TRUSTED_APP, 
								message, NULL, NULL, NULL, 0)) <= 0) {
		fprintf(stderr, "%saudit_log_user_avc_message - ERROR %s %s\n", 
										red, strerror(errno), reset);
		return (-1);
	}
    fprintf(stderr, "\n%s%s%s\n", red, message, reset);
    return 0;
}




/*
 * Events from the avc_add_callback end up here. Note that AVC_CALLBACK_RESET 
 * is the only event currently (libselinux 2.0.96) returned by this callback.
 */
static int cb_avc_add (u_int32_t event, security_id_t ssid,
                        security_id_t tsid, security_class_t tclass,
                        access_vector_t perms, access_vector_t *out_retained)
{
		/******************* Do your processing here *****************/
	/* NOTE: This function just writes a message to audit log and stderr. */
	char message[MAX_AUDIT_MESSAGE_LENGTH];
	int rc, ptr = 0;
	char *event_message[] = {
		"AVC_CALLBACK_GRANT",
		"AVC_CALLBACK_TRY_REVOKE",
		"AVC_CALLBACK_REVOKE",
		"AVC_CALLBACK_RESET - AVC Cache reset",
		"AVC_CALLBACK_AUDITALLOW_ENABLE",
		"AVC_CALLBACK_AUDITALLOW_DISABLE",
		"AVC_CALLBACK_AUDITDENY_ENABLE",
		"AVC_CALLBACK_AUDITDENY_DISABLE",
	};

	/* Get ptr to message */ 
	for (ptr = 0; (event & 1) != 1; ptr++) 
		event = event >> 1;

	/* Build message and send to audit log */
	sprintf(message, "Received avc_add_callback notice via %s callback. "
				"Event set to: %s", __FUNCTION__, event_message[ptr]);

	if ((rc = audit_log_user_avc_message(audit_fd, AUDIT_USER_AVC, message, 
										NULL, NULL, NULL, 0)) <= 0) {
		fprintf(stderr, "%saudit_log_user_avc_message - ERROR %s %s\n", 
										red, strerror(errno), reset);
		return (-1);
	}

	/* Then send to stderr as well */
	fprintf(stderr, "\n%s%s%s\n", red, message, reset);
	return 0;
}


/*
 * This callback (SELINUX_CB_POLICYLOAD) is invoked whenever the system  
 * security  policy is reloaded. The seqno argument is the sequence number 
 * generated by the SELinux security server.
 *
 * Note that the AVC service has already reset the cache so no need to 
 * call avc_reset().
 */
static int cb_policyload(int seqno)

{
		/******************* Do your processing here *****************/
	/* NOTE: This function just writes a message to audit log and stderr. */
	char message[MAX_AUDIT_MESSAGE_LENGTH];
	int rc;

    sprintf(message, "Received policy reload notice via the %s callback "
						"function. seqno = %d", __FUNCTION__, seqno);

	if ((rc = audit_log_user_avc_message(audit_fd, AUDIT_USER_MAC_POLICY_LOAD, 
								message, NULL, NULL, NULL, 0)) <= 0) {
		fprintf(stderr, "%saudit_log_user_avc_message - ERROR %s %s\n", 
										red, strerror(errno), reset);
		return (-1);
	}

    fprintf(stderr, "\n%s%s%s\n", red, message, reset);
    return 0;
}
				/******** End callback routines **********/

		/******** Insert thread or signal handler routine **********/
/*
 * Use avc_netlink_check_nb (with signal handler) or avc_netlink_loop (with
 * thread handler to allow the policy load and policy enforcement events to
 * be processed by the relevant callback functions.
 */
static void * netlink_thread(void * arg)
{
/* 
 * avc_netlink_loop enters a loop blocking on the netlink socket and processes
 * messages as they are received. This function will not return unless an 
 * error occurs on the socket, in which case the socket is closed. 
 */
	int netlink_fd;

	netlink_fd = avc_netlink_acquire_fd();
	fprintf(stderr, "\n%sExecuting: avc_netlink_loop(); at %s netlink_fd: "
							"%d%s\n", green, __FUNCTION__, netlink_fd, reset);

	/* Blocks here to process policy load and enforcement status events */
	avc_netlink_loop();
	return 0;
}
			/******** End thread or signal handler routine **********/


/* 
 * Function to print the AVC statistics. Because the audit logging call back
 * has been set, the avc_av_stats and avc_sid_stats information will be 
 * displayed in the audit log.
 */
void print_stats(void)
{
    struct avc_cache_stats acs; 

    printf("avc_av_stats and avc_sid_stats outputs are in the audit log.\n"); 
    avc_av_stats();
    avc_sid_stats();
     
    printf("\nThe avc_cache_stats are as follows:\n"); 
    avc_cache_stats(&acs); 
    printf("entry_lookups:  %d\t(Queries made)\n", acs.entry_lookups); 
    printf("entry_hits:     %d\t(Decisions found in aeref)\n", 
                                                            acs.entry_hits); 
    printf("entry_misses:   %d\t(Decisions not found in aeref)\n", 
                                                           acs.entry_misses); 
    printf("entry_discards: %d\t(Decisions not found in aeref that were also "
                                           "non-NULL)\n", acs.entry_discards); 
    printf("cav_lookups:    %d\t(Cache lookups)\n", acs.cav_lookups); 
    printf("cav_hits:       %d\t(Cache hits)\n", acs.cav_hits); 
    printf("cav_probes:     %d\t(Entries examined searching the cache)\n", 
                                                              acs.cav_probes); 
    printf("cav_misses:     %d\t(Cache misses)\n", acs.cav_misses); 
}
