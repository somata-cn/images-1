#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    security_context_t context;

#ifdef INFO
    printf("\nThe setexeccon example requires a context to be selected that "
				"will be set by\nsetexeccon. To check that the context has "
				"been set a getexeccon call is\nissued to display the result, "
				"followed by:\n\texecvp(\"getcon_example\", argv)\n"
           		"that will execute the getcon_example application and display "
				"the new process\ncontext.\n");

	printf("\nNotes 1) The getcon_example binary needs to be in "
				"/usr/local/bin\n"
				"\n      2) The call requires process { transition } "
				"permission to work as a\n         minimum.\n"
				"\n      3) If using F16 targeted policy, then there is a "
				"setexeccon_example.conf\n         policy module supplied in "
				"the 'modules' directory that will add the\n         required "
				"transition rule to the policy for the context:"
				"\n\t\tunconfined_u:unconfined_r:user_t:s0"
				"\n         This should be selected to allow setexeccon to "
				"run showing a different\n         context.\n");
#endif

	printf("\nExecuting: getexeccon_raw(&context)\n");
    if ((rc = getexeccon_raw(&context)) == -1) {
        printf("Failed to obtain context\n");
        perror("getexeccon_raw - ERROR");
        exit(1);
    }
	printf("The exec context is:\n\t%s\n", context);
	printf("Press return to continue\n");
	getchar();
	freecon(context);

    get_config_entry("[raw_context]", &context);
	printf("\nExecuting: setexeccon_raw(%s)\n", context);

    if ((rc = setexeccon_raw(context)) == -1) {
        perror("setexeccon_raw - ERROR");
        exit(1);
    }

    freecon(context);

    if ((rc = getexeccon_raw(&context)) == -1) {
        printf("Failed to obtain exec context\n");
        perror("getexeccon_raw - ERROR");
        exit(1);
    }

    if(context) {
        printf("\nThe exec context is now::\n\t%s\n", context);
        freecon(context);
    }
    else {
            printf("No context has been set (NULL returned)\n");
            exit(1);
    }

    /*
     * Got here so managed to set exec context and read it back. Now go and
     * run an execvp (or execve etc.) to prove that if the context is valid,
     * then a new task can run in the correct context. If fails check the
     * audit log for SELinux audit messages (transition failed or no valid
     * entrypoint are typical).
     */
    printf("\nNow execute an execvp with the \"getcon_example\" sample "
                "function:\n\texecvp(\"getcon_example\", argv)\n\nThis will "
                "display the exec'ed context if the set context is valid.\n"
                "If the setexec context is invalid, then there will be an "
                "entry in the \naudit log stating why it failed to exec. "
                "(denied transition permission\nis typical).\n\n");

    printf("Now executing: \"execvp(\"getcon_example\", argv);\" function:\n");
    if ((rc = execvp("getcon_example", argv)) == -1) {
        perror("execvp - ERROR");
        exit(1);
    }
    /* If execve okay, then we don't get here anyway. */
    exit(0);
}
