#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int policy_version;

#ifdef INFO
	printf("\nThe security_policyvers example will return the maximum policy "
				"version that the\nkernel will support. If it cannot be "
				"determined, then a DEFAULT_POLICY_VERSION\nof 15 is "
				"returned.\n");
#endif

    printf("\nExecuting: security_policyvers();\n");

    if ((policy_version = security_policyvers()) == -1) {
        printf("FAILED to get the policy version\n");
        perror("policy_version - ERROR");
    }
    else
        printf("\nThe maximum policy version supported is: %d\n\n",
															policy_version);
    exit(0);
}
