#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_class_t tclass;
    char *name;

#ifdef INFO
    printf("\nThe string_to_security_class example requires a class to be "
                "selected.\nThe call will then return the value assigned "
                "to the selected class.\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[class]", &name);

    printf("Executing: string_to_security_class(%s);\n", name);

    if ((tclass = string_to_security_class(name)) == 0) {
		perror("string_to_security_class - unknown class - ERROR");
        exit(1);
    }
	else
    	printf("The value assigned to the class is: %d\n", tclass);

    exit(0);
}
