#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include <selinux/selinux.h> 
#include <selinux/avc.h> 

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv) 
{ 
    security_context_t scon, tcon, newcon; 
    security_id_t ssid, tsid, newsid; 
 	security_class_t tclass;
	char *string;
    int rc;

#ifdef INFO
    printf("\nThe avc_compute_member example requires a source and target "
            "context plus a class\nto be selected. Note: that for the source "
			"and target contexts, SIDs will be\ncomputed using "
			"avc_context_to_sid and the class will be computed using\n"
			"string_to_security_class\n"
			"\nThe function will then compute a new SID based on the source "
			"and target SIDs\nfor labeling a new object of the selected class."
			" The new SID will then be used\nto retrieve the context using "
			"avc_sid_to_context.\n");

	printf("\nThe following libselinux functions are used:\n"
			"  avc_open - With no options set.\n"
			"  string_to_security_class - Convert string to class ID.\n"
			"  avc_compute_member - Get new SID for the context.\n"
			"  avc_context_to_sid - Convert context to SID.\n"
			"  avc_sid_to_context - Convert SID to context.\n"
			"  avc_destroy - Destroy AVC cache."
			"\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[raw_context]", &scon);
    get_config_entry("[raw_context]", &tcon);
    get_config_entry("[class]", &string);
    tclass = string_to_security_class(string);
	free(string);

    /* Open with no options */
	printf("\nExecuting: avc_open(NULL, 0);\n");
    if (avc_open(NULL, 0) < 0) {
        printf("avc_open - ERROR %s\n", strerror(errno));
        exit(1);
    }
	printf("The avc_open parameters state that it follows the SELinux "
													"enforcement mode.\n");

	/* Get a SID for the scon context */
	printf("\nExecuting: avc_context_to_sid(%s, &ssid);\n", scon);
    if (avc_context_to_sid(scon, &ssid) < 0) { 
        printf("Could not get SSID - ERROR %s\n", strerror(errno));
        avc_destroy(); 
        exit(1); 
    } 

	/* Get a SID for the tcon context */
	printf("\nExecuting: avc_context_to_sid(%s, &tsid);\n", tcon);
    if (avc_context_to_sid(tcon, &tsid) < 0) { 
        printf("Could not get TSID - ERROR %s\n", strerror(errno));
        avc_destroy(); 
        exit(1); 
    } 

	printf("\nExecuting: avc_compute_member(ssid, tsid, %d, &newsid);\n",
																	tclass);
	if ((rc = avc_compute_member(ssid, tsid, tclass, &newsid) != 0)) {
		printf("avc_compute_member - ERROR %s\n", strerror(errno));
        avc_destroy();
		exit(1);
	}

	/* Now use avc_sid_to_context to get the new context */
	printf("\nExecuting: avc_sid_to_context(newsid, &newcon);\n");
    if (avc_sid_to_context(newsid, &newcon) < 0) { 
        printf("Could not get new context - ERROR %s\n", strerror(errno));
        avc_destroy(); 
        exit(1); 
    }
    printf("The returned (newcon) context is %s\n", newcon);

	/* Free all resources */
    freecon(scon);
	freecon(tcon);
    freecon(newcon);
    avc_destroy();
    exit(0); 
}
