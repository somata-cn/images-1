#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    access_vector_t av_perm;
    security_class_t tclass;
	char *class, *perm_list;

#ifdef INFO
    printf("\nThe string_to_av_perm example requires a class and permission "
				"string to be\nselected. The string_to_av_perm call will "
				"then return the permission bit.\n\n"
                "Note: This test asks for a class string that is converted by "
                "a\n'tclass = string_to_security_class(string)' call. The "
				"permission selected will\nbe the first one in the list."
				"\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[class]", &class);
	if ((tclass = string_to_security_class(class)) == 0) {
		perror("\nstring_to_security_class - ERROR");
		exit(1);
	}
    free(class);

    get_config_entry("[perms]", &perm_list);
	/* Take first in the list if multiple entries */
	strtok(perm_list, " ");

    printf("Executing: string_to_av_perm(%d, %s);\n", tclass, perm_list);

    if ((av_perm = string_to_av_perm(tclass, perm_list)) == 0) {
		perror("string_to_av_perm - unknown permission - ERROR");
    	exit(1);
    }
    else
		printf("The permission bit for %s is: 0x%08x for class: %s\n", perm_list,
                        av_perm, security_class_to_string(tclass));

	exit(0);
}
