#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    char *path;
    security_context_t context;
    mode_t mode;
    struct stat stat_buf;

#ifdef INFO
    printf("\nThe matchpathcon example requires a file name to be selected, "
				"the default\ncontext that should be applied to this file will "
				"then be displayed. Note that\nmatchpathcon returns the "
				"default context that should be applied to a file as\nspecified "
				"in the file_contexts configuration files.\n\nThe example "
				"will check if the file exists (to obtain the mode), however "
				"it\nwill not check the context that has been applied to the "
				"file (i.e. the context\non the file could be different to "
				"that specified by the policy file_context\nconfiguration "
				"files.\n\nNote that if the context specified in the file "
				"contexts series of files is\n<<none>>, then error ENOENT is "
				"returned.\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[path]", &path);

    if (lstat(path, &stat_buf) != 0) {
		printf("\nCould not stat the file: %s\nHowever the default "
					"context that would apply to this file if created "
					"will be\ndisplayed.\n", strerror(errno));
	    mode = 0;
	}
	else
		mode = stat_buf.st_mode;

    printf("\nExecuting: matchpathcon(%s, 0x%x, &context);\n\n", path, mode);
    if ((rc = matchpathcon(path, mode, &context)) == -1) {
        printf("Failed to find a default context to be applied.\n");
        perror("matchpathcon - ERROR");
        exit(1);
	}
    printf("The default file context should be: %s\n", context);

    freecon(context);
    free(path);
    matchpathcon_fini();
    exit(0);
}
