#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/stat.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc, spec_index;
    char *path;
    security_context_t context;
    mode_t mode;
    ino_t  ino;
    struct stat stat_buf;
    char answer[8];

#ifdef INFO
    printf("\nThe matchpathcon_filespec example1 loops asking for a file to "
				"be selected, the\nfiles default context will be obtained "
				"using matchpathcon_index and then\ndisplayed. matchpathcon_"
				"filespec_add is then used to add an entry in the spec\ntable."
				"\nPress 'q' to quit that will display various stats or "
				"press 'd' to call\nmatchpathcon_filespec_destroy and then "
				"continue.\n\n");

    printf("The example will check if the file exists (to obtain the mode) "
				"using lstat.\nIf the file does not exist, then mode = 0 is "
				"used.\n\nNote 1: The context displayed is the 'default "
				"context' and not the context\nthat maybe set on the file (in "
				"the extended attribute).\nUse the selinux_file_context_verify_"
				"example to check if the file is set to\nthe default.\n");

	printf("\nNote 2: That if the context specified in the file contexts "
				"series of files is\n<<none>>, then error ENOENT is "
				"returned.\n");

    printf("\nNote 3: This example uses the default matchpathcon callback "
                "functions and\nExample 2 (matchpathcon_filespec_example2) "
                "modifies these callbacks.\nPress return to continue\n");
    getchar();

    printf("This example calls the following libselinux functions:"
                "\n  set_matchpathcon_flags"
                "\n    This sets MATCHPATHCON_NOTRANS"
                "\n  matchpathcon_init_prefix"
                "\n    This loads the following current policy file "
                "context files: file_contexts\n    and if present the "
                "file_contexts.homedirs and file_contexts.local"
                "\n  matchpathcon_index"
                "\n    This is the same as matchpathcon but returns a "
                "specification index for\n    use by matchpathcon_filespec_add."
                "\n  matchpathcon_filespec_add"
                "\n    Maintains an association between an inode and the "
                "specification index."
                "\n  matchpathcon_filespec_eval"
                "\n    Outputs the statistics for the inode associations to "
                "/var/log/messages."
                "\n  matchpathcon_checkmatches"
                "\n    Reports any specifications that has not been matched. "
                "The output by\n    default is stderr."
                "\n  matchpathcon_filespec_destroy"
                "\n    Destroys inode association table (i.e. start new index)."
                "\n  matchpathcon_fini"
                "\n    Close the file_contexts files and free any memory."
                "\nPress return to continue\n");
    getchar();
#endif

	/*
	 * Note that the MATCHPATHCON_VALIDATE flag is not set, therefore the file
	 * context entries will not be passed to the set_matchpathcon_invalidcon
	 * (or the set_matchpathcon_canoncon) functions when
	 * matchpathcon_init_prefix is called.
	 * The only flag set is the MATCHPATHCON_NOTRANS to stop translations.
	 */
    printf("Executing: set_matchpathcon_flags (MATCHPATHCON_NOTRANS);\n");
    set_matchpathcon_flags(MATCHPATHCON_NOTRANS);

    /*
     * Could also use matchpathcon_init as it calls matchpathcon_init_prefix
     * anyway by setting the 2nd parameter to NULL.
     */
#ifdef INFO
	printf("\nAbout to execute: matchpathcon_init_prefix(NULL, NULL);\n");
    printf("Note: If matchpathcon_init_prefix detects an error in "
                "the policy file_contexts\nfile, then an error is logged to "
				"stderr.\n");
    printf("\nPress return to execute matchpathcon_init_prefix\n");
    getchar();
#endif
    matchpathcon_init_prefix(NULL, NULL);

    while(1) {
        get_config_entry("[path]", &path);

    	if (lstat(path, &stat_buf) != 0) {
			printf("\nCould not stat the file: %s\nHowever the default "
					"context that would apply to this file if created "
					"will be\ndisplayed.\n", strerror(errno));
	    	mode = 0;
			ino = 0;
		}
		else {
			mode = stat_buf.st_mode;
			ino = stat_buf.st_ino;
		}

		printf("\nExecuting: matchpathcon_index(%s, 0x%x, &context);\n\n",
                                                                path, mode);
        if ((spec_index = matchpathcon_index(path, mode, &context)) == -1) {
            printf("Failed to find a default context to be applied.\n");
            perror("matchpathcon_index - ERROR");
			printf("\nPress return to continue\n");
    		getchar();
            continue;
        }
		printf("The default context to be applied is: %s\nand returned "
						"specification index is: %d\n", context, spec_index);

        printf("\nExecuting: matchpathcon_filespec_add(0x%x, %d, %s);\n",
												(int)ino, spec_index, path);
		/*
		 * Note if using 32 bit systems then libselinux requires Large
		 * File Support (LFS) in Linux, therefore need -D_FILE_OFFSET_BITS=64
		 * otherwise matchpathcon_filespec_add passes a too small ino.
		 */
        if ((rc =  matchpathcon_filespec_add(ino, spec_index, path)) == -1) {
            printf("Failed to add index.\n");
            perror("matchpathcon_filespec_add - ERROR");
			printf("\nPress return to continue\n");
    		getchar();
            continue;
        }
        printf("\tmatchpathcon_filespec_add - Entry added to specification "
															"index: %d\n", rc);
        free(path);
        freecon(context);

        printf("\n'q' for Quit and check matches with matchpathcon_checkmatches"
            	" or:\n'd' to call matchpathcon_filespec_destroy or return to "
                                                                "continue.\n");
        fgets(answer, sizeof(answer), stdin);
        if (answer[0] == 'q') {
            printf("Logging matchpathcon_checkmatches\n");
            matchpathcon_checkmatches(NULL);
            printf("Logging matchpathcon_filespec_eval results\n");
            matchpathcon_filespec_eval();
            break;
        }
        if (answer[0] == 'd') {
            printf("Calling matchpathcon_filespec_destroy to reset index\n");
            matchpathcon_filespec_destroy();
            sleep(3);
            continue;
        }
    }
    matchpathcon_fini();
    exit(0);
}
