#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include <pthread.h>
#include <errno.h>
#include <linux/selinux_netlink.h>
#include <libaudit.h>
#include <selinux/selinux.h> 

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

/* show messages on screen in red and green */
static char red[] = "\033[0;31m";
static char green[] = "\033[0;32m";
static char reset[] ="\033[0m";

/* audit file descriptor */
static int audit_fd;

/*
 *************** Thread for managing netlink events ****************
 * This is a typical SELinux netlink routine that will detect various
 * netlink errors and the SELinux policy load and enforcement events.
 * The SELinux events are logged in the audit log, however the netlink
 * errors are just sent to stderr.
 */
static void * netlink_thread(void * arg)
{
	fprintf(stderr, "\n%sSetting up netlink thread: %s%s\n", 
												green, __FUNCTION__, reset);

	/* Blocks here to process policy load and enforcement status events */
	char message[MAX_AUDIT_MESSAGE_LENGTH];
	char buf[1024];
	unsigned buflen = sizeof(buf);
	int len, rc, netlink_fd = 0;
	struct sockaddr_nl addr;
	struct sockaddr_nl nladdr;
	socklen_t nladdrlen = sizeof nladdr;
	struct nlmsghdr *nlh = (struct nlmsghdr *)buf;

	if ((netlink_fd = socket(PF_NETLINK, SOCK_RAW, NETLINK_SELINUX)) < 0) {
							fprintf(stderr, "\n%ssocket error - %s%s\n", 
							red, __FUNCTION__, reset);
		exit(1);
	}
	
	len = sizeof(addr);
	memset(&addr, 0, len);
	addr.nl_family = AF_NETLINK;
	addr.nl_groups = SELNL_GRP_AVC;

	if (bind(netlink_fd, (struct sockaddr *)&addr, len) < 0) {
							fprintf(stderr, "\n%sbind error - %s%s\n", 
							red, __FUNCTION__, reset);
		exit(1);
	}


	while (1) {

		if ((rc = recvfrom(netlink_fd, buf, buflen, 0, 
				(struct sockaddr *)&nladdr, &nladdrlen)) < 0) {
			fprintf(stderr, "\n%srecvfrom error - %s%s\n", 
												red, __FUNCTION__, reset);
			exit(1);
		}

		if (nladdrlen != sizeof nladdr) {
			fprintf(stderr, "\n%sWarning: netlink address truncated, length "
						"%d at %s%s\n", red, nladdrlen, __FUNCTION__, reset);
			exit(1);
		}

		if (nladdr.nl_pid) {
			fprintf(stderr, "\n%sWarning: received spoofed netlink packet "
				"from: %d at %s%s\n", red, nladdr.nl_pid, __FUNCTION__, reset);
			exit(1);
		}

		if (rc == 0) {
			fprintf(stderr, "\n%sWarning: received EOF on netlink socket "
									"at %s%s\n", red, __FUNCTION__, reset);
			exit(1);
		}

		if (nlh->nlmsg_flags & MSG_TRUNC || nlh->nlmsg_len > (unsigned)rc) {
			fprintf(stderr, "\n%sWarning: incomplete netlink message at "
									"%s%s\n", red, __FUNCTION__, reset);
			exit(1);
		}

		switch (nlh->nlmsg_type) {
			case NLMSG_ERROR: 
			{
				struct nlmsgerr *err = NLMSG_DATA(nlh);
				if (err->error == 0)
					break;
				fprintf(stderr, "\n%sWarning: netlink error: %s at %s%s\n", 
                        red, strerror(-err->error), __FUNCTION__, reset);
				break;
			}

			case SELNL_MSG_SETENFORCE: 
			{
				struct selnl_msg_setenforce *msg = NLMSG_DATA(nlh);
    			sprintf(message, "Received setenforce notice via the %s "
                        "callback function. SELinux set to %s", __FUNCTION__, 
						msg->val ? "ENFORCING mode" : "PERMISSIVE mode.");

				if ((rc = audit_log_user_avc_message(audit_fd, 
										AUDIT_TRUSTED_APP, message,
										NULL, NULL, NULL, 0)) <= 0) {

					fprintf(stderr, "%saudit_log_user_avc_message - ERROR "
                            "%s %s\n", red, strerror(errno), reset);
					break;
				}
			    fprintf(stderr, "\n%s%s%s\n", red, message, reset);
				break;
			}

			case SELNL_MSG_POLICYLOAD:
			{
				struct selnl_msg_policyload *msg = NLMSG_DATA(nlh);
    			sprintf(message, "Received policy reload notice via the %s "
					"callback function. seqno = %d", __FUNCTION__, msg->seqno);

				if ((rc = audit_log_user_avc_message(audit_fd,
										AUDIT_TRUSTED_APP, message,
										NULL, NULL, NULL, 0)) <= 0) {

					fprintf(stderr, "%saudit_log_user_avc_message - ERROR %s "
									"%s\n", red, strerror(errno), reset);
					break;
				}
			    fprintf(stderr, "\n%s%s%s\n", red, message, reset);
				break;
			}

			default:
				fprintf(stderr, "\n%sWarning: unknown netlink message %d "
						"at %s%s\n", red, nlh->nlmsg_type, __FUNCTION__, reset);
		} 
	}
	return 0;
}
			/******** End thread for netlink handler **********/


int main(int argc, char **argv) 
{ 
    security_context_t scon, tcon; 
	security_class_t tclass;
	access_vector_t requested, denied, audited;
	struct av_decision avd_buf, *avd;
    avd = &avd_buf;
    mode_t mode;
    int rc;
	char *result = NULL;
	char buf[80], message[MAX_AUDIT_MESSAGE_LENGTH];
	pthread_t thread;

#ifdef INFO
    printf("\nThe netlink_security_compute_av example uses socket calls to "
			"process SELinux\nnetlink events with the security_compute_av and "
			"audit_log_user_avc_message\nfunctions checking access and logging."
			"\n\nThe example requires a context and file or directory name to "
			"be selected.\nThe security_compute_av_raw function will then be "
			"used to determine whether\nthe file has execute permission or "
			"not.\n\nThe example will then ask whether to quit ('q') or return "
			"to input another\nfile name.\n");

	printf("\nNote 1) Run semodule -R to see policy reload notice or "
			"setenforce to see\nenforcement notices.\n\n"
			"Note 2) If NULL is selected for the source context, then getcon\n"
			"will be called and the current process context will be used.\n\n"
			"Note 3) The example uses a number of other functions that are "
			"listed below.\nPress return to continue\n");
	getchar();

	printf("pthread_create\n    Set up a thread to receive netlink messages.\n"
			"\nsocket, bind, recvfrom\n    Process netlink messages in thread."
            "\n\naudit_open\n    Open the audit log.\n"
			"\naudit_log_user_avc_message\n    Write entry into audit log.\n"
			"\nsecurity_getenforce\n    Checks enforcement mode.\n"
			"\ngetcon\n    Get current context if NULL is selected.\n"
			"\nstring_to_security_class, security_class_to_string"
			"\n    Get file class ID/string."
			"\nPress return to continue\n");
	getchar();

	printf("string_to_av_perm, security_av_string"
			"\n    Get execute permission ID/string.\n"
			"\ngetfilecon\n    Retrieve the file context (if it exists).\n"
			"\nmatchpathcon\n    Get the context from the file_contexts file "
			"if the file does not exist.\n"
			"\nsecurity_compute_av_raw\n    Check if execute "
			"permission is allowed on the file.\n"
			"\naudit_close.\n    Close audit fd."
			"\nPress return to continue\n");
	getchar();
#endif

	/* Open an audit fd as the standard audit log will be used. */
	printf("Executing: audit_fd = audit_open();\n");
    if ((audit_fd = audit_open()) < 0) {
    	printf("audit_open - ERROR %s\n", strerror(errno));
        exit(1);
    }

    /* This checks whether SELinux is in enforcing mode or not. */
    if (security_getenforce() == 1)
        printf("\nSELinux is currently in Enforcing mode\n");
    else 
        printf("\nSELinux is currently in Permissive mode\n");
    
	printf("Creating thread to run netlink processing.\n");
	pthread_create(&thread, NULL, netlink_thread, NULL);

	printf("\nPress return to continue\n");
	getchar();

	/* Let user select a context to use */
    get_config_entry("[raw_context]", &scon);
	/* If NULL then get the current process context */ 
	if (strcmp(scon, "NULL") == 0) {
		printf("\nExecuting: getcon(&scon);\n");
    	if (getcon(&scon) < 0) { 
        	printf("getcon - ERROR %s\n", strerror(errno));
        	exit(1); 
    	} 
	}


	/* 
	 * Note it is recommended that the string_to_security_class and 
	 * string_to_av_perm calls are used. This is because they will always
	 * retrieve the correct values whereas the flask entries may not always
	 * be correct.
	 */
	/* Get the class id for a file object */
	printf("\nExecuting: string_to_security_class(\"file\");\n");

    if ((tclass = string_to_security_class("file")) != 0)
        printf("\tThe value assigned to the \"file\" class is: %d\n", tclass);
    else 
        printf("string_to_security_class - ERROR %s\n", strerror(errno));
	/* Then get the permission bit for 'execute'.*/
	printf("Executing: string_to_av_perm(tclass, \"execute\");\n");
    if ((requested = string_to_av_perm(tclass, "execute")) != 0)
        printf("\tThe permission bit for \"execute\" is: 0x%08x\n", requested);
    else 
        printf("string_to_av_perm - ERROR %s\n", strerror(errno));

    /* Read file or directory name from stdin */
    while (1) { 
        printf("\nEnter a file or directory name: ");
		fflush(stdin);
		memset(buf, 0, sizeof(buf));
        fgets(buf, sizeof(buf), stdin);
		/* Remove the cr */
		buf[strlen(buf)-1] = 0;  

        /* 
		 * Get security context for the file. Note that getfilecon 
		 * retrieves the context of a file that physically exists. If it
		 * does not exist then matchpathcon is called to see what context
		 * would be applied if it did.
		 */
		printf("\nExecuting: getfilecon(%s, &tcon);\n", buf);
        if (getfilecon(buf, &tcon) < 0) { 
            printf("\tgetfilecon - Could not retrieve file context for '%s'\n"
					"\tERROR: %s\n", buf, strerror(errno));

			mode = 0;
			printf("Therefore executing: matchpathcon(%s, 0x%x, &tcon);\n\n", 
																buf, mode);
    		if ((rc = matchpathcon(buf, mode, &tcon)) != 0) {
            	printf("\tmatchpathcon - Could not retrieve file context for "
								"'%s'\n\tERROR: %s\n", buf, strerror(errno));
            	continue; 
			}
		} 

		printf("\nExecuting: security_compute_av_raw(scon, tcon, tclass, "
											"requested, avd);\n");
        if ((rc = security_compute_av_raw(scon, tcon, tclass, requested,
                                                        avd)) == -1) {
            printf("security_compute_av_raw - ERROR: %s\n", strerror(errno));
            continue;
        }

    	/* Print class and permissions */    
    	printf("\nFor source context: %s\n    target context: %s\n"
            "        with class: file\n", scon, tcon);

		printf("and requested permissions of:\n\t");
		print_access_vector(tclass, requested);

		/* Now get the actual denied permissions */
		denied = requested & ~avd->allowed;
		audited = denied ? (denied & avd->auditdeny) : 
                                                (requested & avd->auditallow);
		printf("\nthe request would be: %s\n", 
							(denied || !requested) ? "DENIED" : "GRANTED");

		security_av_string(tclass, audited, &result);

		if (audited) {
			/* Add the supplemental audit information so that it is logged. */
    	    sprintf(message, "uavc: %s %s by Sample OM - Checking "
					"file: %s scontext=%s tcontext=%s tclass=%s ",  
					denied ? "denied" : "granted", result, buf, scon, tcon, 
					security_class_to_string(tclass));

			printf("Executing: audit_log_user_avc_message();\n");
			if ((rc = audit_log_user_avc_message(audit_fd, AUDIT_TRUSTED_APP, 
										message, NULL, NULL, NULL, 0)) <= 0) {
				fprintf(stderr, "audit_log_user_avc_message - ERROR %s\n", 
												strerror(errno));
    		}
			printf("Audit Log entry:\n%s%s%s\n", denied ? red : green, 
															message, reset);
		}
		free(result);

		/* Now see if to continue or not */
        printf("\nPress 'q' for quit or return to continue.\n");
		fflush(stdin);
		memset(buf, 0, sizeof(buf));
        fgets(buf, sizeof(buf), stdin);
		if (buf[0] == 'q') {
			audit_close(audit_fd);
		    exit(0); 
    	}
	} 
	audit_close(audit_fd);
    exit(0); 
}
