#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <string.h>
#include <limits.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int fd, rc;
    void *data;
    size_t len;
    char path[PATH_MAX];
	char *policyfile;
    struct stat sb;
    int ver = security_policyvers();

#ifdef INFO
	printf("\nThe security_load_policy example will request a binary policy "
                "file file name to\nbe entered (or select CURRENT for the "
                "current policy). The file will be opened\nand read into a "
                "buffer. If okay, the 'security_load_policy(data, len)' "
                "function\nwill be called to load the policy."
                "\nPress return to continue\n");
	getchar();
#endif

    printf("\nSelect a binary policy file:");
    get_config_entry("[binary_policy]", &policyfile);
    if ((strcmp(policyfile, "CURRENT")) == 0)
        snprintf(path, sizeof(path), "%s.%d", selinux_binary_policy_path(), ver);
	else
		snprintf(path, sizeof(path), "%s", policyfile);

    printf("Attempting to open the policy: %s\n", path);

    if ((fd = open(path, O_RDONLY)) < 0) {
        printf("Cannot open policy file: %s\n", path);
        perror("open - ERROR");
        exit(1);
    }
    printf("Opened policy: %s\n", path);

	if (fstat(fd, &sb) < 0) {
		printf("Cannot stat policy file %s: %s\n", path, strerror(errno));
        perror("fstat - ERROR");
		exit(1);
	}
	len = sb.st_size;

    printf("Attempting to load the policy into memory (size %d)\n", (int)len);
	data = malloc(len);
    if ((data == NULL)) {
        perror("malloc - ERROR");
        exit(1);
    }

    if ((rc = read(fd, data, len) == -1)) {
        perror("Read policy - ERROR");
        exit(1);
    }

    printf("Policy loaded into buffer, now executing security_load_policy"
															"(data, len);\n");

    if ((rc = security_load_policy(data, len)) == -1) {
        printf("Cannot load policy\n");
        perror("security_load_policy - ERROR");
    }
    else
        printf("Policy loaded\n");

    exit(0);
}
