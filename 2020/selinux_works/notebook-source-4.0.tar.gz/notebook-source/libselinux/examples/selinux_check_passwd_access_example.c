#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    access_vector_t requested;
    char *perm;
    int enforce_mode, rc;

#ifdef INFO
    printf("\nThe selinux_check_passwd_access example requires a valid passwd "
				"class permission\nto be selected. This is used by the "
				"function to check (via\n'security_compute_av_raw') whether "
				"the permission is allowed or not.\n\n"
				"Note: Need to be in enforcing mode for this function to work "
				"correctly,\notherwise it will always return okay."
				"\nPress return to continue\n");
    getchar();
#endif

    if ((enforce_mode = security_getenforce()) == -1) {
        printf("Failed to get current SELinux enforcing state\n");
        perror("security_getenforce - ERROR");
        exit(1);
    }
    if (!enforce_mode)
        printf("NOTE: Currently in permissive mode, therefore this "
							"function will always return\nokay.\n");

    get_config_entry("[perms_av]", &perm);
	requested = strtoll(perm, (char **)&perm[8], 16);
    free(perm);

    printf("\nExecuting: selinux_check_passwd_access(0x%08x);\n\n", requested);

    if ((rc = selinux_check_passwd_access(requested)) == -1) 
        printf("Access is NOT allowed for the requested permission.\n");
 	else
    	printf("Access is allowed for the requested permission.\n");

    exit(0);
}
