#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc;

#ifdef INFO
	printf("\nThe security_commit_booleans example will commit all pending "
				"booleans.\n");

	printf("\nNotes 1) A policy reload notice is sent to all object managers "
				"that implement\n         a policy reload callback function.\n "
				"\n      2) For each boolean changed in the loaded policy, "
				"a MAC_CONFIG_CHANGE\n         audit event will be logged.\n"
				"\n      3) The booleans committed are not set permanently, "
				"to do this they must\n         be written to the booleans or "
				"booleans.local file that will\n         automatically be "
				"loaded with the policy.\n         The security_set_boolean_"
				"list can do this.\n         An alternative is to use the "
				"semanage boolean options.\nPress return to continue\n");
	getchar();
#endif

    printf("Executing: security_commit_booleans();\n");

    if ((rc = security_commit_booleans()) == -1) {
        printf("FAILED to commit booleans\n");
        perror("security_commit_booleans - ERROR");
    }
    else
        printf("Committed any pending booleans\n");

    exit(0);
}
