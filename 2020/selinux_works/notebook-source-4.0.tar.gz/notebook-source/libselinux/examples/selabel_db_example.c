#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <selinux/selinux.h>
#include <selinux/label.h>

void db_menu()
{
    printf("Now select an object_type entry from the following list:\n");
    printf("1)  db_database  SELABEL_DB_DATABASE\n");
    printf("2)  db_schema    SELABEL_DB_SCHEMA\n");
    printf("3)  db_table     SELABEL_DB_TABLE\n");
    printf("4)  db_column    SELABEL_DB_COLUMN\n");
    printf("5)  db_sequence  SELABEL_DB_SEQUENCE\n");
    printf("6)  db_view      SELABEL_DB_VIEW\n");
    printf("7)  db_procedure SELABEL_DB_PROCEDURE\n");
    printf("8)  db_blob      SELABEL_DB_BLOB\n");
    printf("9)  db_tuple     SELABEL_DB_TUPLE\n");
    printf("10) db_language  SELABEL_DB_LANGUAGE\n\n");
}

/* These follow the order in label.h */
static char *object_type[] = {
    "SELABEL_DB_DATABASE",
    "SELABEL_DB_SCHEMA",
    "SELABEL_DB_TABLE",
    "SELABEL_DB_COLUMN",
    "SELABEL_DB_SEQUENCE",
    "SELABEL_DB_VIEW",
    "SELABEL_DB_PROCEDURE",
    "SELABEL_DB_BLOB",
    "SELABEL_DB_TUPLE",
	"SELABEL_DB_LANGUAGE"
};

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main (int argc, char **argv)
{
    int max_objects, index;
    char answer[8];
    struct selabel_handle *hnd;
    security_context_t selabel_context;
    char *object_name, *db_contexts_path, *validate = NULL;

    struct selinux_opt selabel_option [] = {
		{ SELABEL_OPT_PATH, db_contexts_path },
		{ SELABEL_OPT_VALIDATE, validate }
	};

#ifdef INFO
    printf("\nThe selabel_db example will show the context that will be applied"
				" to an object\ninstance via the SE-PostgreSQL database object "
				"manager. The example will loop\nasking for a database object "
                "type to be selected (e.g. db_database) and then\nan object "
                "name (e.g. my_database). The objects context will then "
                "be displayed.\nPress 'q' to quit and call selabel_stats, "
				"or return to continue.\n");

	printf("\nThe example will ask for a db contexts file to be selected, if "
				"you want the\ndefault, select NULL. Then select whether the "
				"contexts are to be validated or\nnot.\n");

	printf("\nNote 1: selabel_lookup does not validate the 'object_name' "
	        "component. However\nthe process does allow wild-cards (* and ?) "
	        "to be used that will be expanded.\nThis will allow matching to "
	        "return a valid context (but note any object_name\nwill return a "
			"context if the '*' is used as in the example below).\n\n"
	        "Note 2: For databases the object_type maps to the object class. "
	        "For example\n'SELABEL_DB_DATABASE' is mapped to the 'db_database' "
	        "object class in the\nsepgsql_contexts file as follows:\n");

    printf("\n\t<object type> <object name> <security context>\n"
        "\t db_database        *       system_u:object_r:sepgsql_db_t:s0\n\n");

	printf("Press return to continue\n");
	getchar();
#endif

	get_config_entry("[db_contexts_path]", &db_contexts_path);
    if ((strcmp(db_contexts_path, "NULL")) == 0)
        db_contexts_path = NULL;

	printf("\nDo you want to validate contexts? [y/n]");
	fflush(stdin);
	fgets(answer, sizeof(answer), stdin);
	if ((answer[0] == 'y') || (answer[0] == 'Y'))
		validate = (char *)1;

	selabel_option[0].value = db_contexts_path;
	selabel_option[1].value = validate;

    printf("Executing: selabel_open(SELABEL_CTX_DB, selabel_option, 2)\n\n");
	if ((hnd = selabel_open(SELABEL_CTX_DB, selabel_option, 2)) == NULL) {
	    perror("selabel_open - ERROR");
	    exit(1);
	}

    while(1) {
        /* Set the number of db objects in menu and then display on screen */
        max_objects = 10;
        db_menu();
        fgets(answer, sizeof(answer), stdin);
        index = atoi(answer);
        if(index >= max_objects+1 || index < 1)
            continue;
        printf("The chosen object_type is: %s\n", object_type[index-1]);
        get_config_entry("[object_name]", &object_name);
		/* Allow NULL for object_name - causes Segmentation fault - fix avail */
    	if ((strcmp(object_name, "NULL")) == 0)
        	object_name = NULL;

        printf("Executing: selabel_lookup_raw(hnd, &selabel_context, %s, %s)"
									"\n\n", object_name, object_type[index-1]);

        if (selabel_lookup_raw(hnd, &selabel_context, object_name, index)
                                                                        == 0) {
            printf("The DB context to be applied is: %s\n", selabel_context);
	        freecon(selabel_context);
        } else {
			switch (errno) {
				case ENOENT:
					printf("\nselabel_lookup failed to find a valid "
								"object_name: %s\n", object_name);
					break;
				case EINVAL:
					printf("\nselabel_lookup failed to validate context, or "
								"the object name / object type are invalid."
								"\n\tobject_type: %s object_name: %s\n",
								object_type[index-1], object_name);
					break;
				default:
					printf("\nselabel_lookup ERROR: %s\n", strerror(errno));
					break;
			}
		}
		free(object_name);
		printf("\nq for Quit and display DB selabel_stats or "
                                                    "return to continue.\n");
        fgets(answer, sizeof(answer), stdin);
        if (answer[0] == 'q') {
            printf("selabel_stats returned:\n");
            selabel_stats(hnd);
            break;
        }
    }
    selabel_close(hnd);
    exit(0);
}
