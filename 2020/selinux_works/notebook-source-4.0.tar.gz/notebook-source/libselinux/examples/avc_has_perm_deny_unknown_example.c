#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <selinux/avc.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
	int rc, deny_unknown;
    security_context_t scon, tcon;
    security_class_t tclass;
	access_vector_t requested, av_perm;
    security_id_t ssid, tsid;
    struct avc_entry_ref aeref;
    char *class, *perm_list, *ptr = NULL;

#ifdef INFO
    printf("\nThe avc_has_perm_deny_unknown example requires a source and "
				"target context\nplus a class and one or more "
				"permissions to be selected. Note that the class\nis converted "
				"to the appropriate ID by string_to_security_class and the\n"
				"permissions to their IDs by calls to string_to_av_perm\n");

	printf("\nThe example will check the deny_uknown flag and display its "
                "status (allowed\nor denied) and whether the class selected is "
                "known to the loaded policy\n(via string_to_security_class). "
                "The avc_has_perm is then called and the\ndecision displayed.\n"

				"\nThere are two ways to change the deny_uknown flag:\n"
				"   1) Change the semanage.conf 'handle-unknown' entry and "
				"then run 'semodule -B'\n      to rebuild the policy "
				"(e.g. handle-unknown = allow | deny | reject).\n"
				"   2) Change the policy build.conf 'UNK_PERMS' file entry "
				"and then rebuild\n      the policy (e.g. UNK_PERMS = deny "
				"| allow | reject).\nSetting 'reject' sets the policy "
				"'deny_uknown' flag to 'deny'.\n");

	printf("\nNotes: 1) If the permission is denied, then avc_has_perm will "
				"automatically\n          call avc_audit, however an audit "
				"message may not be displayed\n          as there could be a "
				"'dontaudit' statement in the policy.\n       2) Audit "
				"messages will be sent to stderr.\nPress return to continue\n");
	getchar();
#endif

    get_config_entry("[raw_context]", &scon);
    get_config_entry("[raw_context]", &tcon);
	get_config_entry("[class]", &class);
	get_config_entry("[perms]", &perm_list);

    printf("\nExecuting: security_deny_unknown();\n");
    if ((deny_unknown = security_deny_unknown()) == -1) {
        printf("Could not get deny_unknown flag.\n");
		free(class);
		free(perm_list);
        avc_destroy();
        exit(1);
    }
    printf("\nQueries on undefined object classes and permissions are: %s\n",
										(deny_unknown ? "DENIED" : "ALLOWED"));

	if ((tclass = string_to_security_class(class)) == 0)
		printf("Therefore, as the selected class is undefined, the request "
			"will be %s.\n", deny_unknown ? "DENIED" : "ALLOWED");
	else
		printf("However as the selected '%s' class is valid, access will be "
							"subject to the policy.\n", class);

	if (tclass != 0) {
		/* Convert perm_list to 'requested' bit map for valid classes*/
		printf("\nNow convert the permissions to a bit mask using 'string_to_av_perm'\n");
		ptr = strtok(perm_list, " ");
    	if ((av_perm = string_to_av_perm(tclass, ptr)) == 0) {
			printf("Invalid permission: %s\n", ptr);
    	}
		requested = 0;
		requested = requested | av_perm;
		do {
			ptr = strtok(NULL, " ");
			if (ptr) {
    			if ((av_perm = string_to_av_perm(tclass, ptr)) == 0) {
					printf("Invalid permission: %s\n", ptr);
    			}
				requested = requested | av_perm;
			}
		} while (ptr);

    	free(perm_list);
		/* Now reconvert the perm bits to a list. This will show those that are
		   really supported by the class */
		perm_list = NULL;
		security_av_string(tclass, requested, &perm_list);
		printf("\nThe valid permissions that will be requested are:\n\t%s\n", perm_list);

	} else /* Because invalid class, add all permissions as with no perms
				set the request will be denied */
		requested = ~0;

    free(perm_list);
	free(class);


    /* Open with no option set */
	printf("\nExecuting: avc_open(NULL, 0);\n");
    if (avc_open(NULL, 0) < 0) {
        printf("avc_open - ERROR %s\n", strerror(errno));
        exit(1);
    }

	printf("\nExecuting: avc_entry_ref_init(&aeref);\n");
    avc_entry_ref_init(&aeref);

	/* Get a SID for the contexts */
	printf("Executing: avc_context_to_sid(%s, &ssid);\n", scon);
    if (avc_context_to_sid(scon, &ssid) < 0) {
        printf("Could not get SSID - ERROR %s\n", strerror(errno));
        avc_destroy();
        exit(1);
    }
	free(scon);

	printf("Executing: avc_context_to_sid(%s, &tsid);\n", tcon);
    if (avc_context_to_sid(tcon, &tsid) < 0) {
        printf("Could not get TSID - ERROR %s\n", strerror(errno));
        avc_destroy();
        exit(1);
    }
	free(tcon);

	printf("\nExecuting: avc_has_perm(ssid, tsid, %d, requested, &aeref, NULL);\n\n", tclass);
    rc = avc_has_perm(ssid, tsid, tclass, requested, &aeref, NULL);
	switch (rc) {
		case 0:
			printf("\navc_has_perm - Request GRANTED.\n");
			break;
		case -1:
		default:
			if (errno == EACCES)
           		printf("\navc_has_perm - Request DENIED.\n");
       		else
           		printf("\navc_has_perm - ERROR: %s\n", strerror(errno));
			break;
	}
	avc_destroy();
	exit(0);
}
