#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t con;
    security_context_t canoncon;
	int rc;

#ifdef INFO
    printf("\nThe security_canonicalize_context example requires a context to "
                "be selected and\nif valid will return the context that the "
				"kernel is using (as it is possible\nthat a context being "
				"used in userspace is different to that used by the kernel\n"
				"due to using a 'typealias' statement. This example calls the "
				"'raw' function.\n\nFor example if using the Fedora targeted "
				"policy try selecting the following\ncontext:\n\t"
				"unconfined_u:object_r:user_dbusd_tmp_t:s0\n\nThe function "
				"should then return:\n\t"
				"unconfined_u:object_r:session_dbusd_tmp_t\n\nas that is what "
                "the kernel holds due to the use of a 'typealias' "
				"statement in\nthe dbus.te policy module:"
				"\n    typealias session_dbusd_tmp_t alias { user_dbusd_tmp_t "
				"staff_dbusd_tmp_t\n    sysadm_dbusd_tmp_t };\n");

	printf("\nThere is also a security_canonicalize_context_example.conf "
				"module in the\n'modules' directory that has example typealias "
				"statements.\nPress return to continue\n");

    getchar();
#endif

    get_config_entry("[raw_context]", &con);

    printf("\nExecuting: security_canonicalize_context_raw(%s, "
													"&canoncon);\n", con);
    if ((rc = security_canonicalize_context_raw(con, &canoncon)) != 0)
        perror("security_canonicalize_context_raw - ERROR");
	else {
		printf("\nThe context used by the kernel is:\n\t%s\n", canoncon);
        freecon(canoncon);
    }
    exit(0);
}
