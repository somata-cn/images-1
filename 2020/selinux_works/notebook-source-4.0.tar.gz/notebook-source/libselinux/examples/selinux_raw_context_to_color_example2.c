#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <selinux/selinux.h>
#include <selinux/context.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

/*
 * The first function takes as input the hex ascii string (e.g. d2b48c) and
 * converts it to an hex-rgb-color. The second function takes this and converts
 * it to the nearest 256 xterm colour (in this example tan) to allow the
 * foreground (ESC[38;..) or background (ESC[48;..) colours to be displayed
 * for the user:role:type:range.
 * The functions are by Wolfgang Frisch, xororand@frexx.de
 */
extern int readcolor(const char* rgb_string, unsigned char* output);
extern unsigned char rgb2xterm(unsigned char* rgb);

int main(int argc, char **argv)
{
    security_context_t raw;
    char *color_str;
    int rc, count;
	unsigned char color, rgb[3];
	char hex_string[8], fg_buffer[16], bg_buffer[16];
	/* "ESC[0m" resets the xterm to default colours */
	char reset[] = "\x1b[0m\n";
	char *ptr;
    context_t con;

#ifdef INFO
    printf("\nThe selinux_raw_context_to_color example2 requires a raw context "
                "to be selected that will then use a colour/RGB library to "
                "display the entries in the colours\ndefined in the "
                "secolor.conf file (a suitable file is in the 'config' "
				"directory).\n\nNote: To run this correctly the "
                "following must be enabled:\n"
                " a) A translation configuration file at:\n\t%s\n"
                "\n b) A colour configuration file at:\n\t%s\n"
                "\n c) The mcstransd daemon started: service mcstrans start\n",
                		selinux_translations_path(), selinux_colors_path());

	printf("\nNote that if the %s configuration file is\nmissing, then the "
				"default colour string returned is:"
				"\n\t ---- user ----  ---- role ----  ---- type ----  ---- "
				"range ---\n\t#000000 #ffffff #000000 #ffffff #000000 "
				"#ffffff #000000 #ffffff\n"
				"Press return to continue\n", selinux_colors_path());
    getchar();
#endif

    get_config_entry("[raw_context]", &raw);

    printf("Executing: selinux_raw_context_to_color(%s, &color_str);\n", raw);
    if ((rc = selinux_raw_context_to_color(raw, &color_str)) == -1) {
        printf("Failed to get the colour string\n");
        perror("selinux_raw_context_to_color - ERROR");
        exit(1);
    }

    printf("The colour string is: \n\t ---- user ----  ---- role ----  "
				"---- type ----  ---- range ---\n\t%s\n\n", color_str);

	printf("And the context components are:\n");

	/*
	 * This section takes the color_str that contains the eight #RGB fields
	 * and splits it into a foreground / background colour for each of the
	 * four context components (case 0/1 = user etc.). The RGB colours are
	 * converted to the nearest xterm colour by the rgb2xterm function (See
     * the rgb-color-conv.c file that is built into notebook.so).
     *
	 * The context_user/role/type/range_get functions extract the selected
	 * context components that were in 'raw'.
	 */
    con = context_new(raw);
	ptr = strtok(color_str, "#");
	count = 0;
	while (count != 8) {
		if (ptr) {
			memset(hex_string, '\0', sizeof(hex_string));
			strncpy(hex_string, ptr, 6);
			readcolor(hex_string, rgb);
			color = rgb2xterm(rgb);
			ptr = strtok('\0', "#");

			switch (count) {
			case 0:
				/* ESC[38;5;xxxm = foreground colour */
				sprintf(fg_buffer, "\x1b[38;5;%dm", color);
				break;
			case 1:
				/* ESC[48;5;xxxm = background colour */
				sprintf(bg_buffer, "\x1b[48;5;%dm", color);
				printf("\tUser component is:  %s%s%s%s", fg_buffer,
							bg_buffer, context_user_get(con), reset);
				break;
			case 2:
				sprintf(fg_buffer, "\x1b[38;5;%dm", color);
				break;
			case 3:
				sprintf(bg_buffer, "\x1b[48;5;%dm", color);
				printf("\tRole component is:  %s%s%s%s", fg_buffer,
							bg_buffer, context_role_get(con), reset);
				break;
			case 4:
				sprintf(fg_buffer, "\x1b[38;5;%dm", color);
				break;
			case 5:
				sprintf(bg_buffer, "\x1b[48;5;%dm", color);
				printf("\tType component is:  %s%s%s%s", fg_buffer,
							bg_buffer, context_type_get(con), reset);
				break;
			case 6:
				sprintf(fg_buffer, "\x1b[38;5;%dm", color);
				break;
			case 7:
				sprintf(bg_buffer, "\x1b[48;5;%dm", color);
				printf("\tRange component is: %s%s%s%s", fg_buffer,
							bg_buffer, context_range_get(con), reset);
				break;
			default:
				break;
			}
		}
		count++;
	}
    free(color_str);
	freecon(raw);
    context_free(con);
    exit(0);
}
