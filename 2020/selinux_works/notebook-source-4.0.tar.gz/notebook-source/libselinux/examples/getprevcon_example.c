#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc;
    security_context_t context;

#ifdef INFO
    printf("\nThe getprevcon example will retrieve and display the previous "
                    "process context\n(i.e. the one before the last exec)."
                    "\nPress return to continue\n");
    getchar();
#endif

    printf("Executing: getprevcon_raw(&context);\n");

    if ((rc = getprevcon_raw(&context)) == -1) {
        printf("Failed to obtain previous context\n");
        perror("getprevcon_raw - ERROR");
        exit(1);
    }
    printf("The previous context is:\n\t%s\n", context);
    freecon(context);
    exit(0);
}
