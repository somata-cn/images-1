#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    security_context_t context;
    security_context_t new_context;
    char *path;

#ifdef INFO
    printf("\nThe setfilecon example requires a file or directory name to be "
                "selected.\nA getfilecon call is then issued to retrieve and "
                "display the context from the\nfiles xattr "
                "\"security.selinux\" attribute using the getxattr(2) call.\n"
                "If okay, a new context will then need to be selected that "
				"will be set by\nsetfilecon using the setxattr(2) call.\n");;

    printf("\nNote 1: In permissive mode it is possible to set any context "
                "not defined in the\npolicy (such as \"RUBBISH\"). If this is "
                "done, then in permissive mode\ngetfilecon will show the "
                "xattr value (i.e. RUBBISH), however in enforcing mode\nit "
				"will be shown as unlabeled_t if using Reference Policy.\n");

	printf("\nNote 2: If a valid policy context is set in permissive mode BUT "
                "not allowed for\nthe current process by the policy, then in "
				"enforcement mode the context will be\ndisplayed correctly, "
				"however it will not be possible to change it.\n");

	printf("\nNote 3: Add the setfilecon_example.conf policy module to "
				"experiment with\n'deferred mapping of security contexts'. "
				"This will allow contexts NOT defined\nin the current policy "
				"to be set.\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[path]", &path);

    printf("\nExecuting: getfilecon_raw to retrieve the file context:\n");
    if ((rc = getfilecon_raw(path, &context)) == -1) {
        perror("getfilecon_raw - ERROR");
        exit(1);
    }
    printf("The current \"security.selinux\" xattr context assigned to the "
                "file is:\n\t%s length: %d\n", context, rc);
    freecon(context);

    printf("\nNow select a new context.\nPress return to continue\n");
    getchar();
    get_config_entry("[raw_context]", &new_context);

    printf("\nExecuting: setfilecon_raw to set the xattr context to:\n\t%s\n"
				"on the %s file\n", new_context, path);
    if ((rc = setfilecon_raw(path, new_context)) == -1) {
        perror("setfilecon - ERROR");
        freecon(new_context);
        exit(1);
    }

    printf("\nExecuting: getfilecon to retrieve the new file context:\n");
    if ((rc = getfilecon_raw(path, &context)) == -1) {
        perror("getfilecon_raw - ERROR");
        exit(1);
    }
    printf("The new \"security.selinux\" xattr context assigned to the "
                "file is:\n\t%s length: %d\n", context, rc);

    freecon(new_context);
    free(path);
    exit(0);
}
