#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libaudit.h>
#include <errno.h>
#include <selinux/selinux.h>

/* This function handles the 'audit_msg' parameter */
static int cb_audit(void *auditdata, security_class_t class, char *msgbuf,
			size_t msgbufsize);
/* This writes the AVC denied message to the audit log */
static int cb_log(int type, const char *fmt, ...);
/* audit file descriptor */
static int audit_fd;

/* Get config entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t scon, tcon;
	int enforce_mode, rc;
    char *class, *perm_list, *audit_msg = NULL;

#ifdef INFO
    printf("\nThe selinux_check_access example requires a source and target "
                "context plus a\nclass and one permission (if a list is "
				"selected, then only the first is taken). An optional "
				"'audit_msg' can also be selected.\n\nNote that if access is "
				"denied, then an AVC error will be sent to the audit log\n"
				"with the optional 'audit_msg' parameter."
				"\nPress return to continue\n");
	getchar();
#endif

    get_config_entry("[raw_context]", &scon);
    get_config_entry("[raw_context]", &tcon);
	get_config_entry("[class]", &class);
    get_config_entry("[perms]", &perm_list);
	/* Take first in the list if multiple entries */
	strtok(perm_list, " ");

	/* Get the audit string to display and set callback if !NULL */
    get_config_entry("[msg_string]", &audit_msg);
    if ((strcmp(audit_msg, "NULL")) != 0) {
		/*
		 * This callback is optional and used for adding supplemental auditing
		 * information to AVC messages for avc_has_perm.
		 */
		printf("\nExecuting: selinux_set_callback(SELINUX_CB_AUDIT, cb_audit);\n");
    	selinux_set_callback(SELINUX_CB_AUDIT, (union selinux_callback)cb_audit);
	} else
		audit_msg = NULL;

	/*
	 * The SELINUX_CB_LOG callback is required to write AVC messages
	 * to an audit log. If not set then output is to stderr.
	 */
	printf("Executing: selinux_set_callback(SELINUX_CB_LOG, cb_log);\n");
    selinux_set_callback(SELINUX_CB_LOG, (union selinux_callback)cb_log);


	/* Open an audit fd as the standard audit log will be used. */
	printf("Executing: audit_fd = audit_open();\n");
    if ((audit_fd = audit_open()) < 0) {
    	printf("audit_open - ERROR %s\n", strerror(errno));
        exit(1);
    }

    if ((enforce_mode = security_getenforce()) == -1) {
        printf("Failed to get current SELinux enforcing state\n");
        perror("security_getenforce - ERROR");
        exit(1);
    }
    if (!enforce_mode)
        printf("\nNOTE: Currently in permissive mode, therefore this "
							"function will always return\nokay.\n");

    printf("\nExecuting selinux_check_access(%s, %s, %s, %s, audit_msg);\n",
				scon, tcon, class, perm_list);

	if ((rc = selinux_check_access(scon, tcon, class, perm_list, audit_msg))
																	== -1) {
		perror("selinux_check_access - ERROR ");
		if (errno == EACCES)
			printf("Check audit log for AVC message\n");
		exit(1);
	}

	printf("Access allowed\n");
    exit(0);
}


/*
 * This callback (SELINUX_CB_AUDIT) is invoked whenever avc_has_perm calls
 * avc_audit with the auditdata parameter. It becomes the 'msg=' entry in the
 * audit log. This callback is optional - use only if additional AVC info needs
 * to be logged.
 */
static int cb_audit(void *auditdata,
					security_class_t class,
					char *msgbuf,
					size_t msgbufsize)
{
		/******************* Do your processing here *****************/
	/*
	 * The auditdata buffer was updated just before calling avc_has_perm()
	 * The snprintf function will return a negative value.
	 */
    return snprintf(msgbuf, msgbufsize, "%s", (char *)auditdata);
}

/*
 * This callback (SELINUX_CB_LOG) is invoked whenever an audit event needs to
 * be logged. The callback is really mandatory to write messages to the audit
 * log. This example uses the audit_log_user_avc_message to write events to
 * the standard audit log, if required, a different log file could be used.
 */
static int cb_log(int type, const char *fmt, ...)
{
    va_list ap;
    char message[MAX_AUDIT_MESSAGE_LENGTH];
    int rc, audit_type;

		/******************* Do your processing here *****************/
	/*
	 * The 'type' code passed to the logging callback will be one of these:
	 * 		#define SELINUX_ERROR		0
	 * 		#define SELINUX_WARNING		1
	 * 		#define SELINUX_INFO		2
	 * 		#define SELINUX_AVC		    3
	 *
	 * The audit_type entry required by the audit_log_user_avc_message call
	 * is then selected from messages available for the audit library
	 * contained in <libaudit.h>.
	 */
    switch (type) {
        case SELINUX_ERROR:
        	audit_type = AUDIT_USER_SELINUX_ERR;
        	break;
        case SELINUX_WARNING:
        	audit_type = AUDIT_USER_AVC;
        	break;
        case SELINUX_INFO:
        	audit_type = AUDIT_USER_AVC;
    		break;
        case SELINUX_AVC:
        	audit_type = AUDIT_USER_AVC;
    		break;
        default:
        	audit_type = AUDIT_USER_AVC;
	    	break;
    }

    va_start(ap, fmt);
    vsnprintf(message, MAX_AUDIT_MESSAGE_LENGTH, fmt, ap);
	if ((rc = audit_log_user_avc_message(audit_fd, audit_type, message,
												NULL, NULL, NULL, 0)) <= 0) {
    	va_end(ap);
		return -1;
	}
 	else {
	    va_end(ap);
	    return 0;
	}
}
