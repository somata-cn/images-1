#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    security_context_t context;

#ifdef INFO
    printf("\nThe setcon example requires a context to be selected that will be"
                " set by setcon.\nTo check that the context has been set a "
				"getcon is issued to display the\nresult, followed by:\n"
				"\texecvp(\"getcon_example\", argv)\n"
           		"that will execute the getcon_example application and display "
				"the new process\ncontext.\n");

	printf("\nNotes 1) The getcon_example binary needs to be in "
				"/usr/local/bin\n"
				"\n      2) The call requires process { dyntransition } "
				"permission to work as a\n         minimum.\n"
				"\n      3) If using the targeted policy, then there is a "
				"setcon_example.conf\n         policy module supplied in the "
				"'modules' directory that will add the\n         required "
				"dyntransition rule to the policy. A context of:"
				"\n\t\tunconfined_u:unconfined_r:user_t:s0"
				"\n         should then be selected to allow setcon to run.\n"
				"\n      4) See the setcon_thread1_example and setcon_thread2_"
				"example programs for\n         using setcon with threads.\n"
				"\nPress return to continue\n");
    getchar();
#endif

	printf("\nExecuting: getcon_raw(&context)\n");
    if ((rc = getcon_raw(&context)) == -1) {
        printf("Failed to obtain context\n");
        perror("getcon_raw - ERROR");
        exit(1);
    }

    if(context) {
        printf("The current context is:\n\t%s\n", context);
		printf("Press return to continue\n");
    	getchar();
        freecon(context);
    }

    get_config_entry("[raw_context]", &context);
	printf("\nExecuting: setcon_raw(%s)\n", context);

    if ((rc = setcon_raw(context)) == -1) {
        perror("setcon_raw - ERROR");
		printf("Check the audit log for SELinux audit messages as denied "
					"dyntransition\npermission is typical.\n");
        exit(1);
    }
    freecon(context);

    if ((rc = getcon_raw(&context)) == -1) {
        printf("Failed to obtain context\n");
        perror("getcon_raw - ERROR");
        exit(1);
    }

    if(context) {
        printf("\ngetcon returned a current context of:\n\t%s\n", context);
        freecon(context);
    }
    else {
            printf("No context has been set (NULL returned)\n");
            exit(1);
    }

    /*
     * Got here so managed to set the current context and read it back. Now go
     * and run an execvp (or execve etc.) to prove that if the context is
     * valid, then a new task can run in the correct context. If fails check
     * the audit log for SELinux audit messages (denied dyntransition
     * permission is typical).
	 *
	 * Note: If dyntransition allowed, then the transition permission and rules
	 *       are not required.
     */
    printf("\nAbout to execute an execvp with the \"getcon_example\" sample "
				"function:\n\texecvp(\"getcon_example\", argv)\n\nThis will "
				"display the exec'ed context if the set context is valid.\n");

    printf("Executing: \"execvp(\"getcon_example\", argv);\" function\n");
    if ((rc = execvp("getcon_example", argv)) == -1) {
        perror("execvp - ERROR");
        exit(1);
    }
    /* If execve okay, then we don't get here anyway. */
    exit(0);
}
