#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    char *path, *subset, *file_contexts_path = NULL;
    security_context_t context;
    mode_t mode;
    struct stat stat_buf;
    char answer[8];

#ifdef INFO
    printf("\nThe matchpatchcon_file example requires a file contexts file to "
				"be selected\n(choose NULL for the default), then a 'subset' "
				"prefix entry that will be used\nby matchpathcon_init_prefix "
				"to select the entries to be processed. NULL can be\nselected "
				"that will process all entries. Note that matchpathcon by "
				"default\nchecks whether the contexts are valid or not."
				"\n\nOnce initialised, a file can be selected and the files "
				"default context will be\ndisplayed. Press 'q' to quit and "
				"call matchpathcon_checkmatches, or press\nreturn to select "
				"another file.\n");

    printf("\nThe example will check if the file exists (to obtain the mode) "
				"using lstat.\nIf the file does not exist, then mode = 0 is "
				"used.\n\nNote that the context displayed is the 'default "
				"context' and not the context\nthat maybe set on the file (in "
				"the extended attribute). Use the\nselinux_file_context_verify"
				"_example to check if the file is set to the\ndefault.\n");

	printf("\nNote that if the context specified in the file contexts series "
				"of files is\n<<none>>, then error ENOENT is returned."
				"\nPress return to continue\n");
    getchar();
#endif

	get_config_entry("[file_contexts_path]", &file_contexts_path);
    if ((strcmp(file_contexts_path, "NULL")) == 0)
        file_contexts_path = NULL;

	get_config_entry("[subset]", &subset);
    if ((strcmp(subset, "NULL")) == 0)
        subset = NULL;

    printf("\nExecuting matchpathcon_init_prefix(%s, %s);\n",
												file_contexts_path, subset);
    if ((rc = matchpathcon_init_prefix(file_contexts_path, subset)) != 0) {
		perror("matchpathcon_init - ERROR");
	    exit(1);
	}
	free(subset);

	while(1) {
	    get_config_entry("[path]", &path);

    	if (lstat(path, &stat_buf) != 0) {
			printf("\nCould not stat the file: %s\nHowever the default "
					"context that would apply to this file if created "
					"will be\ndisplayed.\n", strerror(errno));
	    	mode = 0;
		}
		else
			mode = stat_buf.st_mode;

    	printf("\nExecuting: matchpathcon(%s, 0x%x, &context);\n\n",
																path, mode);
    	if (matchpathcon(path, mode, &context) == 0 ) {
			printf("The default file context should be:\n\t%s\n",
																	context);
			freecon(context);
        } else {
			switch (errno) {
				case ENOENT:
					printf("\nmatchpathcon failed to find a context."
										"\n\tERROR: %s\n", strerror(errno));
					break;
				case EINVAL:
					printf("\nmatchpathcon failed to validate context, or "
								"the path / mode are invalid.\n\tERROR: %s\n",
															strerror(errno));
					break;
				default:
					printf("\nmatchpathcon ERROR: %s\n", strerror(errno));
					break;
			}
		}
	    free(path);
        printf("\nq for Quit and display matchpathcon_checkmatches or "
                                                    "return to continue.\n");
        fgets(answer, sizeof(answer), stdin);
        if (answer[0] == 'q') {
            printf("matchpathcon_checkmatches returned:\n");
            matchpathcon_checkmatches(NULL);
			break;
        }
	}
   	matchpathcon_fini();
    exit(0);
}
