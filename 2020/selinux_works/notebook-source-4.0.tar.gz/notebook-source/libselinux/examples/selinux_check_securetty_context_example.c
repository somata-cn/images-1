#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t tty_context;
    int rc;

#ifdef INFO
    printf("\nThe selinux_check_securetty_context example requires a context to"
				" be selected.\nThe selinux_check_securetty_context function "
				"will then check whether the 'type'\ncomponent of the context "
				"is defined in the %s configuration file as a secure tty "
				"context.\nPress return to continue\n",
											selinux_securetty_types_path());
	getchar();
#endif

    get_config_entry("[raw_context]", &tty_context);

    printf("Executing: selinux_check_securetty_context(%s);\n", tty_context);
    if ((rc = selinux_check_securetty_context(tty_context)) < 0)
        printf("\nThe context is NOT defined in the securetty_types file.\n");
    else
        printf("\nThe context is defined in the securetty_types file.\n");

    exit(0);
}
