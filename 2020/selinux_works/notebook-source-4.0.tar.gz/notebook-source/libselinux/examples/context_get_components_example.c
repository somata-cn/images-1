#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>
#include <selinux/context.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t fromcon;
    context_t con;
    const char *con_ptr;
    const char *user;
    const char *role;
    const char *type;
    const char *range;
    int rc;

#ifdef INFO
    printf("\nThe context_get_components example requires a context "
                "to be selected.\nThe context_xxxx_get functions are then "
                "used to display the individual context\ncomponents. "
                "Finally security_check_context is called to check that the\n"
                "context is valid.\n"
                "\nThe functions used in this example are: context_new, "
                "context_str,\ncontext_user_get, context_role_get, "
                "context_type_get, context_range_get,\ncontext_free and "
                "security_check_context.\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[raw_context]", &fromcon);

/*
 * Copy the context to a new context string so the components can be obtained
 * using the context_xxx_get functions.
 */
    printf("Executing: context_new(%s);\n", fromcon);
    if ((con = context_new(fromcon)) == NULL) {
        perror("context_new - ERROR");
    }

/* Get a pointer to the new context and print the full context */
    printf("Executing: context_str(con);\n");
    if ((con_ptr = context_str(con)) == NULL) {
        perror("context_str - ERROR");
        exit(1);
    }
    printf("\nNow show the components from this context string:\n\t%s\nusing "
                "the context_xxxx_get functions to isolate the individual "
                "components:\n", con_ptr);

/* Now get and display each component of the security context */
    if ((user = context_user_get(con)) == NULL) {
        perror("context_user_get - ERROR");
        exit(1);
    }
    printf("\tThe user is:  %s\n", user);

    if ((role = context_role_get(con)) == NULL) {
        perror("context_role_get - ERROR");
        exit(1);
    }
    printf("\tThe role is:  %s\n", role);

    if ((type = context_type_get(con)) == NULL) {
        perror("context_type_get - ERROR");
        exit(1);
    }
    printf("\tThe type is:  %s\n", type);

    if ((range = context_range_get(con)) == NULL) {
        perror("context_range_get - ERROR");
        exit(1);
    }
    printf("\tThe range is: %s\n", range);

    if ((rc = security_check_context(fromcon)) < 0)
        printf("and security_check_context confirms that it is not a "
                                                            "valid context.\n");
    else
        printf("and security_check_context confirms that it is a valid "
                                                                "context.\n");

/* Finally free the string */
    context_free(con);
    exit(0);
}
