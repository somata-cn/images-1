#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <selinux/selinux.h>
#include <selinux/get_context_list.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    const char *user;
    const char *role;
    const char *level;
    security_context_t fromcon = NULL;
    security_context_t newcon = NULL;
    int rc;

#ifdef INFO
    printf("\nThe get_default_context_with_rolelevel example requires a user, "
                "role, level\nand context entries to be selected. The "
                "default context for the user is then\nobtained using the "
                "supplied role and level.\n");

    printf("\nNotes: 1) Select the context NULL entry to use the current "
                "process context.\n\n"
                "       2) If the policy does not support MCS/MLS then the "
                "NULL level entry\n          should be selected."
                "\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[user]", (char **)&user);
    get_config_entry("[role]", (char **)&role);
	get_config_entry("[level]", (char **)&level);
    if ((strcmp(level, "NULL")) == 0)
        level = NULL;

    get_config_entry("[raw_context]", &fromcon);
    if ((strcmp(fromcon, "NULL")) == 0)
        fromcon = NULL;


    printf("Executing: get_default_context_with_role(%s, %s, %s, %s, &newcon);"
                                        "\n", user, role, level, fromcon);

    if ((rc = get_default_context_with_rolelevel(user, role, level,
                                                fromcon, &newcon)) != 0) {
		printf("Could not retrieve a default context based on role and "
																"level.\n");
        perror("get_default_context_with_rolelevel - ERROR");
        exit(1);
    }
    printf("The returned default context is:\n\t%s\n",  newcon);

    freecon(fromcon);
    freecon(newcon);
    exit(0);
}
