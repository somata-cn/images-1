#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    int value;
    char *name;
    char answer [2];

#ifdef INFO
    printf("\nThe security_set_boolean example requires a boolean entry "
				"to be selected and\nthen either a '0' (false/off) or '1' "
				"(true/on) to set the booleans pending\nvalue.\n");

	printf("\nNotes 1) The boolean will not be set permanently, to do this "
				"it needs to be\n         written to a booleans or "
				"booleans.local file "
				"using the\n         security_set_boolean_list, or "
				"alternativily use the semanage boolean\n         options.\n"
				"\n      2) The boolean value will be set as 'pending' but "
				"not activated. To\n         activate the pending booleans "
				"(i.e. modify the policy), the\n         "
				"security_commit_booleans, security_load_booleans or the "
				"semanage\n         boolean options should be called "
				"depending on the method used to\n         manage booleans."
				"\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[boolean]", &name);

    printf("\nEnter '0' (false) or '1' (true) to set a pending value for "
                                                            "the boolean:\n");
    fflush(stdin);
    fgets (answer, sizeof(answer), stdin);
    value = atoi(answer);

    printf("Executing: security_set_boolean(%s, %d);\n", name, value);

    if ((rc = security_set_boolean(name, value)) == -1) {
        printf("FAILED to set boolean pending for %s with %s\n", name,
                                            value ? "true (1)" : "false (0)");
        perror("security_set_boolean - ERROR");
    }
    else
        printf("Set boolean %s pending with %s\n", name,
                                            value ? "true (1)" : "false (0)");

    exit(0);
}
