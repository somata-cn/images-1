#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc, enforce_mode;
    char answer[2];

	printf("\nThe security_setenforce example will allow SELinix to be set in "
				"enforcing or\npermissive mode. security_getenforce will then "
				"be called to display the status.\n");

    printf("\n\tThe current enforcement mode is: %s\n",
                        security_getenforce() ? "ENFORCING" : "PERMISSIVE");

    do {
        printf("\nEnter 1 (enforcing) or 0 (permissive):\n");
	    fgets(answer, sizeof(answer), stdin);
	} while (answer[0] != '0' && answer[0] != '1');
	enforce_mode = atoi(answer);

    printf("Executing: security_setenforce(%d);\n", enforce_mode);

    if ((rc = security_setenforce(enforce_mode)) == -1) {
        printf("Failed to set enforcement mode\n");
        perror("security_setenforce - ERROR");
        exit(1);
    }
    printf("\nThe enforcement mode has been set to: %s\n",
                        security_getenforce() ? "ENFORCING" : "PERMISSIVE");
    exit(0);
}
