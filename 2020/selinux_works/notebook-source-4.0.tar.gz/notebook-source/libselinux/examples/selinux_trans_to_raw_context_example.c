#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t rawp;
    security_context_t trans;
    int rc;

#ifdef INFO
    printf("\nThe selinux_trans_to_raw_context example requires a text based "
                "context to be\nselected that will then be converted to its "
				"raw value.\nNote to run this correctly the following must "
				"be enabled:\n"
                " a) A translation configuration file at:\n\t%s\n"
                "    This will need entries to reflect the translation of the "
				"context as if\n    not present the context is returned "
				"unchanged.\n"
                "\n b) The mcstransd daemon started: service mcstrans start\n"
                "Press return to continue\n", selinux_translations_path());
    getchar();
#endif

    get_config_entry("[trans_context]", &trans);

    printf("\nExecuting: selinux_trans_to_raw_context(%s, &rawp);\n", trans);
    if ((rc = selinux_trans_to_raw_context(trans, &rawp)) < 0) {
        printf("Failed to get raw context\n");
        perror("selinux_trans_to_raw_context - ERROR");
        exit(1);
    }

    printf("\nThe raw context is: %s\n\n", rawp);
    freecon(rawp);
    exit(0);
}
