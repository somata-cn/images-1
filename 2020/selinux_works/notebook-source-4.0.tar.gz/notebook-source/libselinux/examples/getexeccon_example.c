#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc;
    security_context_t context;

#ifdef INFO
    printf("\nThe getexeccon example will retrieve and display the context "
                    "used for executing\na new process. It is normally 'null' "
                    "unless it has been set by setexeccon."
                    "\nPress return to continue\n");
	getchar();
#endif

    printf("Executing: getexeccon_raw(&context)\n");

    if ((rc = getexeccon_raw(&context)) == -1) {
        printf("Failed to obtain exec context\n");
        perror("getexeccon_raw - ERROR");
        exit(1);
    }

    if(context) {
        printf("The returned exec context is:\n\t%s\n", context);
        freecon(context);
    }
    else
        printf("No context has been set. %s returned\n", context);
    exit(0);
}
