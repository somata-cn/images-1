#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc;
    char path[PATH_MAX];

#ifdef INFO
	printf("\nThe security_load_booleans example will load the booleans from "
				"the specified\npath using the 'booleans' file or if not "
				"present the 'booleans.local' file.\n\nNote that the function "
				"calls security_commit_booleans and then returns even\nif "
				"there were no boolean files found (i.e. the "
				"security_load_booleans\nfunction only errors if the boolean "
				"files have invalid entries.\n");

	printf("\nThe format of the boolean files are as follows:\n"
				"\t<boolean_name> <true | false | 0 | 1>\n");
#endif

    /* Ask for path name: */
    printf("\nEnter a path to the boolean file or Return to load the active "
            "policy booleans\n(%s). Note that the path must end with"
			" \"booleans\" as this will be used as the base (e.g. "
			"/home/rch/booleans).\n\nEnter path or Return to load the active "
            "policy booleans:\n", selinux_booleans_path());
    fgets(path, sizeof(path), stdin);
	/* Remove the cr */
	path[strlen(path)-1] = 0;

    printf("Executing security_load_booleans(%s);\n",
                                    path[0] ? path : selinux_booleans_path());
    if (path[0] == 0)
        rc = security_load_booleans(NULL);
    else
        rc = security_load_booleans(path);

    if (rc == 0)
        printf("Loaded booleans\n");
    else
        perror("security_load_booleans - ERROR");

    exit(0);
}
