#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
#ifdef INFO
    printf("\nThe selinux_reset_config example will reset the current "
				"configuration to the\nnew one specified in the updated "
				"SELinux configuration file.\nPress return to continue\n");
    getchar();
#endif

    printf("Executing: selinux_reset_config();\n\n");

    /* Setting errno to zero and then checking if reset after call will show
	 * if the config file is missing (ENOENT) but no other errors returned. */
    errno = 0;
    selinux_reset_config();

    if (errno != 0)
		printf("Failed to reset entries in %sconfig - ERROR %s\n",
                                            selinux_path(), strerror(errno));
    else
        printf("Reloaded configuration based on the following entries "
					"in %sconfig:\n\tSELINUXTYPE (mandatory entry)"
                    "\n\tSETLOCALDEFS and REQUIRESEUSERS (optional entries)\n",
																selinux_path());

    exit(0);
}
