/*
 * basic_compute_av - This will take a source and target context along with a
 * class (the requested permission is set to 1) and passes them to
 * /selinux/access that will return the permissions allowed, those that must be
 * audited etc.
 *
 * The reason why 'requested' is set to one is that the returned 'allowed'
 * permissions will contain all permissions allowed for the source, target
 * and class.
 *
 * Note that on some classes the bits are set as you would normally expect, for
 * example class = file would return something like '0x00100257', where the
 * unused high-order bits are set to 0. However some, for example class =
 * x_keyboard returns '0xffffffff' where the unused high order bits are set to
 * 1's that is a bit confusing (it should be 0x0007ffff if all permissions
 * were allowed for x_keyboard).
 *
 * This code has been derived from the libselinux source.
 */

#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <limits.h>
#include <selinux/selinux.h>

/* selinuxfs mount point */
extern char *selinux_mnt;

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

/*
 * avd->seqno = number of policy load since last boot.
 *
 * Currently one flag is supported: SELINUX_AVD_FLAGS_PERMISSIVE, which
 * indicates the decision is computed on a permissive domain.
 * #define SELINUX_AVD_FLAGS_PERMISSIVE    0x0001
 * Try: 'semanage permissive -a unconfined_t' and then checking access.
*/


int main(int argc, char **argv)
{
    security_context_t scon;
    security_context_t tcon;
    security_class_t tclass;
	access_vector_t requested = 1;
	struct av_decision avd_buf;
	struct av_decision *avd;
    int selinux_page_size = sysconf(_SC_PAGE_SIZE);
	char path[PATH_MAX];
	char *buf;
	int fd, rc;
    char *class;

    avd = &avd_buf;

    printf("\nThe basic_compute_av example requires a source and target context"
                ", plus a class\nentry to be selected. Note that the requested "
                "permission is pre-set to 1 as all\nvalid permissions are "
                "returned by default anyway. Note that the class entered\n"
				"is the name and not the tclass number. This is converted to "
				"the number by\nthe string_to_security_class function.\n"
				"Be aware that the deny_unknown flag will influence the "
				"outcome for invalid\nclasses (tclass = 0)"
				"\nPress return to continue\n");
    getchar();
    get_config_entry("[raw_context]", &scon);
    get_config_entry("[raw_context]", &tcon);

	/* Could use these functions if the actual number is required: */
/*	get_config_entry("[class_flask]", &class); */
/*  tclass = strtol(class, (char **)&class[3], 10); */
	/* Instead of these: */
	get_config_entry("[class]", &class);
	tclass = string_to_security_class(class);

    sprintf(path, "%s/access", selinux_mnt);
	if ((fd = open(path, O_RDWR)) < 0) {
	    perror("OPEN FAILED");
	    exit(1);
	}

    if ((buf = malloc(selinux_page_size)) == NULL) {
	    perror("MALLOC FAILED");
	    exit(1);
	}

	snprintf(buf, selinux_page_size, "%s %s %hu %x", scon, tcon, tclass,
	                                                                requested);
    printf("About to write scon, tcon, class and requested permission to\n"
                                        "%s:\n\t%s %s %hu %x\n\n",
										path, scon, tcon, tclass, requested);
	if ((rc = write(fd, buf, strlen(buf))) < 0) {
	    perror("WRITE FAILED");
	    exit(1);
	}

	memset(buf, 0, selinux_page_size);

	if ((rc = read(fd, buf, selinux_page_size - 1)) < 0) {
	    perror("READ FAILED");
	    exit(1);
	}

	if ((rc = sscanf(buf, "%x %x %x %x %u %x",
		     &avd->allowed, &avd->decided,
		     &avd->auditallow, &avd->auditdeny,
		     &avd->seqno, &avd->flags)) != 6) {
	    printf("SSCANF FAILED - did not receive 6 fields");
	    exit(1);
	}

	printf("The returned buffer is:\n"
	        "\tallowed     decided     auditallow  auditdeny   seqno   flags\n"
	        "\t0x%08x  0x%08x  0x%08x  0x%08x    %u     0x%04x\n",
		     avd->allowed, avd->decided,
		     avd->auditallow, avd->auditdeny,
		     avd->seqno, avd->flags);
    /* Use print_access_vector to display the permissions as text */
    if (avd->allowed != 0) {
        printf("\nprint_access_vector will display the allowed permissions\n");
        print_access_vector(tclass, avd->allowed);
        printf("\n");
    }
    else
        printf("\nNo permissions were allowed\n");

    free(class);
	free(buf);
	close(fd);
	exit(0);
}
