#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/stat.h>
#include <selinux/selinux.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    char *path;
    mode_t mode;
    struct stat stat_buf;

#ifdef INFO
    printf("\nThe selinux_file_context_verify example requires a file name to "
                    "be selected to\ncheck that its context 'on disk' matches "
                    "that specified in the file_contexts\nseries of files.\n\n"
					"Note that the function internally calls "
					"selinux_file_context_cmp to compare the\ncontexts, "
					"therefore the user component is ignored.\nNote that lstat "
					"is called first to obtain the value for the 'mode' entry."
					"\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[path]", &path);

	/*
	 * This will retrieve the file mode for passing to
	 * selinux_file_context_verify. If the file cannot be found,
	 * selinux_file_context_verify will be passed a mode of 0, however the
	 * selinux_file_context_verify will fail as it checks whether the
	 * file exists or not using lgetfilecon_raw. Passing the mode over allows
	 * file mode / type matching (otherwise any entry would match).
	 */
    if (lstat(path, &stat_buf) != 0) {
		printf("\nCould not stat the file: %s.\nTherefore passing mode = 0 to "
					"selinux_file_context_verify.\n", strerror(errno));
	    mode = 0;
	}
	else
		mode = stat_buf.st_mode;

    printf("\nExecuting: selinux_file_context_verify(%s, 0x%x);\n\n",
                                                                path, mode);
    rc = selinux_file_context_verify(path, mode);

    switch (rc) {
        case 0:
            printf("The context is different 'on disk' to that specified "
                  "in the file_contexts series of files (return 0).\n\n");
            break;
        case 1:
            printf("The contexts match 'on disk' with that specified in the "
                        "file_contexts series of files (return 1).\n\n");
            break;
        case -1:
            printf("Error returned -1\n");
            perror("selinux_file_context_verify - ERROR");
            break;
    }
    free(path);
    exit(0);
}
