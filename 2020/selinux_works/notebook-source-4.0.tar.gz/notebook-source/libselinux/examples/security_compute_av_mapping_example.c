#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <selinux/selinux.h>

static struct security_class_mapping map[] = {
    { "file",           /* "file" object class ID will be 1 */
        { "execute",    /* "execute" permission 0x00000001  */
          "read",       /* "read" permission    0x00000002  */
          "write",      /* "write" permission   0x00000004  */
          NULL } },     /* End of FILE object class definition for this OM */
     { NULL }			/* End of mapping definitions */
};

#define FILE_ID 	1
#define EXECUTE_ID	0x00000001
#define READ_ID		0x00000002
#define WRITE_ID	0x00000004

/* Get config entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    security_context_t scon, tcon;
    security_class_t tclass;
	access_vector_t requested, denied, av_perm;
	struct av_decision avd;
	int rc, deny_unknown;
    char *class, *perm_list = NULL;
    const char *ptr = NULL;

#ifdef INFO
    printf("\nThe security_compute_av_mapping example requires a source and "
                "target context\nplus a class and one or more permissions. "
                "Note that the class and permissions\nentered are the string "
				"values. These are then converted to the ID/bit mask\nby the "
				"string_to_security_class and string_to_av_perm functions.\n"
				"\nShould the class be invalid (tclass = 0), then "
				"security_deny_unknown is called\nto check whether the "
				"permissions will be granted or not before executing\n"
				"security_compute_av.\n\nIf any of the selected "
				"permissions are invalid, then there will be a warning\n"
				"issued.\n\nNOTE: Bug in libselinux - if tclass = 0, then "
				"access denied - fixed in 2.1.8."
				"\nPress return to continue\n");
	getchar();
#endif

    printf("\nExecuting: selinux_set_mapping(map);\n");
    if (selinux_set_mapping(map) < 0) {
        perror("selinux_set_mapping - ERROR");
        if (errno == EINVAL) {
            printf("Invalid object class mapping\n");

            exit(1);
        }
        printf("Could not set up the object class mapping\n");
        exit(1);
    }
	printf("The selinux_set_mapping is complete.\n\n");

	printf("The ONLY valid object class is now %s with the following "
				"permissions:\n", security_class_to_string(1));
	print_access_vector(FILE_ID, EXECUTE_ID | READ_ID | WRITE_ID);
	printf("\nPress return to continue\n");
	getchar();

    get_config_entry("[raw_context]", &scon);
    get_config_entry("[raw_context]", &tcon);

	get_config_entry("[class]", &class);
	tclass = string_to_security_class(class);

    get_config_entry("[perms]", &perm_list);

	if (tclass != 0) {
		/* Convert perm_list to 'requested' bit map for valid classes*/
		printf("\nNow convert the permissions to a bit mask using "
													"'string_to_av_perm'\n");
		ptr = strtok(perm_list, " ");
    	if ((av_perm = string_to_av_perm(tclass, ptr)) == 0) {
			printf("Warning invalid permission: %s\n", ptr);
			printf("Press return to continue\n");
			getchar();
    	}
		requested = 0;
		requested = requested | av_perm;
		do {
			ptr = strtok(NULL, " ");
			if (ptr) {
    			if ((av_perm = string_to_av_perm(tclass, ptr)) == 0) {
					printf("Warning invalid permission: %s\n", ptr);
					printf("Press return to continue\n");
					getchar();
    			}
				requested = requested | av_perm;
			}
		} while (ptr);

    	free(perm_list);
		/* Now reconvert the perm bits to a list. This will show those that are
		   really supported by the class */
		perm_list = NULL;
		security_av_string(tclass, requested, &perm_list);
		printf("\nThe valid permissions requested are:\n\t%s\n", perm_list);
		printf("Press return to continue\n");
		getchar();

	} else { /* Because invalid class, add all permissions as with no perms
				set, the request will be denied */
		requested = ~0;
		printf("\nThe class chosen is invalid (tclass = 0), therefore "
					"setting all permission\nbits\n");
		printf("\nExecuting: security_deny_unknown();\n");
		deny_unknown = security_deny_unknown();
		printf("\nQueries on undefined object classes and permissions are: "
								"%s\n", (deny_unknown ? "DENIED" : "ALLOWED"));

		printf("Therefore, as the selected class is undefined, the request "
						"will be %s.\n", deny_unknown ? "DENIED" : "ALLOWED");
		printf("\nPress return to continue\n");
		getchar();
	}

    free(perm_list);
	free(class);

    printf("\nExecuting security_compute_av_raw(%s, %s, %d, 0x%08x, &avd);\n",
                                                scon, tcon, tclass, requested);

    if ((rc = security_compute_av_raw(scon, tcon, tclass, requested, &avd))
                                                                        < 0) {
        perror("security_compute_av_raw - ERROR");
        exit(1);
    }

	printf("\nReturned avd entries are:\n"
	        "\tallowed     decided     auditallow  auditdeny   seqno\n"
	        "\t0x%08x  0x%08x  0x%08x  0x%08x    %u\n",
		     avd.allowed, avd.decided, avd.auditallow,
		     avd.auditdeny, avd.seqno);

    /* Print class and permissions */
    printf("\nFor source context: %s\n    target context: %s\n        with "
				"class: %s\n", scon, tcon, security_class_to_string(tclass));

	printf("and requested permissions of:\n\t");
	print_access_vector(tclass, requested);

	/* Now get the actual denied permissions */
	denied = requested & ~avd.allowed;
	printf("\n\nthe request would be: %s\n",
							(denied || !requested) ? "DENIED" : "GRANTED");

	if (denied) {
		printf("\nbecause of the following denied permissions:\n\t");
		print_access_vector(tclass, denied);
		printf("\n");
	}

	printf("\nPress return to continue\n");
	getchar();

	/* Now give general information regarding the permissions allowed/denied */
	printf("\n\t*********** General Information ************\n\n");

	printf("The following permissions will be allowed:\n\t");
    print_access_vector(tclass, avd.allowed);
	printf("\n\nThe following permissions will be denied:\n\t");
    print_access_vector(tclass, ~avd.allowed);
	printf("\n\n");
	/*
	 * The auditallow field permission bits are set to a '1' if an
	 * 'auditallow' rule specified that an event MUST be audited.
	 */
	if (avd.auditallow == 0)
		printf("There are no mandatory audit events (auditallow rules).\n\n");
	else {
	    printf("The following permissions have mandatory audit events "
											"(using auditallow rules):\n\t");
		print_access_vector(tclass, avd.auditallow);
		printf("\n\n");
	}

	printf("The policy has been loaded %d times since initial boot.\n",
																avd.seqno);
    exit(0);
}
