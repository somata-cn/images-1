#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc;
    int enforce;

#ifdef INFO
    printf("\nThe selinux_init_load_policy function is normally used to load "
				"the initial\npolicy via init. However it can be called after "
				"the initial load but will only\nreset the current "
				"configuration to the new one specified in the updated\n"
				"SELinux configuration file and then attempt to load the "
				"specified policy\n(defined in the SELINUXTYPE= entry).\n"
				"\nNote that the enforcement mode is that specified in the "
				"SELINUX= entry and\nnot the current mode."
				"\nPress return to continue\n");
    getchar();
#endif

    printf("Executing selinux_init_load_policy(&enforce);\n");

    if ((rc = selinux_init_load_policy(&enforce)) == -1) {
        printf("Cannot load policy\n");
        perror("selinux_init_load_policy - ERROR");
    }
    else
        printf("Policy loaded with an enforcement mode of: %s\n",
                                    enforce ? "ENFORCING" : "PERMISSIVE");

    exit(0);
}
