#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int rc;

#ifdef INFO
    printf("\nThe is_selinux_enabled example checks whether SELinux is enabled "
                    "or not.\nSELinux is considered enabled if the SELinux "
                    "filesystem is avaliable and a\npolicy is loaded. Note "
                    "that if the filesystem is available but no policy is\n"
                    "loaded, then SELinux is considered disabled.\n");
#endif

    printf("\nExecuting: is_selinux_enabled();\n\n");

    rc = is_selinux_enabled();
    switch (rc) {
        case 0:
            printf("SELinux is not enabled.\n");
            break;
        case 1:
            printf("SELinux is enabled.\n");
            break;
        default:
            printf("Cannot determine SELinux state\n");
            perror("is_selinux_enabled - ERROR");
            break;
    }
    exit(0);
}
