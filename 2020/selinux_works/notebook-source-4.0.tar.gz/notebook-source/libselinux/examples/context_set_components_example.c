#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>
#include <selinux/context.h>

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
/* The functions need a starting context with at least the minimum
 * of "x:y:z" to work.
 */
    security_context_t fromcon = "user:role:type";

    /* This will contain the new context built by the functions*/
    security_context_t newfromcon = NULL;

/* These are the new context components used to build newfromcon
 * Note that the context components are not checked against the policy.
 * This must be done by a function such as security_check_context that is
 * shown at the end.
 */
    context_t con;
    const char *user;
    const char *role;
    const char *type;
    const char *range;
    int rc;

#ifdef INFO
    printf("\nThe context_set_components example requires a user, "
                "role, type and\noptional range entries to be selected. The "
                "context_xxxx_set functions will\nthen be used to build a "
                "context in a security_context_t structure. Finally\n"
                "security_check_context is called to check that the context "
                "is valid.\n\nThe functions used in this example are: "
                "is_selinux_mls_enabled, context_new,\ncontext_str, "
                "context_user_set, context_role_set, context_type_set,\n"
                "context_range_set (if MCS/MLS enabled), context_free and "
                "security_check_context.\nPress return to continue\n");
#endif

    getchar();

    get_config_entry("[user]", (char **)&user);
    get_config_entry("[role]", (char **)&role);
    get_config_entry("[type]", (char **)&type);
    if (is_selinux_mls_enabled())
        get_config_entry("[range]", (char **)&range);
/*
 * Need to initialise the 'context_t con' with a context string before
 * we start using the context_xxxx_get functions, otherwise the calls get
 * bitter & twisted. It can be any context but it MUST have the colons:
 * a:b:c: or user:role:type:level etc.
 */
    printf("Executing: context_new(fromcon); to initialise the starting "
                                            "context with:\n\t%s\n", fromcon);
    if ((con = context_new(fromcon)) == NULL) {
        perror("context_new - ERROR");
        exit(1);
    }

   printf("\nNow building context string using the context_xxxx_set "
															"functions:\n");

    if ((rc = context_user_set(con, user)) == 1) {
        perror("context_user_set- ERROR");
        exit(1);
    }
    newfromcon = context_str(con);
    printf("\twith new user: %s\n", newfromcon);

    if ((rc = context_role_set(con, role)) == 1) {
        perror("context_role_set - ERROR");
        exit(1);
    }
    newfromcon = context_str(con);
    printf("\tplus new role: %s\n", newfromcon);

    if ((rc = context_type_set(con, type)) == 1) {
        perror("context_type_set - ERROR");
        exit(1);
    }
    newfromcon = context_str(con);
    printf("\tplus new type: %s\n", newfromcon);

    if (is_selinux_mls_enabled()) {
        if ((rc = context_range_set(con, range)) == 1) {
            perror("context_range_set - ERROR");
            exit(1);
        }
        newfromcon = context_str(con);
        printf("\tplus new range: %s\n", newfromcon);
    }

    printf("\nTherefore the new context is:\n\t%s\n", newfromcon);

    if ((rc = security_check_context_raw(newfromcon)) < 0)
        printf("and security_check_context confirms that it is not a "
                                                           "valid context.\n");
    else
        printf("and security_check_context confirms that it is a valid "
                                                                "context.\n");
/* Finally free the string */
    context_free(con);
    exit(0);
}
