#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>

int main(int argc, char **argv)
{
    int enforce_mode;

#ifdef INFO
	printf("\nThe security_getenforce example will return the current "
                "enforcement mode of\nSELinux.\n");
#endif

    printf("\nExecuting: security_getenforce();\n");

    if ((enforce_mode = security_getenforce()) == -1) {
        printf("FAILED to get the enforcement mode.\n");
        perror("security_getenforce - ERROR");
    }
    else
        printf("\nThe current SELinux enforcement mode is: %s\n",
                                enforce_mode ? "ENFORCING" : "PERMISSIVE");
    exit(0);
}
