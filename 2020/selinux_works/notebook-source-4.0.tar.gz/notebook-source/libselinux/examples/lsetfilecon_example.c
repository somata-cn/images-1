#include <stdio.h>
#include <stdlib.h>
#include <selinux/selinux.h>
/*
ln -s $HOME/THIS-FILE/root/Documents/THIS-FILE-symlink
*/

/* Get entries from $HOME/notebook.conf file */
extern void get_config_entry(char *entry, char **content);

int main(int argc, char **argv)
{
    int rc;
    security_context_t context;
    security_context_t new_context;
    char *path;

#ifdef INFO
    printf("\nThe lsetfilecon example requires a file or directory name to be "
                "selected.\nIf the file is a symbolic link it will "
                "retrieve and display the context from\nthe symbolic link "
                "entries \"security.selinux\" attribute. If the file is not a "
				"\nsymbolic link it acts as getfilecon.\n"
                "If okay, a new context will then need to be selected that "
                "will be set by\nlsetfilecon using the lsetxattr(2) call.\n");

    printf("\nNote 1: In permissive mode it is possible to set any context "
                "not defined in the\npolicy (such as \"RUBBISH\"). If this is "
                "done, then in permissive mode\nlgetfilecon will show the "
                "xattr value (i.e. RUBBISH), however in enforcing mode it will "
                "be shown as unlabeled_t if using the Reference Policy.\n");

	printf("\nNote 2: If a valid policy context is set in permissive mode BUT "
                "not allowed for\nthe current process by the policy, then in "
				"enforcement mode the context will be\ndisplayed correctly, "
				"however it will not be possible to change it.\n");

	printf("\nNote 3: Add the mac_admin_example.conf policy module to "
				"experiment with\n'deferred mapping of security contexts' "
				"(but remove module afterwards)."
				"\nPress return to continue\n");
    getchar();
#endif

    get_config_entry("[path]", &path);

    printf("\nNow obtaining the current file context via lgetfilecon_raw:\n");
    if ((rc = lgetfilecon_raw(path, &context)) == -1) {
        perror("lgetfilecon_raw - ERROR");
        exit(0);
    }
    printf("The current \"security.selinux\" xattr context assigned to the "
                "file is:\n\t%s length: %d\n", context, rc);
    freecon(context);

    printf("\nNow select a new context\nPress return to continue\n");
    getchar();

    get_config_entry("[raw_context]", &new_context);

    printf("\nExecuting: lsetfilecon_raw(%s, %s);\n", path, new_context);
    if ((rc = lsetfilecon_raw(path, new_context)) == -1) {
        freecon(new_context);
        perror("lsetfilecon_raw - ERROR");
        exit(0);
    }
    freecon(new_context);
    free(path);
    exit(0);
}
