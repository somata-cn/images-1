/*
 * libselinux header file for selinux_set_mapping(3)
 * containing Kernel + Userspace classes and permissions
 */
static struct security_class_mapping map[] = {

	{ "security", { "compute_av", "compute_create", "compute_member", "check_context", "load_policy", "compute_relabel", "compute_user", "setenforce", "setbool", "setsecparam", "setcheckreqprot", "read_policy", NULL } },

	{ "process", { "fork", "transition", "sigchld", "sigkill", "sigstop", "signull", "signal", "ptrace", "getsched", "setsched", "getsession", "getpgid", "setpgid", "getcap", "setcap", "share", "getattr", "setexec", "setfscreate", "noatsecure", "siginh", "setrlimit", "rlimitinh", "dyntransition", "setcurrent", "execmem", "execstack", "execheap", "setkeycreate", "setsockcreate", NULL } },

	{ "system", { "ipc_info", "syslog_read", "syslog_mod", "syslog_console", "module_request", NULL } },

	{ "capability", { "chown", "dac_override", "dac_read_search", "fowner", "fsetid", "kill", "setgid", "setuid", "setpcap", "linux_immutable", "net_bind_service", "net_broadcast", "net_admin", "net_raw", "ipc_lock", "ipc_owner", "sys_module", "sys_rawio", "sys_chroot", "sys_ptrace", "sys_pacct", "sys_admin", "sys_boot", "sys_nice", "sys_resource", "sys_time", "sys_tty_config", "mknod", "lease", "audit_write", "audit_control", "setfcap", NULL } },

	{ "filesystem", { "mount", "remount", "unmount", "getattr", "relabelfrom", "relabelto", "transition", "associate", "quotamod", "quotaget", NULL } },

	{ "file", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "unlink", "link", "rename", "execute", "swapon", "quotaon", "mounton", "execute_no_trans", "entrypoint", "execmod", "open", "audit_access", NULL } },

	{ "dir", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "unlink", "link", "rename", "execute", "swapon", "quotaon", "mounton", "add_name", "remove_name", "reparent", "search", "rmdir", "open", "audit_access", "execmod", NULL } },

	{ "fd", { "use", NULL } },

	{ "lnk_file", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "unlink", "link", "rename", "execute", "swapon", "quotaon", "mounton", "open", "audit_access", "execmod", NULL } },

	{ "chr_file", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "unlink", "link", "rename", "execute", "swapon", "quotaon", "mounton", "execute_no_trans", "entrypoint", "execmod", "open", "audit_access", NULL } },

	{ "blk_file", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "unlink", "link", "rename", "execute", "swapon", "quotaon", "mounton", "open", "audit_access", "execmod", NULL } },

	{ "sock_file", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "unlink", "link", "rename", "execute", "swapon", "quotaon", "mounton", "open", "audit_access", "execmod", NULL } },

	{ "fifo_file", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "unlink", "link", "rename", "execute", "swapon", "quotaon", "mounton", "open", "audit_access", "execmod", NULL } },

	{ "socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", NULL } },

	{ "tcp_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", "connectto", "newconn", "acceptfrom", "node_bind", "name_connect", NULL } },

	{ "udp_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", "node_bind", NULL } },

	{ "rawip_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", "node_bind", NULL } },

	{ "node", { "tcp_recv", "tcp_send", "udp_recv", "udp_send", "rawip_recv", "rawip_send", "enforce_dest", "dccp_recv", "dccp_send", "recvfrom", "sendto", NULL } },

	{ "netif", { "tcp_recv", "tcp_send", "udp_recv", "udp_send", "rawip_recv", "rawip_send", "dccp_recv", "dccp_send", "ingress", "egress", NULL } },

	{ "netlink_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", NULL } },

	{ "packet_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", NULL } },

	{ "key_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", NULL } },

	{ "unix_stream_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", "connectto", "newconn", "acceptfrom", NULL } },

	{ "unix_dgram_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", NULL } },

	{ "sem", { "create", "destroy", "getattr", "setattr", "read", "write", "associate", "unix_read", "unix_write", NULL } },

	{ "msg", { "send", "receive", NULL } },

	{ "msgq", { "create", "destroy", "getattr", "setattr", "read", "write", "associate", "unix_read", "unix_write", "enqueue", NULL } },

	{ "shm", { "create", "destroy", "getattr", "setattr", "read", "write", "associate", "unix_read", "unix_write", "lock", NULL } },

	{ "ipc", { "create", "destroy", "getattr", "setattr", "read", "write", "associate", "unix_read", "unix_write", NULL } },

	{ "passwd", { "passwd", "chfn", "chsh", "rootok", "crontab", NULL } },

	{ "x_drawable", { "create", "destroy", "read", "write", "blend", "getattr", "setattr", "list_child", "add_child", "remove_child", "list_property", "get_property", "set_property", "manage", "override", "show", "hide", "send", "receive", NULL } },

	{ "x_screen", { "getattr", "setattr", "hide_cursor", "show_cursor", "saver_getattr", "saver_setattr", "saver_hide", "saver_show", NULL } },

	{ "x_gc", { "create", "destroy", "getattr", "setattr", "use", NULL } },

	{ "x_font", { "create", "destroy", "getattr", "add_glyph", "remove_glyph", "use", NULL } },

	{ "x_colormap", { "create", "destroy", "read", "write", "getattr", "add_color", "remove_color", "install", "uninstall", "use", NULL } },

	{ "x_property", { "create", "destroy", "read", "write", "append", "getattr", "setattr", NULL } },

	{ "x_selection", { "read", "write", "getattr", "setattr", NULL } },

	{ "x_cursor", { "create", "destroy", "read", "write", "getattr", "setattr", "use", NULL } },

	{ "x_client", { "destroy", "getattr", "setattr", "manage", NULL } },

	{ "x_device", { "getattr", "setattr", "use", "read", "write", "getfocus", "setfocus", "bell", "force_cursor", "freeze", "grab", "manage", "list_property", "get_property", "set_property", "add", "remove", "create", "destroy", NULL } },

	{ "x_server", { "getattr", "setattr", "record", "debug", "grab", "manage", NULL } },

	{ "x_extension", { "query", "use", NULL } },

	{ "netlink_route_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", "nlmsg_read", "nlmsg_write", NULL } },

	{ "netlink_firewall_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", "nlmsg_read", "nlmsg_write", NULL } },

	{ "netlink_tcpdiag_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", "nlmsg_read", "nlmsg_write", NULL } },

	{ "netlink_nflog_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", NULL } },

	{ "netlink_xfrm_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", "nlmsg_read", "nlmsg_write", NULL } },

	{ "netlink_selinux_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", NULL } },

	{ "netlink_audit_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", "nlmsg_read", "nlmsg_write", "nlmsg_relay", "nlmsg_readpriv", "nlmsg_tty_audit", NULL } },

	{ "netlink_ip6fw_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", "nlmsg_read", "nlmsg_write", NULL } },

	{ "netlink_dnrt_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", NULL } },

	{ "dbus", { "acquire_svc", "send_msg", NULL } },

	{ "nscd", { "getpwd", "getgrp", "gethost", "getstat", "admin", "shmempwd", "shmemgrp", "shmemhost", "getserv", "shmemserv", NULL } },

	{ "association", { "sendto", "recvfrom", "setcontext", "polmatch", NULL } },

	{ "netlink_kobject_uevent_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", NULL } },

	{ "appletalk_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", NULL } },

	{ "packet", { "send", "recv", "relabelto", "flow_in", "flow_out", "forward_in", "forward_out", NULL } },

	{ "key", { "view", "read", "write", "search", "link", "setattr", "create", NULL } },

	{ "context", { "translate", "contains", NULL } },

	{ "dccp_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", "node_bind", "name_connect", NULL } },

	{ "memprotect", { "mmap_zero", NULL } },

	{ "db_database", { "create", "drop", "getattr", "setattr", "relabelfrom", "relabelto", "access", "install_module", "load_module", "get_param", "set_param", NULL } },

	{ "db_table", { "create", "drop", "getattr", "setattr", "relabelfrom", "relabelto", "use", "select", "update", "insert", "delete", "lock", NULL } },

	{ "db_procedure", { "create", "drop", "getattr", "setattr", "relabelfrom", "relabelto", "execute", "entrypoint", "install", NULL } },

	{ "db_column", { "create", "drop", "getattr", "setattr", "relabelfrom", "relabelto", "use", "select", "update", "insert", NULL } },

	{ "db_tuple", { "relabelfrom", "relabelto", "use", "select", "update", "insert", "delete", NULL } },

	{ "db_blob", { "create", "drop", "getattr", "setattr", "relabelfrom", "relabelto", "read", "write", "import", "export", NULL } },

	{ "peer", { "recv", NULL } },

	{ "capability2", { "mac_override", "mac_admin", "syslog", NULL } },

	{ "x_resource", { "read", "write", NULL } },

	{ "x_event", { "send", "receive", NULL } },

	{ "x_synthetic_event", { "send", "receive", NULL } },

	{ "x_application_data", { "paste", "paste_after_confirm", "copy", NULL } },

	{ "kernel_service", { "use_as_override", "create_files_as", NULL } },

	{ "tun_socket", { "ioctl", "read", "write", "create", "getattr", "setattr", "lock", "relabelfrom", "relabelto", "append", "bind", "connect", "listen", "accept", "getopt", "setopt", "shutdown", "recvfrom", "sendto", "recv_msg", "send_msg", "name_bind", NULL } },

	{ "x_pointer", { "getattr", "setattr", "use", "read", "write", "getfocus", "setfocus", "bell", "force_cursor", "freeze", "grab", "manage", "list_property", "get_property", "set_property", "add", "remove", "create", "destroy", NULL } },

	{ "x_keyboard", { "getattr", "setattr", "use", "read", "write", "getfocus", "setfocus", "bell", "force_cursor", "freeze", "grab", "manage", "list_property", "get_property", "set_property", "add", "remove", "create", "destroy", NULL } },

	{ "db_schema", { "create", "drop", "getattr", "setattr", "relabelfrom", "relabelto", "search", "add_name", "remove_name", NULL } },

	{ "db_view", { "create", "drop", "getattr", "setattr", "relabelfrom", "relabelto", "expand", NULL } },

	{ "db_sequence", { "create", "drop", "getattr", "setattr", "relabelfrom", "relabelto", "get_value", "next_value", "set_value", NULL } },

	{ "db_language", { "create", "drop", "getattr", "setattr", "relabelfrom", "relabelto", "implement", "execute", NULL } },

	{ "service", { "start", "stop", "status", "reload", "kill", NULL } },

	{ NULL }
};
